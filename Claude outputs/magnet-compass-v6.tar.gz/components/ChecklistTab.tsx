'use client'

import { useMemo, useState } from 'react'
import { api } from '@/lib/client'
import { ClipboardCheck, Plus, Sparkles } from 'lucide-react'
import type { ChecklistItem } from '@/lib/checklist'
import { groupsFor } from '@/lib/checklistGroups'
import type { Product } from '@/lib/checklist'

type Result = {
  id: string
  item_key: string
  status: 'ok' | 'partial' | 'ng' | 'unknown'
  evidence: string | null
  fix: string | null
  manual: boolean
  priority?: Priority | null
}

type Priority = 'high' | 'medium' | 'low'

export type Finding = {
  id: string
  title: string
  detail: string | null
  fix: string | null
  category: string | null
  priority: Priority
}

/** 優先度の見せ方。色だけに頼らず必ずラベルを併記する */
const PRIORITY_LABEL: Record<Priority, string> = {
  high: '最優先',
  medium: '重要',
  low: '推奨',
}
const PRIORITY_STYLE: Record<Priority, string> = {
  high: 'bg-red-100 text-red-900',
  medium: 'bg-amber-100 text-amber-900',
  low: 'bg-surface-muted text-black/60',
}
const PRIORITY_ORDER: Record<Priority, number> = { high: 0, medium: 1, low: 2 }
export type ChecklistState = {
  run: { id: string; score: number | null; ok_count: number; total_count: number; created_at: string } | null
  results: Result[]
  items: ChecklistItem[]
  findings?: Finding[]
}

const STATUS_LABEL: Record<Result['status'], string> = {
  ok: '対応済み',
  partial: '一部のみ',
  ng: '未対応',
  unknown: '未確認'
}

/** 状態色は 4 値の固定パレット。系列色とは別枠で、必ずラベルと併記する。 */
const STATUS_STYLE: Record<Result['status'], string> = {
  ok: 'bg-accel-lightest text-accel-dark',
  partial: 'bg-amber-50 text-amber-800',
  ng: 'bg-red-50 text-red-800',
  unknown: 'bg-surface-muted text-black/50'
}

export default function ChecklistTab({
  product,
  companyId,
  isStaff,
  state,
  onState,
  onTodosChanged,
  onError,
  onNotice
}: {
  companyId: string
  product: Product
  isStaff: boolean
  state: ChecklistState
  onState: (s: ChecklistState) => void
  onTodosChanged: () => void
  onError: (m: string) => void
  onNotice: (m: string) => void
}) {
  const [running, setRunning] = useState(false)
  const [filter, setFilter] = useState<'all' | 'todo' | 'aio'>('all')
  const [category, setCategory] = useState<string>('all')
  const [group, setGroup] = useState<string>('all')

  const byKey = useMemo(
    () => new Map(state.results.map((r) => [r.item_key, r])),
    [state.results]
  )

  const categories = useMemo(
    () => Array.from(new Set(state.items.map((i) => i.category))),
    [state.items]
  )

  const groups = useMemo(() => groupsFor(product, categories), [product, categories])

  /** タブごとの達成率。ok を 1、一部のみを 0.5 として重みで割る */
  const groupStats = useMemo(() => {
    const stat = (items: typeof state.items) => {
      const total = items.reduce((sum, i) => sum + i.weight, 0)
      if (total === 0) return { count: items.length, percent: null as number | null }
      const gained = items.reduce((sum, i) => {
        const st = byKey.get(i.key)?.status
        return sum + i.weight * (st === 'ok' ? 1 : st === 'partial' ? 0.5 : 0)
      }, 0)
      return { count: items.length, percent: Math.round((gained / total) * 100) }
    }
    const out: Record<string, { count: number; percent: number | null }> = {
      all: stat(state.items),
    }
    for (const g of groups) {
      out[g.key] = stat(state.items.filter((i) => g.categories.includes(i.category)))
    }
    return out
  }, [groups, state.items, byKey])

  const activeGroup = groups.find((g) => g.key === group) ?? null

  /** その他の指摘。優先度の高い順に出す */
  const findings = useMemo(
    () =>
      (state.findings ?? [])
        .slice()
        .sort((a, b) => PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority]),
    [state.findings]
  )

  /** タブを切り替えたら、そのタブに無いカテゴリの絞り込みは解除する */
  function selectGroup(key: string) {
    setGroup(key)
    const g = groups.find((x) => x.key === key)
    if (category !== 'all' && (!g || !g.categories.includes(category))) setCategory('all')
  }

  const rows = state.items
    .filter((item) => {
      if (activeGroup && !activeGroup.categories.includes(item.category)) return false
      if (category !== 'all' && item.category !== category) return false
      if (filter === 'aio' && !item.aio) return false
      if (filter === 'todo') {
        const status = byKey.get(item.key)?.status
        return status === 'ng' || status === 'partial'
      }
      return true
    })
    // 直すべき順に並べる。点検表の並びより、優先度の方が行動に近い
    .slice()
    .sort((a, b) => {
      const pa = PRIORITY_ORDER[byKey.get(a.key)?.priority ?? 'medium']
      const pb = PRIORITY_ORDER[byKey.get(b.key)?.priority ?? 'medium']
      return pa - pb
    })

  async function run(diff = false) {
    setRunning(true)
    try {
      const next = await api<ChecklistState>('/api/checklist', {
        method: 'POST',
        body: { company_id: companyId, diff }
      })
      onState(next)
      onNotice(diff ? '差分点検が完了しました' : '点検が完了しました')
    } catch (e: any) {
      onError(e.message)
    }
    setRunning(false)
  }

  async function setStatus(result: Result, status: Result['status']) {
    const before = state.results
    onState({
      ...state,
      results: state.results.map((r) => (r.id === result.id ? { ...r, status, manual: true } : r))
    })
    try {
      await api('/api/checklist', { method: 'PATCH', body: { id: result.id, status } })
    } catch (e: any) {
      onState({ ...state, results: before })
      onError(e.message)
    }
  }

  async function sendToTodo(keys: string[]) {
    if (keys.length === 0) return
    try {
      const res = await api<{ added: number }>('/api/checklist', {
        method: 'PATCH',
        body: { action: 'to_todo', company_id: companyId, keys }
      })
      onTodosChanged()
      onNotice(
        res.added > 0
          ? `${res.added} 件を「やること」に追加しました`
          : 'すべて既に「やること」に入っています'
      )
    } catch (e: any) {
      onError(e.message)
    }
  }

  const counts = {
    ok: state.results.filter((r) => r.status === 'ok').length,
    partial: state.results.filter((r) => r.status === 'partial').length,
    ng: state.results.filter((r) => r.status === 'ng').length,
    unknown: state.results.filter((r) => r.status === 'unknown').length
  }

  const pending = state.items
    .filter((i) => {
      const s = byKey.get(i.key)?.status
      return s === 'ng' || s === 'partial'
    })
    .map((i) => i.key)

  if (!state.run) {
    return (
      <section className="rounded-2xl border border-border-soft bg-surface p-10 text-center">
        <ClipboardCheck size={28} className="mx-auto mb-3 text-accel-secondary" />
        <h3 className="mb-2">{state.items.length} 項目の点検表</h3>
        <p className="mx-auto mb-2 max-w-xl text-sm text-black/70">
          {/* 分類は点検表そのものから出す。製品を増やしても文面を直さずに済む。
              区切りに「・」を使うと「導線・CTA」のような分類名と見分けが付かないため読点にする */}
          {categories.join('、')}を、実際にサイトや口コミを見ながら1項目ずつ確認します。
        </p>
        <p className="mx-auto mb-2 max-w-xl text-sm text-black/60">
          うち {state.items.filter((i) => i.aio).length} 項目は「AI に見つけられ、正しく説明されるか」に直接効くものです。
        </p>
        <p className="mx-auto mb-6 max-w-xl text-sm text-black/60">
          構造化データや robots.txt など {state.items.filter((i) => i.auto).length} 項目は、
          ページを直接取得してコードで判定します（推測が入らず、費用もかかりません）。
        </p>
        {isStaff ? (
          <button
            onClick={() => run(false)}
            disabled={running}
            className="rounded-lg bg-accel-primary px-6 py-3 text-white hover:bg-accel-hover active:bg-accel-active"
          >
            {running ? '点検中… 3分ほどかかります' : '点検する'}
          </button>
        ) : (
          <p className="text-sm text-black/60">担当者が点検を実行すると表示されます。</p>
        )}
      </section>
    )
  }

  return (
    <section className="flex flex-col gap-6">
      <div className="rounded-2xl border border-border-soft bg-surface p-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="text-sm text-black/60">達成率（重要度で重み付け）</p>
            <p className="text-4xl font-bold tabular-nums text-accel-primary">
              {state.run.score ?? '—'}
              <span className="ml-1 text-base font-normal text-black/40">%</span>
            </p>
            <p className="mt-1 text-xs text-black/50">
              {new Date(state.run.created_at).toLocaleString('ja-JP')} 時点
            </p>
          </div>

          <dl className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
            {(['ok', 'partial', 'ng', 'unknown'] as const).map((s) => (
              <div key={s} className="flex items-center gap-2">
                <span className={`rounded px-2 py-0.5 text-xs ${STATUS_STYLE[s]}`}>
                  {STATUS_LABEL[s]}
                </span>
                <dd className="tabular-nums">{counts[s]}</dd>
              </div>
            ))}
          </dl>

          {isStaff && (
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => sendToTodo(pending)}
                disabled={pending.length === 0}
                className="flex items-center gap-2 rounded-lg bg-accel-primary px-4 py-2 text-sm text-white hover:bg-accel-hover"
              >
                <Plus size={16} />
                未対応をまとめて追加（{pending.length}）
              </button>
              <button
                onClick={() => run(true)}
                disabled={running}
                title="変わりやすい項目と、まだ未達の項目だけを再確認します。費用が大幅に安く済みます"
                className="flex items-center gap-2 rounded-lg border-2 border-border-soft px-4 py-2 text-sm hover:border-accel-secondary"
              >
                <Sparkles size={16} />
                {running ? '点検中…' : '差分点検'}
              </button>
              <button
                onClick={() => run(false)}
                disabled={running}
                title={`全 ${state.items.length} 項目をゼロから点検し直します`}
                className="rounded-lg border-2 border-border-soft px-4 py-2 text-sm text-black/60 hover:border-accel-secondary"
              >
                全点検
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 分類のタブ。コンパスは 11 カテゴリあり一度に見るには多いのでまとめている */}
      <div>
        <div className="flex flex-wrap gap-2" role="tablist" aria-label="点検の分類">
          {[{ key: 'all', label: 'すべて' }, ...groups].map((g) => {
            const stat = groupStats[g.key]
            const on = group === g.key
            return (
              <button
                key={g.key}
                role="tab"
                aria-selected={on}
                onClick={() => selectGroup(g.key)}
                className={
                  on
                    ? 'rounded-xl border-2 border-accel-primary bg-accel-lightest px-4 py-2.5 text-left'
                    : 'rounded-xl border-2 border-border-soft bg-surface px-4 py-2.5 text-left hover:border-accel-secondary'
                }
              >
                <span className={on ? 'block font-semibold text-accel-deep' : 'block font-semibold'}>
                  {g.label}
                </span>
                <span className="block text-sm text-black/60">
                  {stat?.count ?? 0} 項目
                  {stat?.percent !== null && stat?.percent !== undefined && ` ・ ${stat.percent}%`}
                </span>
              </button>
            )
          })}
        </div>
        {activeGroup && <p className="mt-2 text-sm text-black/60">{activeGroup.note}</p>}
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="flex gap-1 rounded-lg border-2 border-border-soft bg-surface p-1">
          {([
            ['all', 'すべて'],
            ['todo', '未対応・一部のみ'],
            ['aio', 'AI検索に効く']
          ] as const).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setFilter(key)}
              className={
                filter === key
                  ? 'rounded-md bg-accel-primary px-3 py-1.5 text-sm text-white'
                  : 'rounded-md px-3 py-1.5 text-sm text-black/60 hover:text-black'
              }
            >
              {label}
            </button>
          ))}
        </div>

        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="sm:w-56"
          aria-label="カテゴリで絞り込む"
        >
          <option value="all">すべてのカテゴリ</option>
          {(activeGroup ? activeGroup.categories : categories).map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>

        <p className="text-sm text-black/60">{rows.length} 項目</p>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-border-soft bg-surface">
        <table className="w-full min-w-[900px] border-collapse text-sm">
          <thead>
            <tr className="border-b border-border-soft bg-surface-muted text-left">
              <th className="w-40 px-4 py-3 font-semibold">カテゴリ</th>
              <th className="px-4 py-3 font-semibold">項目</th>
              <th className="w-32 px-4 py-3 font-semibold">状態</th>
              <th className="px-4 py-3 font-semibold">根拠と直し方</th>
              {isStaff && <th className="w-20 px-4 py-3 font-semibold">操作</th>}
            </tr>
          </thead>
          <tbody>
            {rows.map((item) => {
              const result = byKey.get(item.key)
              const status = result?.status ?? 'unknown'
              return (
                <tr key={item.key} className="border-b border-border-soft/60 align-top">
                  <td className="px-4 py-4 text-black/60">
                    {(() => {
                      const pr = result?.priority ?? null
                      return pr ? (
                        <span
                          className={`mb-1 block w-fit rounded px-1.5 py-0.5 text-[11px] font-semibold ${PRIORITY_STYLE[pr]}`}
                        >
                          {PRIORITY_LABEL[pr]}
                        </span>
                      ) : null
                    })()}
                    {item.category}
                    <span className="mt-1 flex flex-wrap gap-1">
                      {item.aio && (
                        <span className="w-fit rounded bg-accel-lightest px-1.5 py-0.5 text-[11px] text-accel-dark">
                          AI検索
                        </span>
                      )}
                      {item.auto && (
                        <span
                          className="w-fit rounded bg-surface-muted px-1.5 py-0.5 text-[11px] text-black/50"
                          title="ページを直接取得して機械的に判定しています"
                        >
                          自動判定
                        </span>
                      )}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <p className="font-semibold">{item.title}</p>
                    <p className="mt-1 text-black/60">{item.check}</p>
                    <p className="mt-1 text-xs text-black/40">{item.why}</p>
                  </td>
                  <td className="px-4 py-4">
                    {isStaff && result ? (
                      <select
                        value={status}
                        onChange={(e) => setStatus(result, e.target.value as Result['status'])}
                        aria-label={`${item.title} の状態`}
                        style={{ minHeight: '36px', padding: '4px 8px', fontSize: '13px', width: '100%' }}
                      >
                        <option value="ok">対応済み</option>
                        <option value="partial">一部のみ</option>
                        <option value="ng">未対応</option>
                        <option value="unknown">未確認</option>
                      </select>
                    ) : (
                      <span className={`rounded px-2 py-0.5 text-xs ${STATUS_STYLE[status]}`}>
                        {STATUS_LABEL[status]}
                      </span>
                    )}
                    {result?.manual && (
                      <span className="mt-1 block text-[11px] text-black/40">手動更新</span>
                    )}
                  </td>
                  <td className="px-4 py-4">
                    {result?.evidence && <p className="text-black/70">{result.evidence}</p>}
                    {result?.fix && (
                      <p className="mt-2 rounded-lg bg-surface-muted px-3 py-2">
                        <span className="font-semibold">直し方：</span>
                        {result.fix}
                      </p>
                    )}
                  </td>
                  {isStaff && (
                    <td className="px-4 py-4">
                      {(status === 'ng' || status === 'partial') && (
                        <button
                          onClick={() => sendToTodo([item.key])}
                          aria-label="やることに追加"
                          className="rounded-lg border-2 border-border-soft p-2 hover:border-accel-secondary"
                        >
                          <Plus size={14} />
                        </button>
                      )}
                    </td>
                  )}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* 点検表に無い気づき。固定の項目では拾えない、そのサイト固有の問題 */}
      {findings.length > 0 && (
        <div className="rounded-2xl border border-border-soft bg-surface p-6">
          <h3 className="mb-1">その他の指摘（{findings.length}件）</h3>
          <p className="mb-4 text-sm text-black/60">
            点検表の項目には無いが、実際にサイトを見て気づいた点です。
          </p>
          <ul className="flex flex-col gap-4">
            {findings.map((f) => (
              <li key={f.id} className="border-t border-border-soft pt-4 first:border-t-0 first:pt-0">
                <div className="mb-1 flex flex-wrap items-center gap-2">
                  <span
                    className={`rounded px-1.5 py-0.5 text-[11px] font-semibold ${PRIORITY_STYLE[f.priority]}`}
                  >
                    {PRIORITY_LABEL[f.priority]}
                  </span>
                  {f.category && <span className="text-sm text-black/50">{f.category}</span>}
                </div>
                <p className="font-semibold">{f.title}</p>
                {f.detail && <p className="mt-1 text-sm text-black/70">{f.detail}</p>}
                {f.fix && (
                  <p className="mt-1 text-sm text-accel-deep">直し方: {f.fix}</p>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  )
}
