'use client'

import { useMemo, useState } from 'react'
import { api } from '@/lib/client'
import { MessageSquare, Sparkles, Pencil, Check } from 'lucide-react'
import { WORDING } from '@/lib/wording'
import type { Product } from '@/lib/checklist'

type Question = { id: string; question: string; intent: string | null; sort_order: number }
type Mention = {
  id: string
  question_id: string | null
  batch_id: string | null
  question: string
  answer: string | null
  mentioned: boolean | null
  rank_position: number | null
  sentiment: string | null
  notes: string | null
  sources: string[] | null
  created_at: string
}
export type MentionState = { questions: Question[]; mentions: Mention[] }

const SENTIMENT_LABEL: Record<string, string> = {
  positive: '好意的',
  neutral: '中立',
  negative: '否定的',
  absent: '登場せず'
}

export default function MentionsTab({
  product,
  companyId,
  isStaff,
  state,
  onState,
  onError,
  onNotice
}: {
  companyId: string
  product: Product
  isStaff: boolean
  state: MentionState
  onState: (s: MentionState) => void
  onError: (m: string) => void
  onNotice: (m: string) => void
}) {
  const w = WORDING[product]
  const [busy, setBusy] = useState<'questions' | 'probe' | null>(null)
  const [editing, setEditing] = useState<string | null>(null)
  const [draft, setDraft] = useState('')
  const [openAnswer, setOpenAnswer] = useState<string | null>(null)

  // 最新バッチと、質問ごとの履歴
  const batches = useMemo(() => {
    const map = new Map<string, Mention[]>()
    for (const m of state.mentions) {
      const key = m.batch_id ?? m.id
      if (!map.has(key)) map.set(key, [])
      map.get(key)!.push(m)
    }
    return Array.from(map.entries()).sort(
      (a, b) => new Date(b[1][0].created_at).getTime() - new Date(a[1][0].created_at).getTime()
    )
  }, [state.mentions])

  const latest = batches[0]?.[1] ?? []
  const latestByQuestion = new Map(latest.map((m) => [m.question_id ?? m.question, m]))

  const measured = latest.filter((m) => m.mentioned !== null)
  const hitRate = measured.length
    ? Math.round((measured.filter((m) => m.mentioned).length / measured.length) * 100)
    : null

  async function buildQuestions() {
    setBusy('questions')
    try {
      const res = await api<{ questions: Question[] }>('/api/mentions', {
        method: 'POST',
        body: { company_id: companyId, action: 'questions' }
      })
      onState({ ...state, questions: res.questions })
      onNotice('測定用の質問を作成しました')
    } catch (e: any) {
      onError(e.message)
    }
    setBusy(null)
  }

  async function probe() {
    setBusy('probe')
    try {
      const res = await api<{ mentions: Mention[] }>('/api/mentions', {
        method: 'POST',
        body: { company_id: companyId }
      })
      onState({ ...state, mentions: [...res.mentions, ...state.mentions] })
      onNotice('測定が完了しました')
    } catch (e: any) {
      onError(e.message)
    }
    setBusy(null)
  }

  async function saveQuestion(id: string) {
    try {
      const updated = await api<Question>('/api/mentions', {
        method: 'PATCH',
        body: { id, question: draft }
      })
      onState({
        ...state,
        questions: state.questions.map((q) => (q.id === id ? updated : q))
      })
      setEditing(null)
    } catch (e: any) {
      onError(e.message)
    }
  }

  if (state.questions.length === 0) {
    return (
      <section className="rounded-2xl border border-border-soft bg-surface p-10 text-center">
        <MessageSquare size={28} className="mx-auto mb-3 text-accel-secondary" />
        <h3 className="mb-2">まず測定用の質問を作ります</h3>
        <p className="mx-auto mb-3 max-w-xl text-sm text-black/70">
          {w.mentionNote}
          自社が候補に挙がるか・どう説明されるかを記録します。
        </p>
        <p className="mx-auto mb-6 max-w-xl text-sm text-black/60">
          質問文に社名は入れません。社名を書くと「その会社を知っているか」を聞くことになり、
          「候補として挙がるか」を測れなくなるためです。
        </p>
        {isStaff ? (
          <button
            onClick={buildQuestions}
            disabled={busy !== null}
            className="rounded-lg bg-accel-primary px-6 py-3 text-white hover:bg-accel-hover active:bg-accel-active"
          >
            {busy === 'questions' ? '設計中… 1分ほどかかります' : '質問を作る'}
          </button>
        ) : (
          <p className="text-sm text-black/60">担当者が設定すると表示されます。</p>
        )}
      </section>
    )
  }

  return (
    <section className="flex flex-col gap-6">
      <div className="rounded-2xl border border-border-soft bg-surface p-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="text-sm text-black/60">言及率（直近の測定）</p>
            <p className="text-4xl font-bold tabular-nums text-accel-primary">
              {hitRate === null ? '—' : hitRate}
              <span className="ml-1 text-base font-normal text-black/40">%</span>
            </p>
            {latest.length > 0 && (
              <p className="mt-1 text-xs text-black/50">
                {new Date(latest[0].created_at).toLocaleString('ja-JP')} 時点 ／{' '}
                {measured.filter((m) => m.mentioned).length} / {measured.length} 問で登場
              </p>
            )}
          </div>

          {isStaff && (
            <div className="flex flex-wrap gap-2">
              <button
                onClick={probe}
                disabled={busy !== null}
                className="flex items-center gap-2 rounded-lg bg-accel-primary px-5 py-2 text-sm text-white hover:bg-accel-hover"
              >
                <Sparkles size={16} />
                {busy === 'probe' ? '測定中… 2〜3分' : latest.length ? '再測定' : '測定する'}
              </button>
              <button
                onClick={buildQuestions}
                disabled={busy !== null}
                title="質問を作り直すと、以前の測定と比較できなくなります"
                className="rounded-lg border-2 border-border-soft px-4 py-2 text-sm text-black/60 hover:border-accel-secondary"
              >
                質問を作り直す
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-border-soft bg-surface">
        <table className="w-full min-w-[820px] border-collapse text-sm">
          <thead>
            <tr className="border-b border-border-soft bg-surface-muted text-left">
              <th className="px-4 py-3 font-semibold">質問</th>
              <th className="w-24 px-4 py-3 font-semibold">登場</th>
              <th className="w-24 px-4 py-3 font-semibold">評価</th>
              <th className="px-4 py-3 font-semibold">状況</th>
            </tr>
          </thead>
          <tbody>
            {state.questions.map((q) => {
              const m = latestByQuestion.get(q.id)
              return (
                <tr key={q.id} className="border-b border-border-soft/60 align-top">
                  <td className="px-4 py-4">
                    {editing === q.id ? (
                      <div className="flex flex-col gap-2">
                        <textarea
                          value={draft}
                          onChange={(e) => setDraft(e.target.value)}
                          style={{ minHeight: '72px' }}
                        />
                        <div className="flex gap-2">
                          <button
                            onClick={() => saveQuestion(q.id)}
                            className="flex items-center gap-1.5 rounded-lg bg-accel-primary px-3 py-1.5 text-xs text-white"
                          >
                            <Check size={14} />
                            保存
                          </button>
                          <button
                            onClick={() => setEditing(null)}
                            className="rounded-lg border-2 border-border-soft px-3 py-1.5 text-xs"
                          >
                            やめる
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <p className="font-semibold">{q.question}</p>
                        {q.intent && <p className="mt-1 text-xs text-black/50">{q.intent}</p>}
                        {isStaff && (
                          <button
                            onClick={() => {
                              setDraft(q.question)
                              setEditing(q.id)
                            }}
                            className="mt-2 flex items-center gap-1 text-xs text-black/50 hover:text-black"
                          >
                            <Pencil size={12} />
                            編集
                          </button>
                        )}
                      </>
                    )}
                  </td>
                  <td className="px-4 py-4">
                    {m?.mentioned === null || m === undefined ? (
                      <span className="text-black/40">—</span>
                    ) : m.mentioned ? (
                      <span className="rounded bg-accel-lightest px-2 py-0.5 text-xs text-accel-dark">
                        {m.rank_position ? `${m.rank_position} 番目` : '登場'}
                      </span>
                    ) : (
                      <span className="rounded bg-red-50 px-2 py-0.5 text-xs text-red-800">
                        登場せず
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-4 text-black/60">
                    {m?.sentiment ? SENTIMENT_LABEL[m.sentiment] ?? m.sentiment : '—'}
                  </td>
                  <td className="px-4 py-4">
                    {m?.notes && <p className="text-black/70">{m.notes}</p>}
                    {m?.sources && m.sources.length > 0 && (
                      <p className="mt-2 text-xs text-black/50">
                        挙がった企業：{m.sources.slice(0, 8).join('、')}
                      </p>
                    )}
                    {m?.answer && (
                      <button
                        onClick={() => setOpenAnswer(openAnswer === m.id ? null : m.id)}
                        className="mt-2 text-xs underline"
                      >
                        {openAnswer === m.id ? '回答を閉じる' : 'AI の回答を見る'}
                      </button>
                    )}
                    {openAnswer === m?.id && m?.answer && (
                      <p className="mt-2 max-h-64 overflow-y-auto whitespace-pre-wrap rounded-lg bg-surface-muted px-3 py-2 text-xs text-black/70">
                        {m.answer}
                      </p>
                    )}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {batches.length > 1 && (
        <div className="rounded-2xl border border-border-soft bg-surface p-6">
          <h3 className="mb-4">測定の履歴</h3>
          <ul className="flex flex-col gap-2">
            {batches.map(([key, items]) => {
              const done = items.filter((m) => m.mentioned !== null)
              const hits = done.filter((m) => m.mentioned).length
              return (
                <li
                  key={key}
                  className="flex flex-wrap items-center justify-between gap-3 border-t border-border-soft pt-2 text-sm"
                >
                  <span className="text-black/60">
                    {new Date(items[0].created_at).toLocaleString('ja-JP')}
                  </span>
                  <span className="tabular-nums">
                    {done.length ? `${hits} / ${done.length} 問で登場` : '測定できず'}
                    {done.length > 0 && (
                      <span className="ml-2 text-black/50">
                        （{Math.round((hits / done.length) * 100)}%）
                      </span>
                    )}
                  </span>
                </li>
              )
            })}
          </ul>
        </div>
      )}
    </section>
  )
}
