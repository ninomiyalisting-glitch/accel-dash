-- =====================================================================
-- 第5段階：製品の切り替え（採用版マグネット / 集客版コンパス）
-- 何度実行しても安全です。
--
-- 会社ごとに「どちらの点検表を使うか」を持たせる。点検表そのものは
-- コード側（lib/checklist-magnet.ts / lib/checklist-compass.ts）にあり、
-- DB は「どちらを使うか」だけを持つ。項目を DB に置かないのは、
-- 会社間の比較と時系列の進捗を成り立たせるため。
-- =====================================================================

-- ── 会社の製品 ────────────────────────────────────────────────
-- 既存の行はすべて採用版として動いていたので magnet を既定にする。
alter table public.companies
  add column if not exists product text not null default 'magnet';

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'companies_product_check'
  ) then
    alter table public.companies
      add constraint companies_product_check check (product in ('magnet', 'compass'));
  end if;
end $$;

-- ── 点検の実行にも製品を残す ──────────────────────────────────
-- 会社の製品を後から変えても、過去の点検が「どの表で測ったか」が
-- 分かるようにする。これが無いと点数の推移が意味を失う。
alter table public.checklist_runs
  add column if not exists product text not null default 'magnet';

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'checklist_runs_product_check'
  ) then
    alter table public.checklist_runs
      add constraint checklist_runs_product_check check (product in ('magnet', 'compass'));
  end if;
end $$;

-- 製品ごとの最新 run を引く問い合わせが増えるので索引を足す
create index if not exists checklist_runs_company_product_idx
  on public.checklist_runs(company_id, product, created_at desc);

create index if not exists companies_product_idx
  on public.companies(product) where archived = false;

-- ── 優先度 ────────────────────────────────────────────────────
-- どの指摘から手を付けるかを出すため。既存行は medium 扱いにする。
alter table public.checklist_results
  add column if not exists priority text not null default 'medium';

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'checklist_results_priority_check'
  ) then
    alter table public.checklist_results
      add constraint checklist_results_priority_check
      check (priority in ('high', 'medium', 'low'));
  end if;
end $$;

-- ── 点検表に無い気づき ────────────────────────────────────────
-- 固定の点検表だけでは、そのサイト固有の問題を拾えない。
-- 項目に紐づかない指摘をここに貯める。run に紐づけ、履歴として残す。
create table if not exists public.checklist_findings (
  id uuid primary key default gen_random_uuid(),
  run_id uuid not null references public.checklist_runs(id) on delete cascade,
  company_id uuid not null references public.companies(id) on delete cascade,
  title text not null,
  detail text,
  fix text,
  category text,
  priority text not null default 'medium',
  created_at timestamptz not null default now()
);
create index if not exists checklist_findings_run_idx on public.checklist_findings(run_id);
create index if not exists checklist_findings_company_idx
  on public.checklist_findings(company_id, created_at desc);

alter table public.checklist_findings enable row level security;

-- 閲覧は所属会社のみ、書き込みは担当者のみ。他テーブルと同じ方針。
drop policy if exists checklist_findings_select on public.checklist_findings;
create policy checklist_findings_select on public.checklist_findings
  for select to authenticated using (public.has_company_access(company_id));

drop policy if exists checklist_findings_write on public.checklist_findings;
create policy checklist_findings_write on public.checklist_findings
  for all to authenticated using (public.is_staff()) with check (public.is_staff());
