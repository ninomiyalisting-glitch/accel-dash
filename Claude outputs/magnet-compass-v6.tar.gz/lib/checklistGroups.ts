/**
 * 点検表のタブ分け。
 *
 * カテゴリのままだとコンパスは 11 個あり、一度に見るには多い。
 * 実務で「どこを直すか」を考える単位にまとめる。
 *
 * ここに書いていないカテゴリは「その他」に落ちる。点検表に新しい
 * カテゴリを足したときに項目が消えないようにするための逃がし先で、
 * 恒久的にそこへ置く想定ではない。落ちたままなら、この表に足すこと。
 */
import type { Product } from './checklist'

export type Group = {
  key: string
  label: string
  /** このタブが何を見るかの一文。タブの下に出す */
  note: string
  categories: string[]
}

/** 「その他」に落ちる分の受け皿。categories は実行時に決まる */
const OTHER_KEY = 'other'

const COMPASS_GROUPS: Group[] = [
  {
    key: 'appeal',
    label: '魅力',
    note: '訪問者に何が伝わるか。第一印象と、読ませて動かすまでの中身',
    categories: ['ファーストビュー', '導線・CTA', 'コンテンツ'],
  },
  {
    key: 'reputation',
    label: '口コミ',
    note: '第三者からどう見えているか。自社発信では埋められない部分',
    categories: ['口コミ・評判', 'SNS'],
  },
  {
    key: 'seo',
    label: 'SEO・AIO',
    note: '検索と AI に見つけられ、正しく説明されるか',
    categories: ['技術SEO', 'AI検索対応'],
  },
  {
    key: 'ui',
    label: 'UI',
    note: '実際に操作する場面での使いやすさ',
    categories: ['フォーム'],
  },
]

const MAGNET_GROUPS: Group[] = [
  {
    key: 'appeal',
    label: '魅力',
    note: '求職者に何が伝わるか。採用ページと求人票の中身',
    categories: ['採用サイト', '求人票', 'コンテンツ'],
  },
  {
    key: 'reputation',
    label: '口コミ',
    note: '第三者からどう見えているか。自社発信では埋められない部分',
    categories: ['口コミ・第三者評価', 'SNS'],
  },
  {
    key: 'seo',
    label: 'SEO・AIO',
    note: '検索と AI に見つけられ、正しく説明されるか',
    categories: ['構造化データ・技術', 'AI検索対応'],
  },
  {
    key: 'ui',
    label: '応募導線',
    note: '応募しようとした人が、最後までたどり着けるか',
    categories: ['選考プロセス'],
  },
]

const BASE: Record<Product, Group[]> = {
  magnet: MAGNET_GROUPS,
  compass: COMPASS_GROUPS,
}

/**
 * 実際のカテゴリ一覧を渡して、タブの定義を作る。
 * どのタブにも入らなかったカテゴリは「その他」にまとめる。
 */
export function groupsFor(product: Product, categories: string[]): Group[] {
  const base = BASE[product]
  const claimed = new Set(base.flatMap((g) => g.categories))
  // 点検表に実在するカテゴリだけを残す（定義の書き間違いで空タブが出ないように）
  const groups = base
    .map((g) => ({ ...g, categories: g.categories.filter((c) => categories.includes(c)) }))
    .filter((g) => g.categories.length > 0)

  const rest = categories.filter((c) => !claimed.has(c))
  if (rest.length > 0) {
    groups.push({
      key: OTHER_KEY,
      label: 'その他',
      note: rest.join('、'),
      categories: rest,
    })
  }
  return groups
}
