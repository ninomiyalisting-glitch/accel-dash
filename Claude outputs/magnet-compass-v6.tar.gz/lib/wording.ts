/**
 * 画面に出る、製品ごとに変わる言い回し。
 *
 * プロンプト側の VOICE（lib/prompts.ts）と役割は同じだが、あちらは
 * Claude への指示、こちらは人が読む説明文。混ぜると片方だけ直して
 * 食い違うので別に持つ。
 */
import type { Product } from './checklist'

type Wording = {
  /** 点検の相手。「〜が見る」の主語 */
  audience: string
  /** ネタ出しタブの説明 */
  contentNote: string
  /** AI 言及タブの説明 */
  mentionNote: string
  /** スコアタブ：評価軸を作るときの説明 */
  criteriaNote: string
  /** スコアタブ：採点するときの説明 */
  scoringNote: string
  /** 会社登録フォーム：サイト欄のラベル */
  websiteLabel: string
  /** 会社登録フォーム：競合欄の補足 */
  rivalNote: string
  /** 会社登録フォーム：メモ欄の例 */
  notesPlaceholder: string
  /** やること欄の入力例 */
  todoPlaceholder: string
}

export const WORDING: Record<Product, Wording> = {
  magnet: {
    audience: '求職者',
    contentNote:
      '点検で弱かった箇所と、競合が答えていない質問をもとに、採用ブログや SNS のネタを 20〜30 本出します。',
    mentionNote: '求職者が AI に投げる質問を 5〜7 個設計し、それを毎回同じ文面で投げて、',
    criteriaNote:
      '登録した会社情報と競合をもとに、求職者がこの会社を選ぶときに見る基準を洗い出し、',
    scoringNote:
      'Web 検索で採用サイト・求人・口コミを調べ、上の軸で採点します。打ち手も「やること」に追加されます。',
    websiteLabel: '採用サイト / 企業サイト',
    rivalNote: '求職者が併願しそうな会社を入れてください。スコアの比較対象になります。',
    notesPlaceholder: '採用の課題、ターゲット、進行中の施策など。分析の前提として使われます。',
    todoPlaceholder: 'やることを入力（例: 採用ページに社員インタビューを3本追加）',
  },
  compass: {
    audience: '見込み客',
    contentNote:
      '点検で弱かった箇所と、競合が答えていない質問をもとに、記事や事例、料金ページのネタを 20〜30 本出します。',
    mentionNote: '見込み客が AI に投げる質問を 5〜7 個設計し、それを毎回同じ文面で投げて、',
    criteriaNote:
      '登録した会社情報と競合をもとに、見込み客がこの会社に頼むかを決めるときに見る基準を洗い出し、',
    scoringNote:
      'Web 検索でサイト・料金・事例・口コミを調べ、上の軸で採点します。打ち手も「やること」に追加されます。',
    websiteLabel: 'サービスサイト / 企業サイト',
    rivalNote: '見込み客が相見積もりを取りそうな会社を入れてください。スコアの比較対象になります。',
    notesPlaceholder: '集客の課題、ターゲット、進行中の施策など。分析の前提として使われます。',
    todoPlaceholder: 'やることを入力（例: 料金ページに目安の金額レンジを載せる）',
  },
}
