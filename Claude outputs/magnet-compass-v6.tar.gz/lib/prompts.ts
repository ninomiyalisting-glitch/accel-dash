import type { Product } from './checklist'

/**
 * 製品ごとの言い回し。
 *
 * 採用版と集客版は「誰に向けて何を良くするか」だけが違い、調べ方の骨格は同じ。
 * 文面を丸ごと 2 本持つと片方だけ直して食い違うので、違う語だけをここに集める。
 */
type Voice = {
  /** 調査者の立場 */
  analyst: string
  /** 対象読者 */
  audience: string
  /** 「〜がこの企業を選ぶか」の動詞。採用は「入社するか」集客は「依頼するか」 */
  decision: string
  /** スコアの評価軸を作るときに調べる先 */
  scoreSources: string
  /** 判断される対象の呼び方 */
  asset: string
  /** 実地で見るべき場所 */
  sources: string[]
  /** AI・検索で何と検索して確かめるか（会社名と業種を受け取る） */
  probes: (name: string, industry: string) => string[]
}

const VOICE: Record<Product, Voice> = {
  magnet: {
    analyst: '採用広報と検索・AI 対策の実務者',
    audience: '求職者',
    decision: 'この会社に応募・入社するか',
    scoreSources: '採用サイト・求人情報・口コミ（OpenWork、転職会議など）・報道',
    asset: '採用ページ・求人票',
    sources: [
      '企業サイトと採用ページ（構成、掲載内容、更新日）',
      '自社ドメインの求人票の有無と中身',
      '採用ブログ・オウンドメディアの有無と最終更新',
      'SNS アカウントの有無と最終投稿',
      '口コミサイト（OpenWork、転職会議など）の登録状況と評価',
      '第三者メディアでの言及',
    ],
    probes: (name, industry) => [
      `${name} とはどんな会社か`,
      `${industry}で転職におすすめの会社`,
    ],
  },
  compass: {
    analyst: 'ウェブマーケティングと検索・AI 対策の実務者',
    audience: '見込み客',
    decision: 'この会社に問い合わせ・発注するか',
    scoreSources: 'サービスサイト・料金や事例のページ・口コミ（Google、比較サイトなど）・業界メディア',
    asset: 'サービスサイト・ランディングページ',
    sources: [
      'サービスサイトのトップと主要な下層ページ（構成、訴求、更新日）',
      '料金・事例・よくある質問のページの有無と具体性',
      '問い合わせフォームの項目数と入力しやすさ（スマホでの見え方も）',
      'オウンドメディア・ブログの有無と最終更新',
      'SNS アカウントの有無と最終投稿',
      'Googleビジネスプロフィールと口コミの件数・評価・返信状況',
      '比較サイト、業界メディア、プレスリリースでの掲載',
    ],
    probes: (name, industry) => [
      `${name} の評判`,
      `${industry}のおすすめ業者`,
      `${industry} 依頼 比較`,
    ],
  },
}

type CompanyInput = {
  name: string
  website?: string | null
  industry?: string | null
  notes?: string | null
  competitors: { name: string; website?: string | null }[]
}

function companyBlock(c: CompanyInput) {
  const rivals = c.competitors.length
    ? c.competitors.map((r) => `- ${r.name}${r.website ? `（${r.website}）` : ''}`).join('\n')
    : '（未登録）'

  return [
    `会社名: ${c.name}`,
    `サイト: ${c.website || '（未登録）'}`,
    `業種: ${c.industry || '（未登録）'}`,
    `競合:\n${rivals}`,
    `補足メモ: ${c.notes || '（なし）'}`
  ].join('\n')
}

// ---------------------------------------------------------------------
// 第1段：調査（Web 検索あり・出力は文章）
// ---------------------------------------------------------------------

export function criteriaResearch(c: CompanyInput, product: Product = 'magnet') {
  const v = VOICE[product]
  const market = product === 'magnet' ? '日本の採用市場' : 'この業界の商習慣と発注の実態'
  return `あなたは${market}に詳しいアナリストです。以下の企業について、**${v.audience}が${v.decision}を判断するときに見る基準**を洗い出してください。

${companyBlock(c)}

web_search で、この企業と競合の${v.scoreSources}を調べ、この業種の${v.audience}が実際に重視している論点を把握してください。

そのうえで評価軸を 8〜12 個に整理し、文章で提案してください。

- **この業種・この${v.audience}層にとって重要な順**に並べる
- 各軸に重み（0〜100 の数値）を割り当て、**合計をちょうど 100 にする**
- 軸は「給与・待遇」のように、**外から観測できる**ものにする。社内文化のように外部から検証できないものは避ける
- 軸名は 15 文字以内。説明は「何を見て判断するか」を 1〜2 文で
- この軸は今後この企業を継続的に採点するための固定の軸になる。**流行や一時的な話題ではなく、数年単位で有効なもの**を選ぶ

最後に、この軸構成にした理由を 3 文以内でまとめてください。`
}

export function scoringResearch(
  c: CompanyInput,
  criteria: { name: string; description: string | null; weight: number }[],
  product: Product = 'magnet'
) {
  const v = VOICE[product]
  const market = product === 'magnet' ? '日本の採用市場' : 'この業界の商習慣と発注の実態'
  const axes = criteria
    .map((x) => `- ${x.name}（重み ${x.weight}）：${x.description || ''}`)
    .join('\n')

  const rivalNames = c.competitors.map((r) => r.name)

  return `あなたは${market}に詳しいアナリストです。以下の企業を、**指定された評価軸のみ**を使って採点してください。軸を追加・削除・改名してはいけません。

${companyBlock(c)}

## 評価軸（固定）
${axes}

## 進め方

1. web_search で、対象企業と競合各社の${v.scoreSources}を調べる
2. 各軸について 0〜100 で採点し、**調べて分かった事実にもとづく根拠**を書く
3. 競合各社（${rivalNames.length ? rivalNames.join('、') : 'なし'}）も同じ軸で採点する
4. 事実が見つからず判断できない軸は 50 点とし、根拠に「公開情報からは確認できず」と明記する

## 採点の基準

- 50 を「同業の平均的な水準」とする
- 80 以上は、明確な根拠がある場合のみ
- 推測で高い点を付けない。**分からないことは分からないと書く**

## 打ち手

採点を踏まえ、この企業が次に取り組むべきことを 3〜6 個提案してください。スコアが低く、かつ自社の努力で動かせる軸を優先します。抽象論ではなく、**着手できる具体的な作業**として書いてください。

最後に、${v.audience}から見た現状を 4 文以内でまとめてください（強みと弱みの両方に触れる）。

以上を文章で出力してください。形式は問いません。`
}

// ---------------------------------------------------------------------
// 第2段：構造化（ツール呼び出しを強制・出力は JSON）
// ---------------------------------------------------------------------

export const CRITERIA_INSTRUCTION =
  '下の調査結果から、評価軸を抽出してツールに登録してください。重みの合計はちょうど 100 にしてください。'

export function scoringInstruction(criteriaNames: string[]) {
  return `下の調査結果から、採点結果・競合スコア・打ち手を抽出してツールに登録してください。

scores には次の軸を**すべて、この表記のまま**含めてください。軸を追加してはいけません。
${criteriaNames.map((n) => `- ${n}`).join('\n')}

調査結果に該当する記述がない軸は、score を 50、rationale を「公開情報からは確認できず」としてください。`
}

export const MENTION_INSTRUCTION =
  '下の回答内容から、言及状況を抽出してツールに登録してください。'

// ---------------------------------------------------------------------
// 点検表
// ---------------------------------------------------------------------

export function checklistResearch(
  c: CompanyInput,
  items: { key: string; category: string; title: string; check: string }[],
  product: Product = 'magnet',
  siteDump = ''
) {
  const v = VOICE[product]
  const list = items
    .map((i) => `### ${i.key}\n項目: ${i.title}\n見るところ: ${i.check}`)
    .join('\n\n')

  const probes = v.probes(c.name, c.industry || '')
    .map((q) => `「${q}」`)
    .join('、')

  // サイトの中身は取得済みのものを渡す。検索は外部の評判にだけ使う
  const siteSection = siteDump
    ? `## 取得済みのサイト内容

以下はこの企業のサイトを実際に取得したものです。**サイト内のことは、まずここを読んで判断してください。**
検索では分からないこと（見出しの文言、CTA の有無、フォームの項目数など）もここに載っています。

${siteDump}
`
    : ''

  return `あなたは${v.analyst}です。以下の企業について、点検項目を1つずつ確認してください。

${companyBlock(c)}

${siteSection}
## 外部の情報を調べる

web_search は、上のサイト内容では分からないことにだけ使ってください。

- 口コミ（Google、業界の口コミサイト）の件数・評価・返信状況
- 比較サイト、業界メディア、プレスリリースでの掲載
- ${probes}を検索し、AI や検索結果に何が出るか
- 競合として挙がっている会社との比較

## 判定の原則

**「確認できず」は最後の手段です。** サイトの内容が上にある以上、サイト内の項目で
unknown を返すのは、ほとんどの場合ただの手抜きです。次の順で判断してください。

1. 上のサイト内容に**書かれている** → その事実で判定する
2. 上のサイト内容を読んだが**見当たらない** → それは「無い」ということ。ng または partial にする。
   例：h1 が「(なし)」なら「h1 が未設定」であって「確認できず」ではない。
   料金ページが取得ページに無ければ「料金の記載が見当たらない」と判定してよい
3. サイトの外の話（口コミ・AI 言及・競合）で、検索しても出てこない → ここで初めて unknown

unknown を使うときは「なぜ判断できないか」を書いてください。「公開情報からは確認できず」
だけで済ませないこと。

## 根拠の書き方

根拠には、**実際に見た文言や数値をそのまま引用**してください。

- 良い例：「h1 は『図面1枚から、最短翌日お見積り』。数字と納期が入っており具体的」
- 良い例：「問い合わせフォームの入力欄が 9 個、うち必須 6 個。項目数が多い」
- 悪い例：「ファーストビューは改善の余地がある」（何を見たのか分からない）

## 直し方の書き方

「〜を改善する」ではなく、**そのまま作業指示になる粒度**で書いてください。

- 良い例：「h1 を『愛知の金属加工｜試作1個・最短翌日見積｜株式会社サンプル製作所』に変更する」
- 良い例：「問い合わせフォームの必須を 6 個から 3 個（会社名・メール・内容）に減らす」
- 悪い例：「SEO を強化する」

## 点検項目

${list}

以上の全項目について、判定と根拠、直し方を書いてください。key は必ず添えてください。`
}

export function checklistInstruction(keys: string[]) {
  return `下の点検結果から、各項目の判定を抽出してツールに登録してください。

results には次の key を**すべて、この表記のまま**含めてください。
${keys.join(', ')}

各項目には priority（high / medium / low）も付けてください。
その項目を直すことが、売上や問い合わせにどれだけ効くかで決めます。
weight が大きく、かつ status が ng のものが high になりやすいはずです。

点検結果に本当に記述が無い key だけ status を unknown にし、evidence には
「なぜ判断できなかったか」を書いてください。理由を書けないなら、それは
判断できるということなので、ng か partial を選んでください。

さらに findings には、**点検項目に無いが実際に見て気づいた問題**を挙げてください。
項目の数に縛られる必要はありません。そのサイト固有の問題ほど価値があります。
気づきが無ければ空配列で構いませんが、通常は 3〜10 件は出るはずです。`
}

// ---------------------------------------------------------------------
// コンテンツ案
// ---------------------------------------------------------------------

export function contentResearch(
  c: CompanyInput,
  weakPoints: string[],
  product: Product = 'magnet'
) {
  const v = VOICE[product]
  const designer = product === 'magnet' ? '採用広報のコンテンツ設計者' : 'ウェブマーケティングのコンテンツ設計者'
  const formats =
    product === 'magnet'
      ? '採用ブログ / note / X / Instagram / LinkedIn / YouTube / 採用サイト内ページ'
      : 'ブログ記事 / 導入事例 / 料金・比較ページ / よくある質問 / ホワイトペーパー / X / Instagram / YouTube'
  const readerExample =
    product === 'magnet'
      ? '在職中で情報収集段階の20代エンジニア'
      : '相見積もりを取り始めた段階の、従業員30名規模の製造業の担当者'

  const weak = weakPoints.length
    ? weakPoints.map((w) => `- ${w}`).join('\n')
    : '（点検結果がまだないため、一般的な観点で提案してください）'

  return `あなたは${designer}です。以下の企業が発信すべきネタを洗い出してください。

${companyBlock(c)}

## 点検で弱いと分かっている点
${weak}

## 進め方

1. web_search で、この企業と競合が現在発信している内容を確認する（重複を避けるため）
2. この業種の${v.audience}が実際に検索・AI に投げている質問を調べる
3. 競合が答えていない質問を探す。**そこが取れる場所**

## 提案の要件

20〜30 個出してください。それぞれについて次を明確にします。

- **そのまま使えるタイトル**。「〜について」のような仮題は不可
- **形式**（${formats}）
- **狙う質問**。${v.audience}が AI に投げる具体的な聞き方で書く
- **想定読者**。立場と状況で具体的に（例：${readerExample}）
- **骨子**を2〜3文

## 配分の考え方

- 半分以上は、上の「弱い点」を埋めるものにする
- 検索・AI から引用されやすい題材（数字、比較、手順、Q&A、事例）を優先する
- 単発の告知ではなく、**資産として残る**ものを選ぶ
- SNS 用は継続できる粒度にする（1投稿で完結する軽さ）

文章で出力してください。`
}

export const CONTENT_INSTRUCTION =
  '下の提案から、コンテンツ案を抽出してツールに登録してください。タイトルはそのまま使える形にしてください。'

// ---------------------------------------------------------------------
// AI 言及モニタリング
// ---------------------------------------------------------------------

/** 測定用の質問を作る。ここでだけ社名を使う（質問文には入れさせない）。 */
export function questionsResearch(c: CompanyInput, product: Product = 'magnet') {
  const v = VOICE[product]
  const designer = product === 'magnet' ? '採用市場の調査設計者' : '購買行動の調査設計者'
  const searcher = product === 'magnet' ? 'この業種・この職種の求職者' : 'この業種の見込み客'
  const asks =
    product === 'magnet'
      ? '「おすすめの会社」「働きやすい会社」「将来性のある会社」'
      : '「おすすめの業者」「信頼できる会社」「失敗しない選び方」'
  const byCondition =
    product === 'magnet'
      ? '〇〇県で△△の求人がある会社'
      : '〇〇県で△△に対応できる業者'
  const byCompare =
    product === 'magnet'
      ? '〇〇業界の大手と中小、どちらが良いか'
      : '〇〇を頼むなら専門業者と総合業者のどちらが良いか'

  return `あなたは${designer}です。次の企業が「AI に推薦されているか」を継続的に測るための質問を設計してください。

${companyBlock(c)}

## 重要な制約

**質問文に社名を入れないでください。** 社名を書くと「その会社を知っているか」を聞くことになり、「候補として挙がるか」を測れなくなります。${v.audience}が**まだその会社を知らない状態**で投げる質問にしてください。

## 質問の作り方

web_search で、${searcher}が実際にどう検索・質問しているかを調べてください。そのうえで 5〜7 個を設計します。

- 業種、地域、条件を組み合わせた自然な聞き方にする
- ${asks}など、**推薦を求める形**を中心にする
- 1つは条件検索型（例：${byCondition}）を入れる
- 1つは比較型（例：${byCompare}）を入れる
- この質問は今後ずっと同じものを使い続ける。**数年単位で有効な聞き方**にする

各質問について、それで何を測るのかも書いてください。`
}

export const QUESTIONS_INSTRUCTION =
  '下の設計から質問を抽出してツールに登録してください。question に社名が含まれていたら、社名を外した形に直してください。'

/** 実測。社名を一切出さずに、素の質問として投げる。 */
export function probePrompt(question: string, product: Product = 'magnet') {
  return `${question}

web_search で調べたうえで、${VOICE[product].audience}に向けて答えてください。具体的な企業名を挙げて説明してください。`
}

export function mentionInstruction(companyName: string) {
  return `下の回答文を読み、「${companyName}」がどう扱われたかを判定してツールに登録してください。

- 回答文に ${companyName} が登場したかどうかを、事実として判定する
- 表記ゆれ（正式名称、略称、英語表記）も同一企業として扱う
- 登場した場合、挙げられた企業のうち何番目かを数える
- 登場しなかった場合は mentioned を false、sentiment を absent とし、notes に代わりに挙がった企業名を書く
- competitors_named には、回答文に出てきた企業名を登場順に並べる`
}
