import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin, requireViewer, requireStaff, canSee } from '@/lib/supabaseAdmin'
import { research, structure, claudeAvailable, friendlyError, modelName, SCORING_SCHEMA } from '@/lib/claude'
import { scoringResearch, scoringInstruction } from '@/lib/prompts'
import { toProduct } from '@/lib/checklist'

export const dynamic = 'force-dynamic'
export const maxDuration = 300

const fail = (message: string, status: number) => NextResponse.json({ error: message }, { status })

/** 履歴を返す。詳細が必要なときは ?id= で 1 件だけ取る。 */
export async function GET(req: NextRequest) {
  const auth = await requireViewer(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const url = new URL(req.url)
  const id = url.searchParams.get('id')
  const companyId = url.searchParams.get('company_id')

  if (id) {
    const { data, error } = await supabaseAdmin
      .from('assessments')
      .select('*, assessment_criteria(*), competitor_scores(*)')
      .eq('id', id)
      .single()
    if (error) return fail(error.message, 500)
    if (!canSee(auth.viewer, data.company_id)) return fail('閲覧する権限がありません', 403)
    return NextResponse.json(data)
  }

  if (!companyId) return fail('company_id が必要です', 400)
  if (!canSee(auth.viewer, companyId)) return fail('閲覧する権限がありません', 403)

  const { data, error } = await supabaseAdmin
    .from('assessments')
    .select('*, assessment_criteria(name, score, weight, rationale, sort_order), competitor_scores(competitor_name, criteria_name, score)')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false })
    .limit(30)

  if (error) return fail(error.message, 500)
  return NextResponse.json(data ?? [])
}

/** 採点を実行する */
export async function POST(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)
  if (!claudeAvailable()) return fail('ANTHROPIC_API_KEY が設定されていません', 501)

  const body = await req.json().catch(() => ({}))
  const companyId = String(body.company_id || '')
  if (!companyId) return fail('company_id が必要です', 400)

  const { data: company } = await supabaseAdmin
    .from('companies')
    .select('*, competitors(name, website, sort_order)')
    .eq('id', companyId)
    .single()
  if (!company) return fail('会社が見つかりません', 404)

  const { data: set } = await supabaseAdmin
    .from('criteria_sets')
    .select('*, criteria_set_items(id, name, description, weight, sort_order)')
    .eq('company_id', companyId)
    .eq('active', true)
    .maybeSingle()

  const axes = (set?.criteria_set_items ?? []).sort((a: any, b: any) => a.sort_order - b.sort_order)
  if (axes.length === 0) {
    return fail('先に評価軸を作成してください', 400)
  }

  let result: any
  const model = modelName()
  try {
    const notes = await research(
      scoringResearch(
        {
          name: company.name,
          website: company.website,
          industry: company.industry,
          notes: company.notes,
          competitors: company.competitors ?? []
        },
        axes.map((a: any) => ({ name: a.name, description: a.description, weight: Number(a.weight) })),
        toProduct(company.product)
      )
    )
    result = await structure({
      notes,
      instruction: scoringInstruction(axes.map((a: any) => a.name)),
      toolName: 'register_assessment',
      schema: SCORING_SCHEMA as unknown as Record<string, unknown>
    })
  } catch (e) {
    return fail(friendlyError(e), 502)
  }

  // 軸名でスコアを引き当てる。指定した軸だけを採用し、増えた軸は捨てる。
  const byName = new Map<string, { score: number | null; rationale: string | null }>()
  for (const row of result.scores ?? []) {
    const name = String(row?.name || '').trim()
    if (!name) continue
    const score = Number(row?.score)
    byName.set(name, {
      score: Number.isFinite(score) ? Math.max(0, Math.min(100, score)) : null,
      rationale: String(row?.rationale || '').trim() || null
    })
  }

  type Scored = {
    name: string
    description: string | null
    weight: number
    score: number | null
    rationale: string | null
    sort_order: number
  }

  const scored: Scored[] = axes.map((axis: any, i: number) => {
    const hit = byName.get(axis.name)
    return {
      name: axis.name,
      description: axis.description,
      weight: Number(axis.weight),
      score: hit?.score ?? null,
      rationale: hit?.rationale ?? null,
      sort_order: i
    }
  })

  // 総合スコアはモデルではなくコードで計算する（毎回同じ計算・検算可能）
  const weighted = scored.filter((s) => s.score !== null)
  const totalWeight = weighted.reduce((sum, s) => sum + s.weight, 0)
  const overall =
    totalWeight > 0
      ? Math.round((weighted.reduce((sum, s) => sum + s.score! * s.weight, 0) / totalWeight) * 10) / 10
      : null

  const { data: assessment, error } = await supabaseAdmin
    .from('assessments')
    .insert({
      company_id: companyId,
      criteria_set_id: set!.id,
      status: 'complete',
      overall_score: overall,
      summary: String(result.summary || '').trim() || null,
      model,
      input_snapshot: {
        company: { name: company.name, website: company.website, industry: company.industry },
        competitors: (company.competitors ?? []).map((c: any) => c.name),
        criteria_version: set!.version
      },
      created_by: auth.viewer.id
    })
    .select()
    .single()

  if (error) return fail(error.message, 500)

  await supabaseAdmin
    .from('assessment_criteria')
    .insert(scored.map((s) => ({ ...s, assessment_id: assessment.id })))

  const rivalRows = (result.competitors ?? [])
    .map((row: any) => ({
      assessment_id: assessment.id,
      competitor_name: String(row?.competitor || '').trim(),
      criteria_name: String(row?.name || '').trim(),
      score: Number.isFinite(Number(row?.score)) ? Number(row.score) : null,
      rationale: String(row?.rationale || '').trim() || null
    }))
    .filter((r: any) => r.competitor_name && r.criteria_name)

  if (rivalRows.length > 0) {
    await supabaseAdmin.from('competitor_scores').insert(rivalRows)
  }

  // 打ち手を保存し、そのまま「やること」にも積む
  const recs = (result.recommendations ?? [])
    .map((r: any) => ({
      company_id: companyId,
      assessment_id: assessment.id,
      title: String(r?.title || '').trim(),
      detail: String(r?.detail || '').trim() || null,
      priority: ['high', 'medium', 'low'].includes(r?.priority) ? r.priority : 'medium',
      effort: String(r?.effort || '').trim() || null
    }))
    .filter((r: any) => r.title)

  if (recs.length > 0) {
    const { data: saved } = await supabaseAdmin.from('recommendations').insert(recs).select()

    if (saved?.length) {
      // 同じ見出しの未完了 TODO が既にあれば積み増さない
      const { data: existing } = await supabaseAdmin
        .from('todos')
        .select('title')
        .eq('company_id', companyId)
        .eq('done', false)

      const known = new Set((existing ?? []).map((t: any) => t.title))
      const todos = saved
        .filter((r: any) => !known.has(r.title))
        .map((r: any, i: number) => ({
          company_id: companyId,
          recommendation_id: r.id,
          title: r.title,
          detail: r.detail,
          priority: r.priority,
          source: 'auto',
          sort_order: i,
          created_by: auth.viewer.id
        }))

      if (todos.length > 0) await supabaseAdmin.from('todos').insert(todos)
    }
  }

  const { data: full } = await supabaseAdmin
    .from('assessments')
    .select('*, assessment_criteria(*), competitor_scores(*)')
    .eq('id', assessment.id)
    .single()

  return NextResponse.json(full, { status: 201 })
}
