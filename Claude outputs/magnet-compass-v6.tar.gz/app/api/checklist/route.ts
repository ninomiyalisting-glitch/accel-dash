import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin, requireViewer, requireStaff, canSee } from '@/lib/supabaseAdmin'
import { research, structure, claudeAvailable, friendlyError, modelName, CHECKLIST_SCHEMA } from '@/lib/claude'
import { checklistResearch, checklistInstruction } from '@/lib/prompts'
import { checklistFor, checklistByKey, toProduct, type ChecklistItem } from '@/lib/checklist'
import { runAutoChecks } from '@/lib/autochecks'
import { runCompassAutoChecks } from '@/lib/autochecks-compass'
import { crawlSite, crawlToPrompt } from '@/lib/crawl'
import { groupsFor } from '@/lib/checklistGroups'

export const dynamic = 'force-dynamic'
export const maxDuration = 800

const fail = (message: string, status: number) => NextResponse.json({ error: message }, { status })

const WEIGHT_OF_STATUS: Record<string, number> = { ok: 1, partial: 0.5, ng: 0, unknown: 0 }

/**
 * Claude が優先度を付けなかったときの既定値。
 * 満たしている項目に「今すぐ直せ」は付けない。重い項目が未対応なら high。
 */
function priorityOf(item: ChecklistItem, status: string): 'high' | 'medium' | 'low' {
  if (status === 'ok') return 'low'
  if (item.weight === 3) return status === 'ng' ? 'high' : 'medium'
  if (item.weight === 2) return status === 'ng' ? 'medium' : 'low'
  return 'low'
}

/** 最新の点検結果を返す */
export async function GET(req: NextRequest) {
  const auth = await requireViewer(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const companyId = new URL(req.url).searchParams.get('company_id')
  if (!companyId) return fail('company_id が必要です', 400)
  if (!canSee(auth.viewer, companyId)) return fail('閲覧する権限がありません', 403)

  // どの点検表を返すかは会社の製品で決まる
  const { data: companyRow } = await supabaseAdmin
    .from('companies')
    .select('product')
    .eq('id', companyId)
    .maybeSingle()
  const product = toProduct(companyRow?.product)
  const items = checklistFor(product)

  const { data: run } = await supabaseAdmin
    .from('checklist_runs')
    .select('*')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle()

  if (!run) return NextResponse.json({ run: null, results: [], items, product })

  const [{ data: results }, { data: found }] = await Promise.all([
    supabaseAdmin.from('checklist_results').select('*').eq('run_id', run.id),
    supabaseAdmin
      .from('checklist_findings')
      .select('*')
      .eq('run_id', run.id)
      .order('priority')
      .order('created_at'),
  ])

  return NextResponse.json({ run, results: results ?? [], items, product, findings: found ?? [] })
}

/** 点検を実行する。カテゴリごとに分けて呼ぶことで、1回の応答を扱える大きさに保つ。 */
export async function POST(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)
  if (!claudeAvailable()) return fail('ANTHROPIC_API_KEY が設定されていません', 501)

  const body = await req.json().catch(() => ({}))
  const companyId = String(body.company_id || '')
  if (!companyId) return fail('company_id が必要です', 400)

  const { data: company } = await supabaseAdmin
    .from('companies')
    .select('*, competitors(name, website, sort_order)')
    .eq('id', companyId)
    .single()
  if (!company) return fail('会社が見つかりません', 404)

  // 製品ごとに点検表もプロンプトも変わる。ここで一度だけ決める
  const product = toProduct(company.product)
  const CHECKLIST = checklistFor(product)
  const CHECKLIST_BY_KEY = checklistByKey(product)

  const input = {
    name: company.name,
    website: company.website,
    industry: company.industry,
    notes: company.notes,
    competitors: company.competitors ?? []
  }

  // 差分点検：変わりやすい項目と、前回 ok でなかった項目だけを再確認する。
  // 変わらないものを毎回調べ直さないことが、費用を下げる一番効く手。
  const diffMode = Boolean(body.diff)
  let previous = new Map<string, { status: string; evidence: string | null; fix: string | null }>()

  if (diffMode) {
    const { data: lastRun } = await supabaseAdmin
      .from('checklist_runs')
      .select('id')
      .eq('company_id', companyId)
      .eq('product', product)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()

    if (lastRun) {
      const { data: rows } = await supabaseAdmin
        .from('checklist_results')
        .select('item_key, status, evidence, fix')
        .eq('run_id', lastRun.id)
      previous = new Map((rows ?? []).map((r: any) => [r.item_key, r]))
    }
  }

  // ── 1. コードで判定できる項目（無料・確実）────────────────────
  // 製品ごとに見るところが違うので実装も分けている
  const auto =
    product === 'compass'
      ? await runCompassAutoChecks(company.website)
      : await runAutoChecks(company.website)

  // ── 2. LLM に回す項目を絞る ──────────────────────────────────
  const needsLlm = CHECKLIST.filter((item: ChecklistItem) => {
    if (item.auto) return false // コードで判定済み
    if (!diffMode) return true
    if (item.volatile) return true // 変わりやすいので毎回見る
    const before = previous.get(item.key)
    return !before || before.status !== 'ok' // 未達のものは進捗を確認する
  })

  const collected: {
    key: string
    status: string
    evidence: string
    fix?: string
    priority?: string
  }[] = []
  const findings: Record<string, unknown>[] = []
  const model = modelName()

  // ── 2.5 サイトを実際に読む ───────────────────────────────────
  // 検索結果のスニペットだけでは、見出しの文言も CTA の有無も分からない。
  // ここで取得した本文をプロンプトに載せることで「確認できず」を減らす。
  const crawl = await crawlSite(company.website)
  const siteDump = crawlToPrompt(crawl)

  /**
   * 1 ページも読めなかったら、そこで中止する。
   *
   * サイトが読めない状態で続けても、サイト内の項目はすべて「確認できず」に
   * しかならない。実際にそれで 46 項目が unknown のまま保存され、API 費用だけが
   * かかった。判定できないことが分かった時点で止め、何が起きたかを返す。
   */
  if (crawl.pages.length === 0 && company.website) {
    const why = crawl.failed.map((f) => `${f.url}（${f.reason}）`).join(' / ')
    return fail(
      `サイトを取得できなかったため点検を中止しました。${why || '原因不明'}。` +
        `URL が正しいか、サイトが公開されているかを確認してください。`,
      502
    )
  }

  if (needsLlm.length > 0) {
    // タブの分類ごとに分けて呼ぶ。1 回で 70 項目を見させると 1 項目あたりの
    // 密度が落ち、根拠が薄くなる。分類ごとなら調べる先も揃うので無駄も少ない。
    const groups = groupsFor(product, Array.from(new Set(CHECKLIST.map((i: ChecklistItem) => i.category))))
    const buckets: { label: string; items: ChecklistItem[] }[] = []
    for (const g of groups) {
      const mine = needsLlm.filter((i: ChecklistItem) => g.categories.includes(i.category))
      if (mine.length > 0) buckets.push({ label: g.label, items: mine })
    }
    // どの分類にも入らなかったものの取りこぼし防止
    const claimed = new Set(buckets.flatMap((b) => b.items.map((i) => i.key)))
    const orphans = needsLlm.filter((i: ChecklistItem) => !claimed.has(i.key))
    if (orphans.length > 0) buckets.push({ label: 'その他', items: orphans })

    try {
      for (const bucket of buckets) {
        const notes = await research(
          checklistResearch(
            input,
            bucket.items.map((i) => ({
              key: i.key,
              category: i.category,
              title: i.title,
              check: i.check,
            })),
            product,
            siteDump
          ),
          { maxTokens: 8000, maxSearches: diffMode ? 3 : 5 }
        )
        const structured = await structure<{ results: any[]; findings?: any[] }>({
          notes,
          instruction: checklistInstruction(bucket.items.map((i) => i.key)),
          toolName: 'register_checklist',
          schema: CHECKLIST_SCHEMA as unknown as Record<string, unknown>,
        })
        collected.push(...(structured.results ?? []))
        for (const f of structured.findings ?? []) {
          findings.push({ ...f, group: bucket.label })
        }
      }
    } catch (e) {
      return fail(friendlyError(e), 502)
    }
  }

  const byKey = new Map(collected.map((r) => [String(r.key), r]))

  const rows = CHECKLIST.map((item: ChecklistItem) => {
    // コード判定を最優先
    const autoHit = auto[item.key]
    if (item.auto && autoHit) {
      return {
        company_id: companyId,
        item_key: item.key,
        status: autoHit.status,
        evidence: autoHit.evidence,
        fix: autoHit.fix ?? null,
        priority: priorityOf(item, autoHit.status)
      }
    }

    const hit = byKey.get(item.key)
    if (hit) {
      const status = ['ok', 'partial', 'ng', 'unknown'].includes(hit.status) ? hit.status : 'unknown'
      return {
        company_id: companyId,
        item_key: item.key,
        status,
        evidence: hit.evidence?.trim() || '公開情報からは確認できず',
        fix: hit.fix?.trim() || null,
        // Claude が付けた優先度を使う。ただし満たしている項目に「最優先」は付けない
        // （Claude が状態と優先度で食い違う値を返すことがあるため、ここで正す）
        priority:
          status === 'ok'
            ? 'low'
            : ['high', 'medium', 'low'].includes(String(hit.priority))
              ? String(hit.priority)
              : priorityOf(item, status)
      }
    }

    // 差分点検で再確認しなかった項目は、前回の判定をそのまま引き継ぐ
    const before = previous.get(item.key)
    if (before) {
      return {
        company_id: companyId,
        item_key: item.key,
        status: before.status,
        evidence: before.evidence || '前回の点検結果を引き継ぎ',
        fix: before.fix,
        priority: priorityOf(item, before.status)
      }
    }

    return {
      company_id: companyId,
      item_key: item.key,
      status: 'unknown',
      evidence: '公開情報からは確認できず',
      fix: null,
      priority: priorityOf(item, 'unknown')
    }
  })

  // 達成率は重み付きでコード側で計算する（毎回同じ計算になり、後から検算できる）
  const totalWeight = CHECKLIST.reduce((sum: number, i: ChecklistItem) => sum + i.weight, 0)
  const gained = rows.reduce((sum: number, row: { item_key: string; status: string }) => {
    const item = CHECKLIST_BY_KEY.get(row.item_key)!
    return sum + item.weight * (WEIGHT_OF_STATUS[row.status] ?? 0)
  }, 0)
  const score = Math.round((gained / totalWeight) * 1000) / 10
  const okCount = rows.filter((r: { status: string }) => r.status === 'ok').length

  const { data: run, error } = await supabaseAdmin
    .from('checklist_runs')
    .insert({
      company_id: companyId,
      product,
      ok_count: okCount,
      total_count: CHECKLIST.length,
      score,
      model,
      created_by: auth.viewer.id
    })
    .select()
    .single()

  if (error) return fail(error.message, 500)

  await supabaseAdmin
    .from('checklist_results')
    .insert(rows.map((r: Record<string, unknown>) => ({ ...r, run_id: run.id })))

  // 点検表に無い気づき。項目に紐づかないので別テーブルに入れる
  if (findings.length > 0) {
    const clean = findings
      .map((f) => ({
        run_id: run.id,
        company_id: companyId,
        title: String(f.title ?? '').trim().slice(0, 300),
        detail: String(f.detail ?? '').trim() || null,
        fix: String(f.fix ?? '').trim() || null,
        category: String(f.category ?? f.group ?? '').trim() || null,
        priority: ['high', 'medium', 'low'].includes(String(f.priority))
          ? String(f.priority)
          : 'medium',
      }))
      .filter((f) => f.title)
    if (clean.length > 0) await supabaseAdmin.from('checklist_findings').insert(clean)
  }

  const { data: results } = await supabaseAdmin
    .from('checklist_results')
    .select('*')
    .eq('run_id', run.id)
  const { data: found } = await supabaseAdmin
    .from('checklist_findings')
    .select('*')
    .eq('run_id', run.id)

  return NextResponse.json(
    { run, results: results ?? [], items: CHECKLIST, product, findings: found ?? [] },
    { status: 201 }
  )
}

/** 判定を手で上書きする、または「やること」に送る */
export async function PATCH(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const body = await req.json().catch(() => ({}))

  if (body.action === 'to_todo') {
    const keys: string[] = Array.isArray(body.keys) ? body.keys : []
    const companyId = String(body.company_id || '')
    if (!companyId || keys.length === 0) return fail('対象がありません', 400)

    // 「やること」の文面は点検項目から作るので、製品に合った表を引く
    const { data: companyRow } = await supabaseAdmin
      .from('companies')
      .select('product')
      .eq('id', companyId)
      .maybeSingle()
    const CHECKLIST_BY_KEY = checklistByKey(toProduct(companyRow?.product))

    const { data: existing } = await supabaseAdmin
      .from('todos')
      .select('title')
      .eq('company_id', companyId)
      .eq('done', false)
    const known = new Set((existing ?? []).map((t: any) => t.title))

    const { data: results } = await supabaseAdmin
      .from('checklist_results')
      .select('item_key, fix')
      .eq('company_id', companyId)
      .in('item_key', keys)
      .order('created_at', { ascending: false })

    const seen = new Set<string>()
    const todos: any[] = []
    for (const r of results ?? []) {
      if (seen.has(r.item_key)) continue
      seen.add(r.item_key)
      const item = CHECKLIST_BY_KEY.get(r.item_key)
      if (!item) continue
      const title = `${item.category}：${item.title}`
      if (known.has(title)) continue
      todos.push({
        company_id: companyId,
        title,
        detail: r.fix || item.check,
        priority: item.weight === 3 ? 'high' : item.weight === 2 ? 'medium' : 'low',
        source: 'auto',
        created_by: auth.viewer.id
      })
    }

    if (todos.length > 0) await supabaseAdmin.from('todos').insert(todos)
    return NextResponse.json({ added: todos.length })
  }

  const id = String(body.id || '')
  if (!id) return fail('id が必要です', 400)
  const status = String(body.status || '')
  if (!['ok', 'partial', 'ng', 'unknown'].includes(status)) return fail('status が不正です', 400)

  const { data, error } = await supabaseAdmin
    .from('checklist_results')
    .update({ status, manual: true })
    .eq('id', id)
    .select()
    .single()

  if (error) return fail(error.message, 500)
  return NextResponse.json(data)
}
