'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import { api } from '@/lib/client'
import Shell from '@/components/Shell'
import Notice, { NoticeState } from '@/components/Notice'
import { Globe, Plus, Trash2 } from 'lucide-react'
import ScoreTab, { type Assessment } from '@/components/ScoreTab'
import HistoryTab from '@/components/HistoryTab'
import ChecklistTab, { type ChecklistState } from '@/components/ChecklistTab'
import ContentTab, { type ContentIdea } from '@/components/ContentTab'
import MentionsTab, { type MentionState } from '@/components/MentionsTab'
import MembersPanel, { type Member } from '@/components/MembersPanel'
import type { Company, Competitor, Todo } from '@/lib/types'
import { PRODUCT_LABEL, toProduct } from '@/lib/checklist'
import { WORDING } from '@/lib/wording'

type Viewer = { id: string; email: string; isStaff: boolean; companyIds: string[] | null }
type Row = Company & { competitors: Competitor[] }
type Tab = 'score' | 'checklist' | 'content' | 'history' | 'mentions' | 'todos' | 'access'

export default function CompanyPage() {
  const router = useRouter()
  const params = useParams<{ id: string }>()
  const companyId = params.id

  const [viewer, setViewer] = useState<Viewer | null>(null)
  const [company, setCompany] = useState<Row | null>(null)
  const [todos, setTodos] = useState<Todo[]>([])
  const [loading, setLoading] = useState(true)
  const [notice, setNotice] = useState<NoticeState>(null)
  const [tab, setTab] = useState<Tab>('score')

  const [criteriaSet, setCriteriaSet] = useState<any>(null)
  const [history, setHistory] = useState<Assessment[]>([])
  const [checklist, setChecklist] = useState<ChecklistState>({ run: null, results: [], items: [] })
  const [ideas, setIdeas] = useState<ContentIdea[]>([])
  const [mentionState, setMentionState] = useState<MentionState>({ questions: [], mentions: [] })
  const [members, setMembers] = useState<Member[]>([])
  const [newTodo, setNewTodo] = useState('')
  const [adding, setAdding] = useState(false)

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId])

  async function load() {
    const { data } = await supabase.auth.getSession()
    if (!data.session) {
      router.push('/login')
      return
    }

    try {
      const res = await api<{ viewer: Viewer; company: Row }>(`/api/companies/${companyId}`)
      setViewer(res.viewer)
      setCompany(res.company)
      setTodos(await api<Todo[]>(`/api/todos?company_id=${companyId}`))
      const [set, runs, check, contentIdeas, mentions] = await Promise.all([
        api<any>(`/api/criteria?company_id=${companyId}`),
        api<Assessment[]>(`/api/assessments?company_id=${companyId}`),
        api<ChecklistState>(`/api/checklist?company_id=${companyId}`),
        api<ContentIdea[]>(`/api/content?company_id=${companyId}`),
        api<MentionState>(`/api/mentions?company_id=${companyId}`)
      ])
      setCriteriaSet(set)
      setHistory(runs)
      setChecklist(check)
      setIdeas(contentIdeas)
      setMentionState(mentions)

      if (res.viewer.isStaff) {
        try {
          setMembers(await api<Member[]>(`/api/members?company_id=${companyId}`))
        } catch {
          // 権限管理は補助的な情報なので、取得できなくても画面は開く
        }
      }
    } catch (e: any) {
      setNotice({ kind: 'ng', text: e.message })
    }
    setLoading(false)
  }

  async function refreshTodos() {
    try {
      setTodos(await api<Todo[]>(`/api/todos?company_id=${companyId}`))
    } catch (e: any) {
      setNotice({ kind: 'ng', text: e.message })
    }
  }

  async function addTodo() {
    if (!newTodo.trim()) return
    setAdding(true)
    try {
      const created = await api<Todo>('/api/todos', {
        method: 'POST',
        body: { company_id: companyId, title: newTodo }
      })
      setTodos([created, ...todos])
      setNewTodo('')
    } catch (e: any) {
      setNotice({ kind: 'ng', text: e.message })
    }
    setAdding(false)
  }

  async function toggleTodo(todo: Todo) {
    // 先に画面を切り替えてから保存する（打ち消し線が即時に出るように）
    setTodos((prev) => prev.map((t) => (t.id === todo.id ? { ...t, done: !t.done } : t)))
    try {
      await api<Todo>('/api/todos', { method: 'PATCH', body: { id: todo.id, done: !todo.done } })
    } catch (e: any) {
      setTodos((prev) => prev.map((t) => (t.id === todo.id ? { ...t, done: todo.done } : t)))
      setNotice({ kind: 'ng', text: e.message })
    }
  }

  async function removeTodo(id: string) {
    const before = todos
    setTodos(todos.filter((t) => t.id !== id))
    try {
      await api(`/api/todos?id=${id}`, { method: 'DELETE' })
    } catch (e: any) {
      setTodos(before)
      setNotice({ kind: 'ng', text: e.message })
    }
  }

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center">読み込み中…</div>
  }

  if (!company) {
    return (
      <Shell email={viewer?.email} isStaff={viewer?.isStaff}>
        <Notice notice={notice} onClose={() => setNotice(null)} />
        <p className="text-black/70">会社が見つかりませんでした。</p>
      </Shell>
    )
  }

  const isStaff = Boolean(viewer?.isStaff)
  const open = todos.filter((t) => !t.done)
  const done = todos.filter((t) => t.done)

  const pendingChecks = checklist.results.filter(
    (r) => r.status === 'ng' || r.status === 'partial'
  ).length
  const freshIdeas = ideas.filter((i) => !i.used).length

  const tabs: { key: Tab; label: string }[] = [
    { key: 'score', label: 'スコア' },
    { key: 'checklist', label: `点検表${pendingChecks ? `（${pendingChecks}）` : ''}` },
    { key: 'content', label: `ネタ${freshIdeas ? `（${freshIdeas}）` : ''}` },
    { key: 'history', label: '推移' },
    { key: 'mentions', label: 'AI 言及' },
    { key: 'todos', label: `やること${open.length ? `（${open.length}）` : ''}` },
    ...(isStaff ? [{ key: 'access' as Tab, label: 'アクセス権' }] : [])
  ]

  return (
    <Shell email={viewer?.email} isStaff={viewer?.isStaff}>
      <Notice notice={notice} onClose={() => setNotice(null)} />

      <div className="mb-8">
        <div className="mb-1 flex flex-wrap items-center gap-3">
          <h1 className="m-0">{company.name}</h1>
          <span className="rounded-full bg-accel-lightest px-3 py-1 text-sm font-semibold text-accel-deep">
            {PRODUCT_LABEL[toProduct(company.product)]}
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-4 text-sm text-black/60">
          {company.industry && <span>{company.industry}</span>}
          {company.website && (
            <a href={company.website} className="flex items-center gap-1.5">
              <Globe size={14} />
              {company.website.replace(/^https?:\/\//, '')}
            </a>
          )}
          <span>競合 {company.competitors?.length ?? 0} 社</span>
        </div>
      </div>

      <div className="mb-8 flex gap-2 overflow-x-auto border-b border-border-soft">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={
              tab === t.key
                ? 'shrink-0 border-b-2 border-accel-primary px-5 py-3'
                : 'shrink-0 border-b-2 border-transparent px-5 py-3 text-black/50 hover:text-black'
            }
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'score' && (
        <ScoreTab
          companyId={companyId}
          product={toProduct(company.product)}
          isStaff={isStaff}
          criteriaSet={criteriaSet}
          latest={history[0] ?? null}
          onCriteriaChange={(set) => setCriteriaSet(set)}
          onScored={async (assessment) => {
            setHistory([assessment, ...history])
            setTodos(await api<Todo[]>(`/api/todos?company_id=${companyId}`))
            setNotice({ kind: 'ok', text: '採点しました。打ち手は「やること」に追加されています。' })
          }}
          onError={(message) => setNotice({ kind: 'ng', text: message })}
        />
      )}

      {tab === 'checklist' && (
        <ChecklistTab
          companyId={companyId}
          product={toProduct(company.product)}
          isStaff={isStaff}
          state={checklist}
          onState={setChecklist}
          onTodosChanged={refreshTodos}
          onError={(m) => setNotice({ kind: 'ng', text: m })}
          onNotice={(m) => setNotice({ kind: 'ok', text: m })}
        />
      )}

      {tab === 'content' && (
        <ContentTab
          companyId={companyId}
          product={toProduct(company.product)}
          isStaff={isStaff}
          ideas={ideas}
          onIdeas={setIdeas}
          onTodosChanged={refreshTodos}
          onError={(m) => setNotice({ kind: 'ng', text: m })}
          onNotice={(m) => setNotice({ kind: 'ok', text: m })}
        />
      )}

      {tab === 'history' && <HistoryTab history={history} />}

      {tab === 'mentions' && (
        <MentionsTab
          companyId={companyId}
          product={toProduct(company.product)}
          isStaff={isStaff}
          state={mentionState}
          onState={setMentionState}
          onError={(m) => setNotice({ kind: 'ng', text: m })}
          onNotice={(m) => setNotice({ kind: 'ok', text: m })}
        />
      )}

      {tab === 'access' && isStaff && (
        <MembersPanel
          companyId={companyId}
          members={members}
          onMembers={setMembers}
          onError={(m) => setNotice({ kind: 'ng', text: m })}
          onNotice={(m) => setNotice({ kind: 'ok', text: m })}
        />
      )}

      {tab === 'todos' && (
        <section>
          {isStaff && (
            <div className="mb-6 flex flex-wrap gap-3 rounded-2xl border border-border-soft bg-surface p-6">
              <input
                type="text"
                value={newTodo}
                onChange={(e) => setNewTodo(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addTodo()}
                placeholder={WORDING[toProduct(company.product)].todoPlaceholder}
                className="min-w-[240px] flex-1"
              />
              <button
                onClick={addTodo}
                disabled={adding}
                className="flex items-center gap-2 rounded-lg bg-accel-primary px-6 py-3 text-white hover:bg-accel-hover active:bg-accel-active"
              >
                <Plus size={18} />
                {adding ? '追加中…' : '追加'}
              </button>
            </div>
          )}

          {todos.length === 0 ? (
            <p className="text-black/70">やることはまだありません。</p>
          ) : (
            <div className="flex flex-col gap-6">
              <ul className="flex flex-col gap-2">
                {open.map((todo) => (
                  <TodoRow
                    key={todo.id}
                    todo={todo}
                    isStaff={isStaff}
                    onToggle={toggleTodo}
                    onRemove={removeTodo}
                  />
                ))}
              </ul>

              {done.length > 0 && (
                <div>
                  <h3 className="mb-3 text-black/50">完了（{done.length}）</h3>
                  <ul className="flex flex-col gap-2">
                    {done.map((todo) => (
                      <TodoRow
                        key={todo.id}
                        todo={todo}
                        isStaff={isStaff}
                        onToggle={toggleTodo}
                        onRemove={removeTodo}
                      />
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </section>
      )}
    </Shell>
  )
}

function TodoRow({
  todo,
  isStaff,
  onToggle,
  onRemove
}: {
  todo: Todo
  isStaff: boolean
  onToggle: (t: Todo) => void
  onRemove: (id: string) => void
}) {
  return (
    <li className="flex items-start gap-3 rounded-xl border border-border-soft bg-surface px-5 py-4">
      <input
        type="checkbox"
        checked={todo.done}
        onChange={() => onToggle(todo)}
        disabled={!isStaff}
        aria-label={todo.done ? '未完了に戻す' : '完了にする'}
        className="mt-1.5 h-5 w-5 shrink-0 accent-accel-primary"
        style={{ minHeight: 'auto', width: '20px', padding: 0 }}
      />
      <div className="min-w-0 flex-1">
        <p className={todo.done ? 'text-black/40 line-through' : ''}>{todo.title}</p>
        {todo.detail && (
          <p className={todo.done ? 'text-sm text-black/30 line-through' : 'text-sm text-black/70'}>
            {todo.detail}
          </p>
        )}
        <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-black/50">
          {todo.source === 'auto' && (
            <span className="rounded bg-accel-lightest px-2 py-0.5 text-black/70">AI 提案</span>
          )}
          {todo.due_on && <span>期限 {todo.due_on}</span>}
        </div>
      </div>
      {isStaff && (
        <button
          onClick={() => onRemove(todo.id)}
          aria-label="削除"
          className="shrink-0 rounded-lg p-2 text-red-600 hover:bg-red-50"
        >
          <Trash2 size={16} />
        </button>
      )}
    </li>
  )
}
