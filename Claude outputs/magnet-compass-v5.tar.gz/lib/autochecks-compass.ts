/**
 * 集客版（コンパス）のうち、コードで確実に判定できる項目。
 *
 * 判定の基準は「HTML と HTTP 応答だけで、人の解釈を挟まず決まるか」。
 * 訴求が具体的か、CTA の文言が適切か、といった良し悪しの判断は
 * ここでは扱わず LLM に回す（点検表側で auto を付けない）。
 *
 * 判定できなかったものは unknown を返す。呼び出し側はそれを見て
 * LLM の判定に委ねる。
 */
import type { AutoResult } from './autochecks'

const TIMEOUT_MS = 8000
const AI_CRAWLERS = ['GPTBot', 'ClaudeBot', 'anthropic-ai', 'PerplexityBot', 'Google-Extended']

async function get(url: string) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS)
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: { 'User-Agent': 'AccelDash-Compass/1.0 (marketing audit)' },
    })
    const body = res.ok ? await res.text() : ''
    return { ok: res.ok, status: res.status, body, finalUrl: res.url }
  } catch {
    return { ok: false, status: 0, body: '', finalUrl: url }
  } finally {
    clearTimeout(timer)
  }
}

function originOf(website: string): string | null {
  try {
    return new URL(website.startsWith('http') ? website : `https://${website}`).origin
  } catch {
    return null
  }
}

/** <head> の中だけを取り出す。本文の記述を head の判定に混ぜないため */
function headOf(html: string): string {
  const m = html.match(/<head[^>]*>([\s\S]*?)<\/head>/i)
  return m ? m[1] : html.slice(0, 40000)
}

/** 正規表現の 1 個目のキャプチャを返す */
function firstMatch(source: string, re: RegExp): string | null {
  const m = source.match(re)
  return m ? m[1] : null
}

/** content 属性は name の前後どちらにも書けるので両方の並びを試す */
function metaContent(head: string, name: string): string | null {
  const before = new RegExp(
    `<meta[^>]+(?:name|property)=["']${name}["'][^>]*content=["']([^"']*)["']`,
    'i'
  )
  const after = new RegExp(
    `<meta[^>]+content=["']([^"']*)["'][^>]*(?:name|property)=["']${name}["']`,
    'i'
  )
  return decodeEntities(firstMatch(head, before) ?? firstMatch(head, after))
}

function decodeEntities(v: string | null): string | null {
  if (v == null) return null
  return v
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .trim()
}

/** タグを除いた本文。長さや文字数の判定に使う */
function textOf(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

export const COMPASS_AUTO_KEYS = [
  'seo-title',
  'seo-description',
  'seo-h1',
  'seo-structured',
  'seo-canonical',
  'seo-crawl',
  'seo-https-mobile',
  'seo-alt',
  'ai-crawler',
  'track-ga4',
  'track-gtm',
  'cta-tel',
  'form-privacy',
  'vs-pages',
  'vs-speed',
] as const

export async function runCompassAutoChecks(
  website: string | null
): Promise<Record<string, AutoResult>> {
  const out: Record<string, AutoResult> = {}
  const fillAll = (status: AutoResult['status'], evidence: string) => {
    for (const key of COMPASS_AUTO_KEYS) out[key] = { status, evidence }
    return out
  }

  if (!website) return fillAll('unknown', 'サイト URL が未登録のため自動判定できず')

  const origin = originOf(website)
  if (!origin) return fillAll('unknown', `サイト URL の形式が不正：${website}`)

  const [home, robots, sitemap] = await Promise.all([
    get(website.startsWith('http') ? website : `https://${website}`),
    get(`${origin}/robots.txt`),
    get(`${origin}/sitemap.xml`),
  ])

  if (!home.ok) {
    return fillAll('unknown', `サイトを取得できませんでした（HTTP ${home.status || '接続失敗'}）`)
  }

  const head = headOf(home.body)
  const body = home.body

  // ── title ──────────────────────────────────────────────────
  const title = decodeEntities(firstMatch(head, /<title[^>]*>([\s\S]*?)<\/title>/i))
  if (!title) {
    out['seo-title'] = {
      status: 'ng',
      evidence: 'title タグがありません',
      fix: 'トップページに、何の会社かが分かる title を設定する',
    }
  } else if (title.length < 10 || title.length > 60) {
    out['seo-title'] = {
      status: 'partial',
      evidence: `title は「${title}」（${title.length}文字）。検索結果では 30 文字前後までしか表示されない`,
      fix: '30〜60 文字に収め、事業内容が分かる語を前半に置く',
    }
  } else {
    out['seo-title'] = { status: 'ok', evidence: `title は「${title}」（${title.length}文字）` }
  }

  // ── meta description ───────────────────────────────────────
  const desc = metaContent(head, 'description')
  if (!desc) {
    out['seo-description'] = {
      status: 'ng',
      evidence: 'meta description がありません',
      fix: '検索結果に出る説明文を 80〜120 文字で書く',
    }
  } else if (desc.length < 50) {
    out['seo-description'] = {
      status: 'partial',
      evidence: `description が ${desc.length} 文字と短い：「${desc.slice(0, 40)}…」`,
      fix: '80〜120 文字にして、誰に何を提供するかを入れる',
    }
  } else {
    out['seo-description'] = { status: 'ok', evidence: `description は ${desc.length} 文字` }
  }

  // ── h1 ─────────────────────────────────────────────────────
  const h1s = Array.from(body.matchAll(/<h1[^>]*>([\s\S]*?)<\/h1>/gi)).map((m) =>
    textOf(m[1]).trim()
  )
  if (h1s.length === 0) {
    out['seo-h1'] = {
      status: 'ng',
      evidence: 'h1 がありません',
      fix: 'ページの主題を表す h1 を 1 つ置く',
    }
  } else if (h1s.length > 1) {
    out['seo-h1'] = {
      status: 'partial',
      evidence: `h1 が ${h1s.length} 個あります：${h1s.slice(0, 3).join(' / ')}`,
      fix: 'h1 は 1 ページに 1 つにし、他は h2 以下にする',
    }
  } else {
    out['seo-h1'] = { status: 'ok', evidence: `h1 は「${h1s[0].slice(0, 60)}」` }
  }

  // ── 構造化データ ───────────────────────────────────────────
  const ldTypes = new Set<string>()
  for (const m of body.matchAll(
    /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi
  )) {
    for (const t of m[1].matchAll(/"@type"\s*:\s*"([^"]+)"/g)) ldTypes.add(t[1])
  }
  out['seo-structured'] = ldTypes.size
    ? { status: 'ok', evidence: `JSON-LD あり：${Array.from(ldTypes).join(', ')}` }
    : {
        status: 'ng',
        evidence: 'JSON-LD による構造化データがありません',
        fix: 'Organization と、該当すれば LocalBusiness / Service / FAQPage を入れる',
      }

  // ── canonical ──────────────────────────────────────────────
  const canonical = firstMatch(head, /<link[^>]+rel=["']canonical["'][^>]*href=["']([^"']+)["']/i)
  out['seo-canonical'] = canonical
    ? { status: 'ok', evidence: `canonical: ${canonical}` }
    : {
        status: 'partial',
        evidence: 'canonical が指定されていません',
        fix: '同じ内容が複数 URL で開ける場合に評価が分散する。canonical を入れる',
      }

  // ── クロールできるか ───────────────────────────────────────
  const noindex = /<meta[^>]+name=["']robots["'][^>]*content=["'][^"']*noindex/i.test(head)
  if (noindex) {
    out['seo-crawl'] = {
      status: 'ng',
      evidence: 'トップページに noindex が指定されています。検索結果に出ません',
      fix: '公開したいページから noindex を外す',
    }
  } else if (robots.ok && /^disallow:\s*\/\s*$/im.test(robots.body.split(/\n(?=user-agent:)/i)[0] ?? '')) {
    out['seo-crawl'] = {
      status: 'ng',
      evidence: 'robots.txt でサイト全体が Disallow になっています',
      fix: 'robots.txt の Disallow: / を外す',
    }
  } else {
    out['seo-crawl'] = {
      status: 'ok',
      evidence: robots.ok ? 'noindex なし。robots.txt も全体拒否なし' : 'noindex なし（robots.txt はなし＝全許可）',
    }
  }

  // ── HTTPS と スマホ対応 ────────────────────────────────────
  const isHttps = home.finalUrl.startsWith('https://')
  const hasViewport = /<meta[^>]+name=["']viewport["']/i.test(head)
  if (isHttps && hasViewport) {
    out['seo-https-mobile'] = { status: 'ok', evidence: 'HTTPS・viewport ともに設定あり' }
  } else {
    const missing = [!isHttps && 'HTTPS 化', !hasViewport && 'viewport 指定'].filter(Boolean)
    out['seo-https-mobile'] = {
      status: isHttps || hasViewport ? 'partial' : 'ng',
      evidence: `未対応：${missing.join('、')}`,
      fix: missing.join('、') + 'を行う',
    }
  }

  // ── 画像の alt ─────────────────────────────────────────────
  const imgs = Array.from(body.matchAll(/<img\b[^>]*>/gi)).map((m) => m[0])
  if (imgs.length === 0) {
    out['seo-alt'] = { status: 'unknown', evidence: 'img タグが見つかりませんでした（遅延読込の可能性）' }
  } else {
    const withAlt = imgs.filter((t) => /\balt\s*=/i.test(t)).length
    const ratio = Math.round((withAlt / imgs.length) * 100)
    out['seo-alt'] =
      ratio >= 90
        ? { status: 'ok', evidence: `img ${imgs.length} 件中 ${withAlt} 件に alt（${ratio}%）` }
        : {
            status: ratio >= 50 ? 'partial' : 'ng',
            evidence: `img ${imgs.length} 件中 alt があるのは ${withAlt} 件（${ratio}%）`,
            fix: '意味のある画像に alt を入れる。装飾画像は alt="" にする',
          }
  }

  // ── AI クローラーを拒否していないか ────────────────────────
  if (!robots.ok) {
    out['ai-crawler'] = {
      status: 'ok',
      evidence: 'robots.txt が無いため、AI クローラーも含め全て許可されている状態',
    }
  } else {
    const blocked: string[] = []
    for (const section of robots.body.split(/\n(?=user-agent:)/i)) {
      const agents = Array.from(section.matchAll(/^user-agent:\s*(.+)$/gim)).map((m) =>
        m[1].trim().toLowerCase()
      )
      if (!/^disallow:\s*\/\s*$/im.test(section)) continue
      for (const c of AI_CRAWLERS) if (agents.includes(c.toLowerCase())) blocked.push(c)
    }
    out['ai-crawler'] = blocked.length
      ? {
          status: 'ng',
          evidence: `robots.txt で拒否：${blocked.join(', ')}`,
          fix: 'AI の回答に出る可能性が消える。意図した設定でなければ解除する',
        }
      : { status: 'ok', evidence: 'robots.txt で AI クローラーを拒否していない' }
  }

  // ── 計測タグ ───────────────────────────────────────────────
  const hasGa4 = /gtag\/js\?id=G-|gtag\(\s*['"]config['"]\s*,\s*['"]G-/i.test(body)
  out['track-ga4'] = hasGa4
    ? { status: 'ok', evidence: 'GA4（G- 測定 ID）のタグを検出' }
    : {
        status: 'ng',
        evidence: 'GA4 のタグを検出できませんでした',
        fix: '計測が無いと改善の効果が判定できない。GA4 を入れる',
      }

  const hasGtm = /googletagmanager\.com\/gtm\.js|GTM-[A-Z0-9]+/i.test(body)
  out['track-gtm'] = hasGtm
    ? { status: 'ok', evidence: 'Google タグマネージャーを検出' }
    : {
        status: 'partial',
        evidence: 'タグマネージャーを検出できませんでした',
        fix: '必須ではないが、入れるとタグの追加が開発なしでできる',
      }

  // ── 電話番号のリンク ───────────────────────────────────────
  const hasTelLink = /href=["']tel:/i.test(body)
  const looksLikePhone = /0\d{1,4}[-(]\d{1,4}[-)]\d{3,4}/.test(textOf(body))
  if (hasTelLink) {
    out['cta-tel'] = { status: 'ok', evidence: 'tel: リンクあり。スマホからそのまま発信できる' }
  } else if (looksLikePhone) {
    out['cta-tel'] = {
      status: 'partial',
      evidence: '電話番号らしき記載はあるが tel: リンクになっていない',
      fix: '<a href="tel:0312345678"> にする。スマホでの発信が 1 タップになる',
    }
  } else {
    out['cta-tel'] = { status: 'unknown', evidence: 'トップページに電話番号を検出できませんでした' }
  }

  // ── プライバシーポリシーへの導線 ───────────────────────────
  const hasPrivacy = /プライバシー|個人情報|privacy/i.test(body)
  out['form-privacy'] = hasPrivacy
    ? { status: 'ok', evidence: 'プライバシーポリシーへの導線を検出' }
    : {
        status: 'ng',
        evidence: 'プライバシーポリシーへの導線を検出できませんでした',
        fix: 'フォーム付近に個人情報の扱いへのリンクを置く。無いと送信をためらわれる',
      }

  // ── ページ数（sitemap から） ───────────────────────────────
  if (sitemap.ok) {
    const urlCount = (sitemap.body.match(/<loc>/gi) ?? []).length
    const isIndex = /<sitemapindex/i.test(sitemap.body)
    out['vs-pages'] = {
      status: 'partial',
      evidence: isIndex
        ? `sitemap は索引形式で、子 sitemap が ${urlCount} 件。競合と比べてください`
        : `sitemap.xml のページ数は ${urlCount} 件。競合と比べてください`,
      fix: '競合より大幅に少なければ、検索で当たる面積が足りていない',
    }
  } else {
    out['vs-pages'] = {
      status: 'unknown',
      evidence: 'sitemap.xml が無く、ページ数を機械的に数えられませんでした',
      fix: 'sitemap.xml を用意すると、検索側にもページの全体像が伝わる',
    }
  }

  // ── 表示の重さ ─────────────────────────────────────────────
  const bytes = new TextEncoder().encode(home.body).length
  const kb = Math.round(bytes / 1024)
  const imgCount = imgs.length
  out['vs-speed'] = {
    status: kb <= 300 ? 'ok' : kb <= 800 ? 'partial' : 'ng',
    evidence: `トップページの HTML は ${kb}KB、img は ${imgCount} 件`,
    fix:
      kb > 300
        ? 'HTML が重い。画像の遅延読込、不要なスクリプトの削除を検討する'
        : undefined,
  }

  return out
}
