/**
 * サイトを実際に読みに行く。
 *
 * これまでは Web 検索の結果だけで点検していたため、
 * 「ファーストビューに CTA があるか」のようにページを見なければ
 * 分からない項目が軒並み「公開情報からは確認できず」になっていた。
 * 検索スニペットに載らない情報は、取りに行かないと分からない。
 *
 * 取得したページの本文をプロンプトに載せ、Claude に実物を読ませる。
 * 検索は口コミ・AI 言及・競合など、サイトの外にある情報にだけ使う。
 */

const TIMEOUT_MS = 10000
const UA = 'AccelDash-Compass/1.0 (site audit)'

/** 1 ページあたりに載せる本文の上限。長い記事で他ページを押し出さないため */
const MAX_TEXT_PER_PAGE = 3500
/** 取得するページ数の上限 */
const DEFAULT_MAX_PAGES = 14

export type CrawledPage = {
  url: string
  title: string
  description: string
  h1: string[]
  h2: string[]
  /** 本文（タグを除いたもの、先頭のみ） */
  text: string
  /** リンクの文言。CTA の判定に使う */
  linkLabels: string[]
  /** ボタンの文言 */
  buttonLabels: string[]
  /** フォームの入力欄の数と必須の数 */
  form: { fields: number; required: number } | null
  bytes: number
  status: number
}

export type CrawlResult = {
  pages: CrawledPage[]
  /** 取得を試みたが失敗した URL */
  failed: { url: string; reason: string }[]
  /** sitemap から分かった総ページ数（分かれば） */
  sitemapCount: number | null
}

async function get(url: string): Promise<{ ok: boolean; status: number; body: string; finalUrl: string }> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS)
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml,application/xml' },
    })
    const type = res.headers.get('content-type') ?? ''
    // HTML と XML 以外（PDF・画像など）は本文を読まない
    const readable = /text\/html|xml/i.test(type)
    return {
      ok: res.ok,
      status: res.status,
      body: res.ok && readable ? await res.text() : '',
      finalUrl: res.url,
    }
  } catch (e) {
    return { ok: false, status: 0, body: '', finalUrl: url }
  } finally {
    clearTimeout(timer)
  }
}

function stripTags(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim()
}

function allMatches(html: string, re: RegExp): string[] {
  return Array.from(html.matchAll(re))
    .map((m) => stripTags(m[1] ?? ''))
    .filter((t) => t.length > 0)
}

function parsePage(url: string, html: string, status: number): CrawledPage {
  const head = html.match(/<head[^>]*>([\s\S]*?)<\/head>/i)?.[1] ?? html.slice(0, 30000)

  const title = stripTags(head.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] ?? '')
  const description =
    head.match(/<meta[^>]+name=["']description["'][^>]*content=["']([^"']*)["']/i)?.[1] ??
    head.match(/<meta[^>]+content=["']([^"']*)["'][^>]*name=["']description["']/i)?.[1] ??
    ''

  // 入力欄の数（type=hidden は除く）
  const inputs = Array.from(html.matchAll(/<(input|textarea|select)\b[^>]*>/gi)).map((m) => m[0])
  const visible = inputs.filter((t) => !/type=["']hidden["']/i.test(t))
  const required = visible.filter((t) => /\brequired\b/i.test(t))
  const hasForm = /<form\b/i.test(html)

  return {
    url,
    title,
    description: stripTags(description),
    h1: allMatches(html, /<h1[^>]*>([\s\S]*?)<\/h1>/gi).slice(0, 5),
    h2: allMatches(html, /<h2[^>]*>([\s\S]*?)<\/h2>/gi).slice(0, 15),
    text: stripTags(html).slice(0, MAX_TEXT_PER_PAGE),
    linkLabels: Array.from(new Set(allMatches(html, /<a\b[^>]*>([\s\S]*?)<\/a>/gi)))
      .filter((t) => t.length <= 30)
      .slice(0, 40),
    buttonLabels: Array.from(new Set(allMatches(html, /<button\b[^>]*>([\s\S]*?)<\/button>/gi)))
      .filter((t) => t.length <= 30)
      .slice(0, 15),
    form: hasForm ? { fields: visible.length, required: required.length } : null,
    bytes: new TextEncoder().encode(html).length,
    status,
  }
}

/** sitemap.xml から URL を集める。索引形式なら子 sitemap も 1 段だけ辿る */
async function urlsFromSitemap(origin: string): Promise<{ urls: string[]; total: number | null }> {
  const first = await get(`${origin}/sitemap.xml`)
  if (!first.ok || !first.body) return { urls: [], total: null }

  const locs = (body: string) =>
    Array.from(body.matchAll(/<loc>\s*([^<\s]+)\s*<\/loc>/gi)).map((m) => m[1])

  if (/<sitemapindex/i.test(first.body)) {
    const children = locs(first.body).slice(0, 3)
    const all: string[] = []
    for (const child of children) {
      const res = await get(child)
      if (res.ok) all.push(...locs(res.body))
    }
    return { urls: all, total: all.length || null }
  }

  const urls = locs(first.body)
  return { urls, total: urls.length || null }
}

/** トップページのリンクから、同じドメインの主要ページを拾う */
function urlsFromHome(html: string, origin: string): string[] {
  const found: string[] = []
  for (const m of html.matchAll(/href=["']([^"']+)["']/gi)) {
    try {
      const abs = new URL(m[1], origin)
      if (abs.origin !== origin) continue
      abs.hash = ''
      const path = abs.pathname
      // 画像やファイルへのリンクは除く
      if (/\.(jpe?g|png|gif|svg|webp|pdf|zip|css|js|ico)$/i.test(path)) continue
      found.push(abs.toString())
    } catch {
      /* 無効な href は無視 */
    }
  }
  return Array.from(new Set(found))
}

/**
 * 点検で見たいページを優先的に選ぶ。
 * 料金・事例・問い合わせ・会社概要は、点検項目が集中するので必ず見に行く。
 */
const PRIORITY = [
  /price|pricing|plan|ryokin|料金|費用/i,
  /contact|inquiry|form|otoiawase|問い合わせ|問合せ/i,
  /case|works|jirei|voice|事例|実績|お客様/i,
  /company|about|profile|会社|概要/i,
  /service|product|サービス/i,
  /faq|qa|よくある/i,
  /recruit|saiyo|採用/i,
  /blog|news|column|お知らせ/i,
]

function pickUrls(candidates: string[], origin: string, max: number): string[] {
  const picked: string[] = [origin + '/']
  const seen = new Set([origin + '/', origin])

  for (const re of PRIORITY) {
    for (const u of candidates) {
      if (picked.length >= max) return picked
      if (seen.has(u)) continue
      if (re.test(u)) {
        picked.push(u)
        seen.add(u)
        break // 各分類から 1 枚ずつ取り、偏らせない
      }
    }
  }

  // 残りは浅い階層から埋める
  const rest = candidates
    .filter((u) => !seen.has(u))
    .sort((a, b) => a.split('/').length - b.split('/').length)
  for (const u of rest) {
    if (picked.length >= max) break
    picked.push(u)
    seen.add(u)
  }
  return picked
}

export async function crawlSite(
  website: string | null,
  maxPages = DEFAULT_MAX_PAGES
): Promise<CrawlResult> {
  const empty: CrawlResult = { pages: [], failed: [], sitemapCount: null }
  if (!website) return empty

  let origin: string
  let startUrl: string
  try {
    const u = new URL(website.startsWith('http') ? website : `https://${website}`)
    origin = u.origin
    startUrl = u.toString()
  } catch {
    return { ...empty, failed: [{ url: website, reason: 'URL の形式が不正' }] }
  }

  const home = await get(startUrl)
  if (!home.ok) {
    return {
      ...empty,
      failed: [{ url: startUrl, reason: `取得できず（HTTP ${home.status || '接続失敗'}）` }],
    }
  }

  const sitemap = await urlsFromSitemap(origin)
  const candidates = sitemap.urls.length > 0 ? sitemap.urls : urlsFromHome(home.body, origin)
  const targets = pickUrls(candidates, origin, maxPages)

  const pages: CrawledPage[] = [parsePage(home.finalUrl, home.body, home.status)]
  const failed: { url: string; reason: string }[] = []

  // 相手のサーバーに負荷をかけないよう、3 件ずつ順に取る
  const rest = targets.filter((u) => u !== origin + '/' && u !== startUrl)
  for (let i = 0; i < rest.length; i += 3) {
    const batch = rest.slice(i, i + 3)
    const results = await Promise.all(batch.map((u) => get(u).then((r) => ({ u, r }))))
    for (const { u, r } of results) {
      if (r.ok && r.body) pages.push(parsePage(r.finalUrl, r.body, r.status))
      else failed.push({ url: u, reason: `HTTP ${r.status || '接続失敗'}` })
    }
    if (pages.length >= maxPages) break
  }

  return { pages: pages.slice(0, maxPages), failed, sitemapCount: sitemap.total }
}

/** プロンプトに載せる形に整える */
export function crawlToPrompt(result: CrawlResult): string {
  if (result.pages.length === 0) {
    const why = result.failed[0]?.reason ?? '取得できませんでした'
    return `（サイトを取得できませんでした：${why}。この場合はサイト内の項目を「確認できず」としてよい）`
  }

  const blocks = result.pages.map((p, i) => {
    const lines = [
      `### ページ${i + 1}: ${p.url}`,
      `title: ${p.title || '(なし)'}`,
      `meta description: ${p.description || '(なし)'}`,
      `h1: ${p.h1.length ? p.h1.join(' / ') : '(なし)'}`,
      `h2: ${p.h2.length ? p.h2.slice(0, 10).join(' / ') : '(なし)'}`,
      `リンクの文言: ${p.linkLabels.slice(0, 25).join(' / ') || '(なし)'}`,
    ]
    if (p.buttonLabels.length) lines.push(`ボタンの文言: ${p.buttonLabels.join(' / ')}`)
    if (p.form) lines.push(`フォーム: 入力欄 ${p.form.fields} 個（うち必須 ${p.form.required} 個）`)
    lines.push(`HTML の大きさ: ${Math.round(p.bytes / 1024)}KB`)
    lines.push(`本文:\n${p.text}`)
    return lines.join('\n')
  })

  const head = [
    `取得したページ ${result.pages.length} 件`,
    result.sitemapCount ? `sitemap 上の総ページ数 ${result.sitemapCount} 件` : null,
    result.failed.length ? `取得できなかったページ ${result.failed.length} 件` : null,
  ]
    .filter(Boolean)
    .join(' / ')

  return `${head}\n\n${blocks.join('\n\n---\n\n')}`
}
