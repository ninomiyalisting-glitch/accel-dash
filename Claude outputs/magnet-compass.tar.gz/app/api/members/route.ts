import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin, requireStaff, STAFF_DOMAIN } from '@/lib/supabaseAdmin'

export const dynamic = 'force-dynamic'

const fail = (message: string, status: number) => NextResponse.json({ error: message }, { status })

/** アクセス権のある人を返す。担当者専用。 */
export async function GET(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const companyId = new URL(req.url).searchParams.get('company_id')
  if (!companyId) return fail('company_id が必要です', 400)

  const { data, error } = await supabaseAdmin
    .from('company_members')
    .select('*')
    .eq('company_id', companyId)
    .order('created_at', { ascending: true })

  if (error) return fail(error.message, 500)
  return NextResponse.json(data ?? [])
}

/** メールアドレスでクライアントを紐づける。未登録なら招待も送る。 */
export async function POST(req: NextRequest) {
  try {
    const auth = await requireStaff(req)
    if (!auth.ok) return fail(auth.message, auth.status)

    const body = await req.json().catch(() => ({}))
    const companyId = String(body.company_id || '')
    const email = String(body.email || '').trim().toLowerCase()

    if (!companyId) return fail('company_id が必要です', 400)
    if (!email) return fail('メールアドレスを入力してください', 400)
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return fail('メールアドレスの形式が正しくありません', 400)
    }
    if (email.endsWith(STAFF_DOMAIN)) {
      return fail(
        `${STAFF_DOMAIN} のアカウントは全クライアントを閲覧できるため、個別の紐付けは不要です`,
        400
      )
    }

    // 既存ユーザーを探す
    const { data: list } = await supabaseAdmin.auth.admin.listUsers({ perPage: 200 })
    let user = list?.users.find((u) => u.email?.toLowerCase() === email)
    let invited = false

    if (!user) {
      const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://accel-dash.com'
      const { data: created, error: inviteError } =
        await supabaseAdmin.auth.admin.inviteUserByEmail(email, {
          redirectTo: `${appUrl}/auth/callback`
        })

      if (inviteError) {
        if (/rate limit/i.test(inviteError.message)) {
          return fail(
            'メール送信の時間あたり上限に達しました。しばらく待つと再送できます',
            429
          )
        }
        return fail(`招待に失敗しました：${inviteError.message}`, 500)
      }
      user = created?.user ?? undefined
      invited = true
    }

    if (!user) return fail('ユーザーを特定できませんでした', 500)

    const { error } = await supabaseAdmin.from('company_members').upsert(
      {
        company_id: companyId,
        user_id: user.id,
        email,
        role: 'viewer'
      },
      { onConflict: 'company_id,user_id' }
    )

    if (error) return fail(error.message, 500)

    return NextResponse.json(
      {
        email,
        invited,
        message: invited
          ? `${email} に招待メールを送り、この会社の閲覧権を付与しました`
          : `${email} にこの会社の閲覧権を付与しました`
      },
      { status: 201 }
    )
  } catch (e: any) {
    console.error('[unexpected]', e)
    return fail(`想定外のエラー：${e?.message || e}`, 500)
  }
}

/** 紐付けを外す。アカウント自体は消さない。 */
export async function DELETE(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const url = new URL(req.url)
  const companyId = url.searchParams.get('company_id')
  const userId = url.searchParams.get('user_id')
  if (!companyId || !userId) return fail('company_id と user_id が必要です', 400)

  const { error } = await supabaseAdmin
    .from('company_members')
    .delete()
    .eq('company_id', companyId)
    .eq('user_id', userId)

  if (error) return fail(error.message, 500)
  return NextResponse.json({ success: true })
}
