import { NextRequest, NextResponse } from 'next/server'
import { toProduct } from '@/lib/checklist'
import { supabaseAdmin, requireViewer, requireStaff } from '@/lib/supabaseAdmin'

export const dynamic = 'force-dynamic'

const fail = (message: string, status: number) => NextResponse.json({ error: message }, { status })

export async function GET(req: NextRequest) {
  const auth = await requireViewer(req)
  if (!auth.ok) return fail(auth.message, auth.status)
  const { viewer } = auth

  let query = supabaseAdmin
    .from('companies')
    .select('*, competitors(id, name, website, sort_order)')
    .eq('archived', false)
    .order('name', { ascending: true })

  if (viewer.companyIds !== null) {
    if (viewer.companyIds.length === 0) return NextResponse.json({ viewer, companies: [] })
    query = query.in('id', viewer.companyIds)
  }

  const { data, error } = await query
  if (error) return fail(error.message, 500)

  return NextResponse.json({ viewer, companies: data ?? [] })
}

export async function POST(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const body = await req.json().catch(() => ({}))
  const name = String(body.name || '').trim()
  if (!name) return fail('会社名は必須です', 400)

  const { data: company, error } = await supabaseAdmin
    .from('companies')
    .insert({
      name,
      // 未指定なら採用版。既存の呼び出し元を壊さないため
      product: toProduct(body.product),
      website: String(body.website || '').trim() || null,
      industry: String(body.industry || '').trim() || null,
      notes: String(body.notes || '').trim() || null,
      created_by: auth.viewer.id
    })
    .select()
    .single()

  if (error) return fail(error.message, 500)

  const competitors = Array.isArray(body.competitors) ? body.competitors : []
  const rows = competitors
    .map((c: any, i: number) => ({
      company_id: company.id,
      name: String(c?.name || '').trim(),
      website: String(c?.website || '').trim() || null,
      sort_order: i
    }))
    .filter((r: any) => r.name)

  if (rows.length > 0) {
    const { error: compError } = await supabaseAdmin.from('competitors').insert(rows)
    if (compError) return fail(`会社は作成できましたが競合の登録に失敗しました：${compError.message}`, 500)
  }

  return NextResponse.json(company, { status: 201 })
}
