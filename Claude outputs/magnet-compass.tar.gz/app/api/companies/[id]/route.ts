import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin, requireViewer, requireStaff, canSee } from '@/lib/supabaseAdmin'

export const dynamic = 'force-dynamic'

const fail = (message: string, status: number) => NextResponse.json({ error: message }, { status })

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const auth = await requireViewer(req)
  if (!auth.ok) return fail(auth.message, auth.status)
  if (!canSee(auth.viewer, id)) return fail('この会社を閲覧する権限がありません', 403)

  const { data, error } = await supabaseAdmin
    .from('companies')
    .select('*, competitors(id, name, website, sort_order)')
    .eq('id', id)
    .single()

  if (error) return fail(error.message, error.code === 'PGRST116' ? 404 : 500)
  return NextResponse.json({ viewer: auth.viewer, company: data })
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const body = await req.json().catch(() => ({}))
  const updates: Record<string, any> = {}
  for (const key of ['name', 'website', 'industry', 'notes'] as const) {
    if (key in body) updates[key] = String(body[key] ?? '').trim() || null
  }
  if (!updates.name && 'name' in updates) return fail('会社名は空にできません', 400)

  if (Object.keys(updates).length > 0) {
    const { error } = await supabaseAdmin.from('companies').update(updates).eq('id', id)
    if (error) return fail(error.message, 500)
  }

  // 競合は毎回まるごと入れ替える（並び順を素直に保つため）
  if (Array.isArray(body.competitors)) {
    await supabaseAdmin.from('competitors').delete().eq('company_id', id)
    const rows = body.competitors
      .map((c: any, i: number) => ({
        company_id: id,
        name: String(c?.name || '').trim(),
        website: String(c?.website || '').trim() || null,
        sort_order: i
      }))
      .filter((r: any) => r.name)
    if (rows.length > 0) {
      const { error } = await supabaseAdmin.from('competitors').insert(rows)
      if (error) return fail(error.message, 500)
    }
  }

  const { data, error } = await supabaseAdmin
    .from('companies')
    .select('*, competitors(id, name, website, sort_order)')
    .eq('id', id)
    .single()

  if (error) return fail(error.message, 500)
  return NextResponse.json(data)
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const { error } = await supabaseAdmin.from('companies').update({ archived: true }).eq('id', id)
  if (error) return fail(error.message, 500)
  return NextResponse.json({ success: true })
}
