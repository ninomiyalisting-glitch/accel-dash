import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin, requireViewer, requireStaff, canSee } from '@/lib/supabaseAdmin'
import {
  research,
  structure,
  claudeAvailable,
  friendlyError,
  modelName,
  QUESTIONS_SCHEMA,
  MENTION_SCHEMA
} from '@/lib/claude'
import {
  questionsResearch,
  QUESTIONS_INSTRUCTION,
  probePrompt,
  mentionInstruction
} from '@/lib/prompts'

export const dynamic = 'force-dynamic'
export const maxDuration = 800

const fail = (message: string, status: number) => NextResponse.json({ error: message }, { status })

export async function GET(req: NextRequest) {
  const auth = await requireViewer(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const companyId = new URL(req.url).searchParams.get('company_id')
  if (!companyId) return fail('company_id が必要です', 400)
  if (!canSee(auth.viewer, companyId)) return fail('閲覧する権限がありません', 403)

  const [{ data: questions }, { data: mentions }] = await Promise.all([
    supabaseAdmin
      .from('mention_questions')
      .select('*')
      .eq('company_id', companyId)
      .eq('active', true)
      .order('sort_order', { ascending: true }),
    supabaseAdmin
      .from('mentions')
      .select('*')
      .eq('company_id', companyId)
      .order('created_at', { ascending: false })
      .limit(200)
  ])

  return NextResponse.json({ questions: questions ?? [], mentions: mentions ?? [] })
}

/** action: 'questions' で質問を設計、それ以外は実測 */
export async function POST(req: NextRequest) {
  try {
    return await handlePost(req)
  } catch (e: any) {
    console.error('[unexpected]', e)
    return fail(`想定外のエラー：${e?.message || e}`, 500)
  }
}

async function handlePost(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)
  if (!claudeAvailable()) return fail('ANTHROPIC_API_KEY が設定されていません', 501)

  const body = await req.json().catch(() => ({}))
  const companyId = String(body.company_id || '')
  if (!companyId) return fail('company_id が必要です', 400)

  const { data: company } = await supabaseAdmin
    .from('companies')
    .select('*, competitors(name, website, sort_order)')
    .eq('id', companyId)
    .single()
  if (!company) return fail('会社が見つかりません', 404)

  const input = {
    name: company.name,
    website: company.website,
    industry: company.industry,
    notes: company.notes,
    competitors: company.competitors ?? []
  }

  // ── 質問の設計 ─────────────────────────────────────────────
  if (body.action === 'questions') {
    let generated: { questions?: { question: string; intent: string }[] }
    try {
      const notes = await research(questionsResearch(input), { maxSearches: 5 })
      generated = await structure({
        notes,
        instruction: QUESTIONS_INSTRUCTION,
        toolName: 'register_questions',
        schema: QUESTIONS_SCHEMA as unknown as Record<string, unknown>
      })
    } catch (e) {
      return fail(friendlyError(e), 502)
    }

    const rows = (generated.questions ?? [])
      .map((q, i) => ({
        company_id: companyId,
        question: String(q?.question || '').trim(),
        intent: String(q?.intent || '').trim() || null,
        sort_order: i
      }))
      .filter((r) => r.question)

    if (rows.length === 0) return fail('質問を生成できませんでした', 502)

    await supabaseAdmin.from('mention_questions').update({ active: false }).eq('company_id', companyId)
    const { data, error } = await supabaseAdmin.from('mention_questions').insert(rows).select()
    if (error) return fail(error.message, 500)

    return NextResponse.json({ questions: data }, { status: 201 })
  }

  // ── 実測 ───────────────────────────────────────────────────
  const { data: questions } = await supabaseAdmin
    .from('mention_questions')
    .select('*')
    .eq('company_id', companyId)
    .eq('active', true)
    .order('sort_order', { ascending: true })

  if (!questions || questions.length === 0) {
    return fail('先に測定用の質問を作成してください', 400)
  }

  const batchId = crypto.randomUUID()
  const model = modelName()
  const created: any[] = []

  for (const q of questions) {
    try {
      // 社名を出さずに素の質問として投げる。ここが公正さの担保。
      const answer = await research(probePrompt(q.question), {
        maxSearches: 4,
        maxTokens: 3000
      })

      const verdict = await structure<{
        mentioned: boolean
        rank_position: number | null
        sentiment: string
        notes: string
        competitors_named: string[]
      }>({
        notes: answer,
        instruction: mentionInstruction(company.name),
        toolName: 'register_mention',
        schema: MENTION_SCHEMA as unknown as Record<string, unknown>
      })

      const { data } = await supabaseAdmin
        .from('mentions')
        .insert({
          company_id: companyId,
          question_id: q.id,
          batch_id: batchId,
          question: q.question,
          answer,
          mentioned: verdict.mentioned,
          rank_position: verdict.rank_position ?? null,
          sentiment: verdict.sentiment || 'absent',
          notes: verdict.notes || null,
          sources: verdict.competitors_named ?? [],
          model
        })
        .select()
        .single()

      if (data) created.push(data)
    } catch (e) {
      // 1 問が失敗しても残りは続ける。全部落とすより部分的な結果の方が役に立つ。
      console.error('[mention probe failed]', q.question, e)
      const { data } = await supabaseAdmin
        .from('mentions')
        .insert({
          company_id: companyId,
          question_id: q.id,
          batch_id: batchId,
          question: q.question,
          mentioned: null,
          sentiment: null,
          notes: `測定に失敗：${friendlyError(e)}`,
          model
        })
        .select()
        .single()
      if (data) created.push(data)
    }
  }

  return NextResponse.json({ mentions: created }, { status: 201 })
}

/** 質問を手で編集・削除する */
export async function PATCH(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const body = await req.json().catch(() => ({}))
  const id = String(body.id || '')
  if (!id) return fail('id が必要です', 400)

  const updates: Record<string, any> = {}
  if ('question' in body) updates.question = String(body.question || '').trim()
  if ('intent' in body) updates.intent = String(body.intent || '').trim() || null
  if ('active' in body) updates.active = Boolean(body.active)
  if (!updates.question && 'question' in body) return fail('質問文は空にできません', 400)

  const { data, error } = await supabaseAdmin
    .from('mention_questions')
    .update(updates)
    .eq('id', id)
    .select()
    .single()

  if (error) return fail(error.message, 500)
  return NextResponse.json(data)
}
