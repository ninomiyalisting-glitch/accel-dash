import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin, requireViewer, requireStaff, canSee } from '@/lib/supabaseAdmin'
import { research, structure, claudeAvailable, friendlyError, modelName, CHECKLIST_SCHEMA } from '@/lib/claude'
import { checklistResearch, checklistInstruction } from '@/lib/prompts'
import { checklistFor, checklistByKey, toProduct, type ChecklistItem } from '@/lib/checklist'
import { runAutoChecks } from '@/lib/autochecks'

export const dynamic = 'force-dynamic'
export const maxDuration = 800

const fail = (message: string, status: number) => NextResponse.json({ error: message }, { status })

const WEIGHT_OF_STATUS: Record<string, number> = { ok: 1, partial: 0.5, ng: 0, unknown: 0 }

/** 最新の点検結果を返す */
export async function GET(req: NextRequest) {
  const auth = await requireViewer(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const companyId = new URL(req.url).searchParams.get('company_id')
  if (!companyId) return fail('company_id が必要です', 400)
  if (!canSee(auth.viewer, companyId)) return fail('閲覧する権限がありません', 403)

  // どの点検表を返すかは会社の製品で決まる
  const { data: companyRow } = await supabaseAdmin
    .from('companies')
    .select('product')
    .eq('id', companyId)
    .maybeSingle()
  const product = toProduct(companyRow?.product)
  const items = checklistFor(product)

  const { data: run } = await supabaseAdmin
    .from('checklist_runs')
    .select('*')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle()

  if (!run) return NextResponse.json({ run: null, results: [], items, product })

  const { data: results } = await supabaseAdmin
    .from('checklist_results')
    .select('*')
    .eq('run_id', run.id)

  return NextResponse.json({ run, results: results ?? [], items, product })
}

/** 点検を実行する。カテゴリごとに分けて呼ぶことで、1回の応答を扱える大きさに保つ。 */
export async function POST(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)
  if (!claudeAvailable()) return fail('ANTHROPIC_API_KEY が設定されていません', 501)

  const body = await req.json().catch(() => ({}))
  const companyId = String(body.company_id || '')
  if (!companyId) return fail('company_id が必要です', 400)

  const { data: company } = await supabaseAdmin
    .from('companies')
    .select('*, competitors(name, website, sort_order)')
    .eq('id', companyId)
    .single()
  if (!company) return fail('会社が見つかりません', 404)

  // 製品ごとに点検表もプロンプトも変わる。ここで一度だけ決める
  const product = toProduct(company.product)
  const CHECKLIST = checklistFor(product)
  const CHECKLIST_BY_KEY = checklistByKey(product)

  const input = {
    name: company.name,
    website: company.website,
    industry: company.industry,
    notes: company.notes,
    competitors: company.competitors ?? []
  }

  // 差分点検：変わりやすい項目と、前回 ok でなかった項目だけを再確認する。
  // 変わらないものを毎回調べ直さないことが、費用を下げる一番効く手。
  const diffMode = Boolean(body.diff)
  let previous = new Map<string, { status: string; evidence: string | null; fix: string | null }>()

  if (diffMode) {
    const { data: lastRun } = await supabaseAdmin
      .from('checklist_runs')
      .select('id')
      .eq('company_id', companyId)
      .eq('product', product)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()

    if (lastRun) {
      const { data: rows } = await supabaseAdmin
        .from('checklist_results')
        .select('item_key, status, evidence, fix')
        .eq('run_id', lastRun.id)
      previous = new Map((rows ?? []).map((r: any) => [r.item_key, r]))
    }
  }

  // ── 1. コードで判定できる項目（無料・確実）────────────────────
  const auto = await runAutoChecks(company.website)

  // ── 2. LLM に回す項目を絞る ──────────────────────────────────
  const needsLlm = CHECKLIST.filter((item: ChecklistItem) => {
    if (item.auto) return false // コードで判定済み
    if (!diffMode) return true
    if (item.volatile) return true // 変わりやすいので毎回見る
    const before = previous.get(item.key)
    return !before || before.status !== 'ok' // 未達のものは進捗を確認する
  })

  const collected: { key: string; status: string; evidence: string; fix?: string }[] = []
  const model = modelName()

  if (needsLlm.length > 0) {
    try {
      // 調査は 1 回にまとめる。以前はカテゴリごとに 3 回検索していたが、
      // 同じ採用ページを何度も取得していて無駄が大きかった。
      const notes = await research(
        checklistResearch(
          input,
          needsLlm.map((i: ChecklistItem) => ({ key: i.key, category: i.category, title: i.title, check: i.check })),
          product
        ),
        { maxTokens: 10000, maxSearches: diffMode ? 8 : 14 }
      )
      const structured = await structure<{ results: any[] }>({
        notes,
        instruction: checklistInstruction(needsLlm.map((i: ChecklistItem) => i.key)),
        toolName: 'register_checklist',
        schema: CHECKLIST_SCHEMA as unknown as Record<string, unknown>
      })
      collected.push(...(structured.results ?? []))
    } catch (e) {
      return fail(friendlyError(e), 502)
    }
  }

  const byKey = new Map(collected.map((r) => [String(r.key), r]))

  const rows = CHECKLIST.map((item: ChecklistItem) => {
    // コード判定を最優先
    const autoHit = auto[item.key]
    if (item.auto && autoHit) {
      return {
        company_id: companyId,
        item_key: item.key,
        status: autoHit.status,
        evidence: autoHit.evidence,
        fix: autoHit.fix ?? null
      }
    }

    const hit = byKey.get(item.key)
    if (hit) {
      const status = ['ok', 'partial', 'ng', 'unknown'].includes(hit.status) ? hit.status : 'unknown'
      return {
        company_id: companyId,
        item_key: item.key,
        status,
        evidence: hit.evidence?.trim() || '公開情報からは確認できず',
        fix: hit.fix?.trim() || null
      }
    }

    // 差分点検で再確認しなかった項目は、前回の判定をそのまま引き継ぐ
    const before = previous.get(item.key)
    if (before) {
      return {
        company_id: companyId,
        item_key: item.key,
        status: before.status,
        evidence: before.evidence || '前回の点検結果を引き継ぎ',
        fix: before.fix
      }
    }

    return {
      company_id: companyId,
      item_key: item.key,
      status: 'unknown',
      evidence: '公開情報からは確認できず',
      fix: null
    }
  })

  // 達成率は重み付きでコード側で計算する（毎回同じ計算になり、後から検算できる）
  const totalWeight = CHECKLIST.reduce((sum: number, i: ChecklistItem) => sum + i.weight, 0)
  const gained = rows.reduce((sum: number, row: { item_key: string; status: string }) => {
    const item = CHECKLIST_BY_KEY.get(row.item_key)!
    return sum + item.weight * (WEIGHT_OF_STATUS[row.status] ?? 0)
  }, 0)
  const score = Math.round((gained / totalWeight) * 1000) / 10
  const okCount = rows.filter((r: { status: string }) => r.status === 'ok').length

  const { data: run, error } = await supabaseAdmin
    .from('checklist_runs')
    .insert({
      company_id: companyId,
      product,
      ok_count: okCount,
      total_count: CHECKLIST.length,
      score,
      model,
      created_by: auth.viewer.id
    })
    .select()
    .single()

  if (error) return fail(error.message, 500)

  await supabaseAdmin
    .from('checklist_results')
    .insert(rows.map((r: Record<string, unknown>) => ({ ...r, run_id: run.id })))

  const { data: results } = await supabaseAdmin
    .from('checklist_results')
    .select('*')
    .eq('run_id', run.id)

  return NextResponse.json({ run, results: results ?? [], items: CHECKLIST, product }, { status: 201 })
}

/** 判定を手で上書きする、または「やること」に送る */
export async function PATCH(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const body = await req.json().catch(() => ({}))

  if (body.action === 'to_todo') {
    const keys: string[] = Array.isArray(body.keys) ? body.keys : []
    const companyId = String(body.company_id || '')
    if (!companyId || keys.length === 0) return fail('対象がありません', 400)

    // 「やること」の文面は点検項目から作るので、製品に合った表を引く
    const { data: companyRow } = await supabaseAdmin
      .from('companies')
      .select('product')
      .eq('id', companyId)
      .maybeSingle()
    const CHECKLIST_BY_KEY = checklistByKey(toProduct(companyRow?.product))

    const { data: existing } = await supabaseAdmin
      .from('todos')
      .select('title')
      .eq('company_id', companyId)
      .eq('done', false)
    const known = new Set((existing ?? []).map((t: any) => t.title))

    const { data: results } = await supabaseAdmin
      .from('checklist_results')
      .select('item_key, fix')
      .eq('company_id', companyId)
      .in('item_key', keys)
      .order('created_at', { ascending: false })

    const seen = new Set<string>()
    const todos: any[] = []
    for (const r of results ?? []) {
      if (seen.has(r.item_key)) continue
      seen.add(r.item_key)
      const item = CHECKLIST_BY_KEY.get(r.item_key)
      if (!item) continue
      const title = `${item.category}：${item.title}`
      if (known.has(title)) continue
      todos.push({
        company_id: companyId,
        title,
        detail: r.fix || item.check,
        priority: item.weight === 3 ? 'high' : item.weight === 2 ? 'medium' : 'low',
        source: 'auto',
        created_by: auth.viewer.id
      })
    }

    if (todos.length > 0) await supabaseAdmin.from('todos').insert(todos)
    return NextResponse.json({ added: todos.length })
  }

  const id = String(body.id || '')
  if (!id) return fail('id が必要です', 400)
  const status = String(body.status || '')
  if (!['ok', 'partial', 'ng', 'unknown'].includes(status)) return fail('status が不正です', 400)

  const { data, error } = await supabaseAdmin
    .from('checklist_results')
    .update({ status, manual: true })
    .eq('id', id)
    .select()
    .single()

  if (error) return fail(error.message, 500)
  return NextResponse.json(data)
}
