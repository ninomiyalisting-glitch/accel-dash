import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin, requireViewer, requireStaff, canSee } from '@/lib/supabaseAdmin'
import { research, structure, claudeAvailable, friendlyError, modelName, CRITERIA_SCHEMA } from '@/lib/claude'
import { criteriaResearch, CRITERIA_INSTRUCTION } from '@/lib/prompts'

export const dynamic = 'force-dynamic'
export const maxDuration = 300

const fail = (message: string, status: number) => NextResponse.json({ error: message }, { status })

async function loadCompany(id: string) {
  const { data } = await supabaseAdmin
    .from('companies')
    .select('*, competitors(name, website, sort_order)')
    .eq('id', id)
    .single()
  return data
}

/** 有効な評価軸を返す */
export async function GET(req: NextRequest) {
  const auth = await requireViewer(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const companyId = new URL(req.url).searchParams.get('company_id')
  if (!companyId) return fail('company_id が必要です', 400)
  if (!canSee(auth.viewer, companyId)) return fail('閲覧する権限がありません', 403)

  const { data, error } = await supabaseAdmin
    .from('criteria_sets')
    .select('*, criteria_set_items(id, name, description, weight, sort_order)')
    .eq('company_id', companyId)
    .eq('active', true)
    .maybeSingle()

  if (error) return fail(error.message, 500)
  return NextResponse.json(data)
}

/** 評価軸を生成する（初回、または作り直し） */
export async function POST(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)
  if (!claudeAvailable()) return fail('ANTHROPIC_API_KEY が設定されていません', 501)

  const body = await req.json().catch(() => ({}))
  const companyId = String(body.company_id || '')
  if (!companyId) return fail('company_id が必要です', 400)

  const company = await loadCompany(companyId)
  if (!company) return fail('会社が見つかりません', 404)

  let generated: { rationale?: string; criteria?: any[] }
  const model = modelName()
  try {
    const notes = await research(
      criteriaResearch({
        name: company.name,
        website: company.website,
        industry: company.industry,
        notes: company.notes,
        competitors: company.competitors ?? []
      })
    )
    generated = await structure({
      notes,
      instruction: CRITERIA_INSTRUCTION,
      toolName: 'register_criteria',
      schema: CRITERIA_SCHEMA as unknown as Record<string, unknown>
    })
  } catch (e) {
    return fail(friendlyError(e), 502)
  }

  const items = (generated.criteria ?? [])
    .map((c: any, i: number) => ({
      name: String(c?.name || '').trim(),
      description: String(c?.description || '').trim() || null,
      weight: Number(c?.weight) || 0,
      sort_order: i
    }))
    .filter((c) => c.name)

  if (items.length === 0) return fail('評価軸を生成できませんでした。もう一度お試しください', 502)

  // 既存の軸は無効化して版を上げる（履歴の系列を分けるため）
  const { data: previous } = await supabaseAdmin
    .from('criteria_sets')
    .select('version')
    .eq('company_id', companyId)
    .order('version', { ascending: false })
    .limit(1)
    .maybeSingle()

  await supabaseAdmin.from('criteria_sets').update({ active: false }).eq('company_id', companyId)

  const { data: set, error } = await supabaseAdmin
    .from('criteria_sets')
    .insert({
      company_id: companyId,
      version: (previous?.version ?? 0) + 1,
      active: true,
      rationale: generated.rationale ?? null,
      model,
      created_by: auth.viewer.id
    })
    .select()
    .single()

  if (error) return fail(error.message, 500)

  const { error: itemError } = await supabaseAdmin
    .from('criteria_set_items')
    .insert(items.map((c) => ({ ...c, criteria_set_id: set.id })))

  if (itemError) return fail(itemError.message, 500)

  const { data: full } = await supabaseAdmin
    .from('criteria_sets')
    .select('*, criteria_set_items(id, name, description, weight, sort_order)')
    .eq('id', set.id)
    .single()

  return NextResponse.json(full, { status: 201 })
}

/** 軸を手で修正する（名前・説明・重み） */
export async function PATCH(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const body = await req.json().catch(() => ({}))
  const items = Array.isArray(body.items) ? body.items : []
  if (items.length === 0) return fail('更新する軸がありません', 400)

  for (const item of items) {
    if (!item?.id) continue
    await supabaseAdmin
      .from('criteria_set_items')
      .update({
        name: String(item.name || '').trim(),
        description: String(item.description || '').trim() || null,
        weight: Number(item.weight) || 0
      })
      .eq('id', item.id)
  }

  return NextResponse.json({ success: true })
}
