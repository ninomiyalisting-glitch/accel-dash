import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin, requireViewer, requireStaff, canSee } from '@/lib/supabaseAdmin'
import { research, structure, claudeAvailable, friendlyError, CONTENT_SCHEMA } from '@/lib/claude'
import { contentResearch, CONTENT_INSTRUCTION } from '@/lib/prompts'
import { checklistByKey, toProduct } from '@/lib/checklist'

export const dynamic = 'force-dynamic'
export const maxDuration = 600

const fail = (message: string, status: number) => NextResponse.json({ error: message }, { status })

export async function GET(req: NextRequest) {
  const auth = await requireViewer(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const companyId = new URL(req.url).searchParams.get('company_id')
  if (!companyId) return fail('company_id が必要です', 400)
  if (!canSee(auth.viewer, companyId)) return fail('閲覧する権限がありません', 403)

  const { data, error } = await supabaseAdmin
    .from('content_ideas')
    .select('*')
    .eq('company_id', companyId)
    .order('used', { ascending: true })
    .order('created_at', { ascending: false })

  if (error) return fail(error.message, 500)
  return NextResponse.json(data ?? [])
}

export async function POST(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)
  if (!claudeAvailable()) return fail('ANTHROPIC_API_KEY が設定されていません', 501)

  const body = await req.json().catch(() => ({}))
  const companyId = String(body.company_id || '')
  if (!companyId) return fail('company_id が必要です', 400)

  const { data: company } = await supabaseAdmin
    .from('companies')
    .select('*, competitors(name, website, sort_order)')
    .eq('id', companyId)
    .single()
  if (!company) return fail('会社が見つかりません', 404)

  const product = toProduct(company.product)
  const CHECKLIST_BY_KEY = checklistByKey(product)

  // 直近の点検で弱かった項目を、提案の狙いとして渡す
  const { data: latestRun } = await supabaseAdmin
    .from('checklist_runs')
    .select('id')
    .eq('company_id', companyId)
    .eq('product', product)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle()

  let weakPoints: string[] = []
  if (latestRun) {
    const { data: weak } = await supabaseAdmin
      .from('checklist_results')
      .select('item_key, status')
      .eq('run_id', latestRun.id)
      .in('status', ['ng', 'partial'])

    weakPoints = (weak ?? [])
      .map((r: any) => {
        const item = CHECKLIST_BY_KEY.get(r.item_key)
        return item ? `${item.title}（${r.status === 'ng' ? '未対応' : '一部のみ'}）` : null
      })
      .filter(Boolean) as string[]
  }

  let ideas: any[] = []
  try {
    const notes = await research(
      contentResearch(
        {
          name: company.name,
          website: company.website,
          industry: company.industry,
          notes: company.notes,
          competitors: company.competitors ?? []
        },
        weakPoints,
        product
      ),
      { maxTokens: 12000 }
    )
    const structured = await structure<{ ideas: any[] }>({
      notes,
      instruction: CONTENT_INSTRUCTION,
      toolName: 'register_content_ideas',
      schema: CONTENT_SCHEMA as unknown as Record<string, unknown>
    })
    ideas = structured.ideas ?? []
  } catch (e) {
    return fail(friendlyError(e), 502)
  }

  const rows = ideas
    .map((i: any) => ({
      company_id: companyId,
      title: String(i?.title || '').trim(),
      format: String(i?.format || '').trim() || null,
      target_question: String(i?.target_question || '').trim() || null,
      audience: String(i?.audience || '').trim() || null,
      outline: String(i?.outline || '').trim() || null,
      priority: ['high', 'medium', 'low'].includes(i?.priority) ? i.priority : 'medium',
      created_by: auth.viewer.id
    }))
    .filter((r) => r.title)

  if (rows.length === 0) return fail('コンテンツ案を生成できませんでした', 502)

  const { data, error } = await supabaseAdmin.from('content_ideas').insert(rows).select()
  if (error) return fail(error.message, 500)

  return NextResponse.json(data, { status: 201 })
}

/** 使用済みにする、または「やること」に送る */
export async function PATCH(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const body = await req.json().catch(() => ({}))

  if (body.action === 'to_todo') {
    const id = String(body.id || '')
    const { data: idea } = await supabaseAdmin.from('content_ideas').select('*').eq('id', id).single()
    if (!idea) return fail('見つかりません', 404)

    await supabaseAdmin.from('todos').insert({
      company_id: idea.company_id,
      title: `${idea.format || 'コンテンツ'}：${idea.title}`,
      detail: [idea.outline, idea.target_question ? `狙う質問：${idea.target_question}` : null]
        .filter(Boolean)
        .join('\n'),
      priority: idea.priority,
      source: 'auto',
      created_by: auth.viewer.id
    })

    await supabaseAdmin.from('content_ideas').update({ used: true }).eq('id', id)
    return NextResponse.json({ success: true })
  }

  const id = String(body.id || '')
  if (!id) return fail('id が必要です', 400)
  const { data, error } = await supabaseAdmin
    .from('content_ideas')
    .update({ used: Boolean(body.used) })
    .eq('id', id)
    .select()
    .single()

  if (error) return fail(error.message, 500)
  return NextResponse.json(data)
}

export async function DELETE(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const id = new URL(req.url).searchParams.get('id')
  if (!id) return fail('id が必要です', 400)

  const { error } = await supabaseAdmin.from('content_ideas').delete().eq('id', id)
  if (error) return fail(error.message, 500)
  return NextResponse.json({ success: true })
}
