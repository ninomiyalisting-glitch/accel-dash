import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin, requireViewer, requireStaff, canSee } from '@/lib/supabaseAdmin'

export const dynamic = 'force-dynamic'

const fail = (message: string, status: number) => NextResponse.json({ error: message }, { status })

export async function GET(req: NextRequest) {
  const auth = await requireViewer(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const companyId = new URL(req.url).searchParams.get('company_id')
  if (!companyId) return fail('company_id が必要です', 400)
  if (!canSee(auth.viewer, companyId)) return fail('閲覧する権限がありません', 403)

  const { data, error } = await supabaseAdmin
    .from('todos')
    .select('*')
    .eq('company_id', companyId)
    .order('done', { ascending: true })
    .order('sort_order', { ascending: true })
    .order('created_at', { ascending: false })

  if (error) return fail(error.message, 500)
  return NextResponse.json(data ?? [])
}

export async function POST(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const body = await req.json().catch(() => ({}))
  const companyId = String(body.company_id || '')
  const title = String(body.title || '').trim()

  if (!companyId) return fail('company_id が必要です', 400)
  if (!title) return fail('やることの内容を入力してください', 400)

  const { data, error } = await supabaseAdmin
    .from('todos')
    .insert({
      company_id: companyId,
      title,
      detail: String(body.detail || '').trim() || null,
      priority: ['high', 'medium', 'low'].includes(body.priority) ? body.priority : 'medium',
      due_on: body.due_on || null,
      source: 'manual',
      created_by: auth.viewer.id
    })
    .select()
    .single()

  if (error) return fail(error.message, 500)
  return NextResponse.json(data, { status: 201 })
}

export async function PATCH(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const body = await req.json().catch(() => ({}))
  const id = String(body.id || '')
  if (!id) return fail('id が必要です', 400)

  const updates: Record<string, any> = {}
  if ('done' in body) {
    updates.done = Boolean(body.done)
    updates.done_at = updates.done ? new Date().toISOString() : null
  }
  for (const key of ['title', 'detail', 'priority', 'due_on'] as const) {
    if (key in body) updates[key] = body[key] === '' ? null : body[key]
  }
  if (Object.keys(updates).length === 0) return fail('更新する項目がありません', 400)

  const { data, error } = await supabaseAdmin.from('todos').update(updates).eq('id', id).select().single()
  if (error) return fail(error.message, 500)
  return NextResponse.json(data)
}

export async function DELETE(req: NextRequest) {
  const auth = await requireStaff(req)
  if (!auth.ok) return fail(auth.message, auth.status)

  const id = new URL(req.url).searchParams.get('id')
  if (!id) return fail('id が必要です', 400)

  const { error } = await supabaseAdmin.from('todos').delete().eq('id', id)
  if (error) return fail(error.message, 500)
  return NextResponse.json({ success: true })
}
