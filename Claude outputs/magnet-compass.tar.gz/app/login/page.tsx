'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import { Mail, Lock } from 'lucide-react'

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    const { data, error: signInError } = await supabase.auth.signInWithPassword({ email, password })
    setLoading(false)

    if (signInError) {
      setError(
        /invalid login/i.test(signInError.message)
          ? 'メールアドレスかパスワードが違います'
          : signInError.message
      )
      return
    }
    if (data.session) router.push('/')
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-accel-lightest p-6">
      <div className="w-full max-w-md rounded-2xl border border-border-soft bg-surface p-10 shadow-sm">
        <div className="mb-9 flex flex-col items-center">
          <img src="/logo.png" alt="マグネット" className="h-11 w-auto" />
          <h1 className="sr-only">マグネット</h1>
        </div>

        <form onSubmit={handleLogin} className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <label htmlFor="email" className="text-sm font-semibold">
              メールアドレス
            </label>
            <div className="relative">
              <Mail
                className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-accel-secondary"
                size={20}
              />
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                required
                className="pl-12"
              />
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <label htmlFor="password" className="text-sm font-semibold">
              パスワード
            </label>
            <div className="relative">
              <Lock
                className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-accel-secondary"
                size={20}
              />
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="pl-12"
              />
            </div>
          </div>

          {error && <p className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-accel-primary px-4 py-3 text-white hover:bg-accel-hover active:bg-accel-active"
          >
            {loading ? 'ログイン中…' : 'ログイン'}
          </button>
        </form>

        <div className="mt-8 flex flex-col items-center gap-3">
          <a href="https://accel-dash.com/auth/reset" className="text-sm underline">
            パスワードをお忘れですか？
          </a>
          <p className="text-sm text-black/60">招待された方のみアクセスできます</p>
        </div>
      </div>
    </div>
  )
}
