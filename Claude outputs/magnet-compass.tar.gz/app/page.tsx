'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'
import { api } from '@/lib/client'
import { PRODUCTS, PRODUCT_LABEL, PRODUCT_NOTE, PRODUCT_SHORT, type Product } from '@/lib/checklist'
import Shell from '@/components/Shell'
import Notice, { NoticeState } from '@/components/Notice'
import { Plus, Building2, Globe, X } from 'lucide-react'
import type { Company, Competitor } from '@/lib/types'

type Viewer = { id: string; email: string; isStaff: boolean; companyIds: string[] | null }
type Row = Company & { competitors: Competitor[] }

export default function Home() {
  const router = useRouter()
  const [viewer, setViewer] = useState<Viewer | null>(null)
  const [companies, setCompanies] = useState<Row[]>([])
  const [loading, setLoading] = useState(true)
  const [notice, setNotice] = useState<NoticeState>(null)

  const [showNew, setShowNew] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ name: '', website: '', industry: '', notes: '', product: 'magnet' as Product })
  const [rivals, setRivals] = useState<{ name: string; website: string }[]>([
    { name: '', website: '' }
  ])

  useEffect(() => {
    load()
  }, [])

  async function load() {
    const { data } = await supabase.auth.getSession()
    if (!data.session) {
      router.push('/login')
      return
    }

    try {
      const res = await api<{ viewer: Viewer; companies: Row[] }>('/api/companies')
      setViewer(res.viewer)
      setCompanies(res.companies)

      // クライアントで所属が 1 社だけならそこへ直行する
      if (!res.viewer.isStaff && res.companies.length === 1) {
        router.replace(`/companies/${res.companies[0].id}`)
        return
      }
    } catch (e: any) {
      setNotice({ kind: 'ng', text: e.message })
    }
    setLoading(false)
  }

  async function handleCreate() {
    if (!form.name.trim()) {
      setNotice({ kind: 'ng', text: '会社名を入力してください' })
      return
    }

    setSaving(true)
    try {
      const created = await api<Company>('/api/companies', {
        method: 'POST',
        body: { ...form, competitors: rivals.filter((r) => r.name.trim()) }
      })
      setShowNew(false)
      setForm({ name: '', website: '', industry: '', notes: '', product: 'magnet' })
      setRivals([{ name: '', website: '' }])
      router.push(`/companies/${created.id}`)
    } catch (e: any) {
      setNotice({ kind: 'ng', text: e.message })
    }
    setSaving(false)
  }

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center">読み込み中…</div>
  }

  return (
    <Shell email={viewer?.email} isStaff={viewer?.isStaff}>
      <Notice notice={notice} onClose={() => setNotice(null)} />

      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h1>クライアント</h1>
        {viewer?.isStaff && (
          <button
            onClick={() => setShowNew((v) => !v)}
            className="flex items-center gap-2 rounded-lg border-2 border-border-soft bg-surface px-4 py-2 hover:border-accel-secondary"
          >
            <Plus size={18} />
            会社を追加
          </button>
        )}
      </div>

      {showNew && viewer?.isStaff && (
        <div className="mb-8 flex flex-col gap-5 rounded-2xl border border-border-soft bg-surface p-6">
          <div className="flex flex-col gap-2">
            <label className="text-sm font-semibold">何を点検するか</label>
            <div className="flex flex-wrap gap-2">
              {PRODUCTS.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setForm({ ...form, product: p })}
                  aria-pressed={form.product === p}
                  className={
                    form.product === p
                      ? 'rounded-xl border-2 border-accel-primary bg-accel-lightest px-4 py-2 text-sm font-semibold text-accel-deep'
                      : 'rounded-xl border border-border-soft px-4 py-2 text-sm hover:border-accel-secondary'
                  }
                >
                  {PRODUCT_LABEL[p]}
                </button>
              ))}
            </div>
            <p className="text-sm text-black/60">{PRODUCT_NOTE[form.product]}</p>
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-semibold">会社名</label>
            <input
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="株式会社ラシン"
            />
          </div>

          <div className="grid gap-5 sm:grid-cols-2">
            <div className="flex flex-col gap-2">
              <label className="text-sm font-semibold">採用サイト / 企業サイト</label>
              <input
                type="url"
                value={form.website}
                onChange={(e) => setForm({ ...form, website: e.target.value })}
                placeholder="https://example.co.jp"
              />
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-sm font-semibold">業種</label>
              <input
                type="text"
                value={form.industry}
                onChange={(e) => setForm({ ...form, industry: e.target.value })}
                placeholder="人材サービス"
              />
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <label className="text-sm font-semibold">競合</label>
            <p className="text-sm text-black/60">
              求職者が併願しそうな会社を入れてください。スコアの比較対象になります。
            </p>
            {rivals.map((rival, i) => (
              <div key={i} className="flex flex-wrap items-center gap-2">
                <input
                  type="text"
                  value={rival.name}
                  onChange={(e) => {
                    const next = [...rivals]
                    next[i] = { ...next[i], name: e.target.value }
                    setRivals(next)
                  }}
                  placeholder="競合の会社名"
                  className="min-w-[180px] flex-1"
                />
                <input
                  type="url"
                  value={rival.website}
                  onChange={(e) => {
                    const next = [...rivals]
                    next[i] = { ...next[i], website: e.target.value }
                    setRivals(next)
                  }}
                  placeholder="https://（任意）"
                  className="min-w-[180px] flex-1"
                />
                {rivals.length > 1 && (
                  <button
                    onClick={() => setRivals(rivals.filter((_, j) => j !== i))}
                    aria-label="削除"
                    className="rounded-lg p-2 text-black/50 hover:bg-surface-muted"
                  >
                    <X size={18} />
                  </button>
                )}
              </div>
            ))}
            <button
              onClick={() => setRivals([...rivals, { name: '', website: '' }])}
              className="self-start rounded-lg border-2 border-border-soft px-4 py-2 text-sm hover:border-accel-secondary"
            >
              競合を追加
            </button>
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-semibold">メモ</label>
            <textarea
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              placeholder="採用の課題、ターゲット、進行中の施策など。分析の前提として使われます。"
            />
          </div>

          <div className="flex gap-3">
            <button
              onClick={handleCreate}
              disabled={saving}
              className="rounded-lg bg-accel-primary px-6 py-2 text-white hover:bg-accel-hover active:bg-accel-active"
            >
              {saving ? '作成中…' : '作成する'}
            </button>
            <button
              onClick={() => setShowNew(false)}
              className="rounded-lg border-2 border-border-soft px-6 py-2 hover:border-accel-secondary"
            >
              キャンセル
            </button>
          </div>
        </div>
      )}

      {companies.length === 0 ? (
        <div className="rounded-2xl border border-border-soft bg-surface p-10 text-center">
          <Building2 size={28} className="mx-auto mb-3 text-accel-secondary" />
          <p className="text-black/70">
            {viewer?.isStaff
              ? 'まだ会社が登録されていません。「会社を追加」から始めてください。'
              : 'アクセスできる会社がありません。担当者にお問い合わせください。'}
          </p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {companies.map((company) => (
            <Link
              key={company.id}
              href={`/companies/${company.id}`}
              className="rounded-2xl border border-border-soft bg-surface p-6 no-underline hover:border-accel-secondary"
            >
              <div className="mb-1 flex items-center gap-2">
                <h3 className="m-0">{company.name}</h3>
                <span className="rounded-full border border-border-soft px-2 py-0.5 text-xs text-black/60">
                  {PRODUCT_SHORT[company.product ?? 'magnet']}
                </span>
              </div>
              {company.industry && <p className="text-sm text-black/60">{company.industry}</p>}
              {company.website && (
                <p className="mt-2 flex items-center gap-1.5 text-sm text-black/60">
                  <Globe size={14} />
                  <span className="truncate">{company.website.replace(/^https?:\/\//, '')}</span>
                </p>
              )}
              <p className="mt-3 text-sm text-black/60">
                競合 {company.competitors?.length ?? 0} 社
              </p>
            </Link>
          ))}
        </div>
      )}
    </Shell>
  )
}
