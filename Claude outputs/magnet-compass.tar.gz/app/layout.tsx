import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'マグネット｜採用魅力度スコアリング',
  description: '求職者視点の選定基準で採用魅力度を採点し、AI 上の言及と打ち手を管理します。',
  icons: { icon: '/favicon.ico' }
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  )
}
