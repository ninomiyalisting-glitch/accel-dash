-- =====================================================================
-- マグネット 第4段階：AI 言及モニタリング／クライアント権限
-- 何度実行しても安全です。
-- =====================================================================

-- 測定用の質問。会社ごとに固定し、毎回同じ質問で測ることで推移が読める。
create table if not exists public.mention_questions (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  question text not null,
  intent text,                -- この質問で何を測るか
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create index if not exists mention_questions_company_idx
  on public.mention_questions(company_id, active, sort_order);

-- 既存の mentions に質問との紐付けと実行単位を足す
alter table public.mentions
  add column if not exists question_id uuid references public.mention_questions(id) on delete set null;
alter table public.mentions
  add column if not exists batch_id uuid;

alter table public.mention_questions enable row level security;

drop policy if exists mention_questions_select on public.mention_questions;
create policy mention_questions_select on public.mention_questions for select to authenticated
  using (public.has_company_access(company_id));
drop policy if exists mention_questions_write on public.mention_questions;
create policy mention_questions_write on public.mention_questions for all to authenticated
  using (public.is_staff()) with check (public.is_staff());
