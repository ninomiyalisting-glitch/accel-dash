-- =====================================================================
-- マグネット スキーマ
-- Supabase の SQL Editor に貼って実行してください。何度実行しても安全です。
-- =====================================================================

-- ---------------------------------------------------------------------
-- 会社
-- ---------------------------------------------------------------------
create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  website text,
  industry text,
  notes text,
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null
);

-- 競合
create table if not exists public.competitors (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  website text,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists competitors_company_idx on public.competitors(company_id);

-- クライアント側ユーザーの所属（自社スタッフは登録不要で全社見える）
create table if not exists public.company_members (
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  email text,
  role text not null default 'viewer',
  created_at timestamptz not null default now(),
  primary key (company_id, user_id)
);
create index if not exists company_members_user_idx on public.company_members(user_id);

-- ---------------------------------------------------------------------
-- スコアリング（1 回の分析 = 1 assessment）
-- ---------------------------------------------------------------------
create table if not exists public.assessments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  status text not null default 'complete',
  overall_score numeric(5,2),
  summary text,
  model text,
  input_snapshot jsonb,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null
);
create index if not exists assessments_company_idx on public.assessments(company_id, created_at desc);

-- 選定基準ごとのスコア
create table if not exists public.assessment_criteria (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid not null references public.assessments(id) on delete cascade,
  name text not null,
  description text,
  weight numeric(5,2) not null default 1,
  score numeric(5,2),
  rationale text,
  sort_order integer not null default 0
);
create index if not exists assessment_criteria_idx on public.assessment_criteria(assessment_id, sort_order);

-- 競合の同一基準スコア（ベンチマーク用）
create table if not exists public.competitor_scores (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid not null references public.assessments(id) on delete cascade,
  competitor_name text not null,
  criteria_name text not null,
  score numeric(5,2),
  rationale text
);
create index if not exists competitor_scores_idx on public.competitor_scores(assessment_id);

-- ---------------------------------------------------------------------
-- AI 言及モニタリング
-- ---------------------------------------------------------------------
create table if not exists public.mentions (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  question text not null,
  answer text,
  mentioned boolean,
  sentiment text,
  rank_position integer,
  notes text,
  sources jsonb,
  model text,
  created_at timestamptz not null default now()
);
create index if not exists mentions_company_idx on public.mentions(company_id, created_at desc);

-- ---------------------------------------------------------------------
-- 改善提案
-- ---------------------------------------------------------------------
create table if not exists public.recommendations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  assessment_id uuid references public.assessments(id) on delete set null,
  title text not null,
  detail text,
  priority text not null default 'medium',
  effort text,
  created_at timestamptz not null default now()
);
create index if not exists recommendations_company_idx on public.recommendations(company_id, created_at desc);

-- ---------------------------------------------------------------------
-- TODO
-- ---------------------------------------------------------------------
create table if not exists public.todos (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  recommendation_id uuid references public.recommendations(id) on delete set null,
  title text not null,
  detail text,
  source text not null default 'manual',
  priority text not null default 'medium',
  due_on date,
  done boolean not null default false,
  done_at timestamptz,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null
);
create index if not exists todos_company_idx on public.todos(company_id, done, sort_order);

-- ---------------------------------------------------------------------
-- 権限判定
-- ---------------------------------------------------------------------

-- 自社スタッフか（@accel-partners.co.jp なら全社アクセス可）
create or replace function public.is_staff()
returns boolean
language sql
stable
as $$
  select coalesce(auth.jwt() ->> 'email', '') like '%@accel-partners.co.jp';
$$;

-- その会社を見られるか。security definer にして RLS の再帰を避ける。
create or replace function public.has_company_access(cid uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.is_staff()
      or exists (
        select 1 from public.company_members m
        where m.company_id = cid and m.user_id = auth.uid()
      );
$$;

-- ---------------------------------------------------------------------
-- RLS
--   参照: その会社にアクセス権のある人だけ
--   更新: 自社スタッフのみ（クライアントは閲覧専用）
-- ---------------------------------------------------------------------
alter table public.companies         enable row level security;
alter table public.competitors       enable row level security;
alter table public.company_members   enable row level security;
alter table public.assessments       enable row level security;
alter table public.assessment_criteria enable row level security;
alter table public.competitor_scores enable row level security;
alter table public.mentions          enable row level security;
alter table public.recommendations   enable row level security;
alter table public.todos             enable row level security;

-- companies
drop policy if exists companies_select on public.companies;
create policy companies_select on public.companies for select to authenticated
  using (public.has_company_access(id));
drop policy if exists companies_write on public.companies;
create policy companies_write on public.companies for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

-- company_id を持つテーブルは同じ形
do $$
declare t text;
begin
  for t in
    select unnest(array['competitors','assessments','mentions','recommendations','todos','company_members'])
  loop
    execute format('drop policy if exists %I_select on public.%I', t, t);
    execute format(
      'create policy %I_select on public.%I for select to authenticated using (public.has_company_access(company_id))', t, t);
    execute format('drop policy if exists %I_write on public.%I', t, t);
    execute format(
      'create policy %I_write on public.%I for all to authenticated using (public.is_staff()) with check (public.is_staff())', t, t);
  end loop;
end $$;

-- assessment 配下は親の会社をたどって判定
drop policy if exists assessment_criteria_select on public.assessment_criteria;
create policy assessment_criteria_select on public.assessment_criteria for select to authenticated
  using (exists (select 1 from public.assessments a
                 where a.id = assessment_id and public.has_company_access(a.company_id)));
drop policy if exists assessment_criteria_write on public.assessment_criteria;
create policy assessment_criteria_write on public.assessment_criteria for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

drop policy if exists competitor_scores_select on public.competitor_scores;
create policy competitor_scores_select on public.competitor_scores for select to authenticated
  using (exists (select 1 from public.assessments a
                 where a.id = assessment_id and public.has_company_access(a.company_id)));
drop policy if exists competitor_scores_write on public.competitor_scores;
create policy competitor_scores_write on public.competitor_scores for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

-- クライアントにも TODO の完了操作だけは許可する場合は、上の todos_write を
-- 消して次を使ってください（done と done_at のみの更新に限定はできないため、
-- 運用で問題が出たら関数経由に切り替えます）。
-- create policy todos_member_update on public.todos for update to authenticated
--   using (public.has_company_access(company_id)) with check (public.has_company_access(company_id));

-- updated_at 自動更新
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists companies_touch on public.companies;
create trigger companies_touch before update on public.companies
  for each row execute function public.touch_updated_at();
