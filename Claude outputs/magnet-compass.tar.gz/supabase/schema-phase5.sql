-- =====================================================================
-- 第5段階：製品の切り替え（採用版マグネット / 集客版コンパス）
-- 何度実行しても安全です。
--
-- 会社ごとに「どちらの点検表を使うか」を持たせる。点検表そのものは
-- コード側（lib/checklist-magnet.ts / lib/checklist-compass.ts）にあり、
-- DB は「どちらを使うか」だけを持つ。項目を DB に置かないのは、
-- 会社間の比較と時系列の進捗を成り立たせるため。
-- =====================================================================

-- ── 会社の製品 ────────────────────────────────────────────────
-- 既存の行はすべて採用版として動いていたので magnet を既定にする。
alter table public.companies
  add column if not exists product text not null default 'magnet';

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'companies_product_check'
  ) then
    alter table public.companies
      add constraint companies_product_check check (product in ('magnet', 'compass'));
  end if;
end $$;

-- ── 点検の実行にも製品を残す ──────────────────────────────────
-- 会社の製品を後から変えても、過去の点検が「どの表で測ったか」が
-- 分かるようにする。これが無いと点数の推移が意味を失う。
alter table public.checklist_runs
  add column if not exists product text not null default 'magnet';

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'checklist_runs_product_check'
  ) then
    alter table public.checklist_runs
      add constraint checklist_runs_product_check check (product in ('magnet', 'compass'));
  end if;
end $$;

-- 製品ごとの最新 run を引く問い合わせが増えるので索引を足す
create index if not exists checklist_runs_company_product_idx
  on public.checklist_runs(company_id, product, created_at desc);

create index if not exists companies_product_idx
  on public.companies(product) where archived = false;
