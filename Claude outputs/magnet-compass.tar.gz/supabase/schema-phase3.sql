-- =====================================================================
-- マグネット 第3段階：点検表とコンテンツ案
-- 何度実行しても安全です。
-- =====================================================================

-- 点検の実行単位
create table if not exists public.checklist_runs (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  summary text,
  ok_count integer not null default 0,
  total_count integer not null default 0,
  score numeric(5,2),
  model text,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null
);
create index if not exists checklist_runs_company_idx on public.checklist_runs(company_id, created_at desc);

-- 項目ごとの判定。item_key はコード側マスター（lib/checklist.ts）と対応する。
create table if not exists public.checklist_results (
  id uuid primary key default gen_random_uuid(),
  run_id uuid not null references public.checklist_runs(id) on delete cascade,
  company_id uuid not null references public.companies(id) on delete cascade,
  item_key text not null,
  status text not null default 'unknown',   -- ok / partial / ng / unknown
  evidence text,
  fix text,
  manual boolean not null default false,     -- 担当者が手で上書きしたか
  created_at timestamptz not null default now()
);
create index if not exists checklist_results_run_idx on public.checklist_results(run_id);
create index if not exists checklist_results_company_idx on public.checklist_results(company_id, item_key);

-- コンテンツ案（ブログ・SNS のネタ）
create table if not exists public.content_ideas (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  title text not null,
  format text,              -- ブログ / X / note / Instagram / YouTube など
  target_question text,     -- 求職者が AI に聞く想定質問
  audience text,            -- 想定読者
  outline text,             -- 中身の骨子
  priority text not null default 'medium',
  used boolean not null default false,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null
);
create index if not exists content_ideas_company_idx on public.content_ideas(company_id, used, created_at desc);

-- RLS
alter table public.checklist_runs enable row level security;
alter table public.checklist_results enable row level security;
alter table public.content_ideas enable row level security;

do $$
declare t text;
begin
  for t in select unnest(array['checklist_runs','checklist_results','content_ideas'])
  loop
    execute format('drop policy if exists %I_select on public.%I', t, t);
    execute format(
      'create policy %I_select on public.%I for select to authenticated using (public.has_company_access(company_id))', t, t);
    execute format('drop policy if exists %I_write on public.%I', t, t);
    execute format(
      'create policy %I_write on public.%I for all to authenticated using (public.is_staff()) with check (public.is_staff())', t, t);
  end loop;
end $$;
