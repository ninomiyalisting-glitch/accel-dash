-- =====================================================================
-- マグネット 第2段階：評価軸の固定
-- 第1段階の schema.sql を実行済みの前提。何度実行しても安全です。
-- =====================================================================

-- 評価軸のセット。会社ごとに 1 つを有効（active）にして使い回す。
-- 作り直すと version が上がり、以前の履歴とは別系列として扱う。
create table if not exists public.criteria_sets (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  version integer not null default 1,
  active boolean not null default true,
  rationale text,
  model text,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null
);
create index if not exists criteria_sets_company_idx on public.criteria_sets(company_id, active);

create table if not exists public.criteria_set_items (
  id uuid primary key default gen_random_uuid(),
  criteria_set_id uuid not null references public.criteria_sets(id) on delete cascade,
  name text not null,
  description text,
  weight numeric(5,2) not null default 10,
  sort_order integer not null default 0
);
create index if not exists criteria_set_items_idx on public.criteria_set_items(criteria_set_id, sort_order);

-- どの評価軸で採点したかを記録する
alter table public.assessments
  add column if not exists criteria_set_id uuid references public.criteria_sets(id) on delete set null;

-- RLS
alter table public.criteria_sets enable row level security;
alter table public.criteria_set_items enable row level security;

drop policy if exists criteria_sets_select on public.criteria_sets;
create policy criteria_sets_select on public.criteria_sets for select to authenticated
  using (public.has_company_access(company_id));
drop policy if exists criteria_sets_write on public.criteria_sets;
create policy criteria_sets_write on public.criteria_sets for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

drop policy if exists criteria_set_items_select on public.criteria_set_items;
create policy criteria_set_items_select on public.criteria_set_items for select to authenticated
  using (exists (select 1 from public.criteria_sets s
                 where s.id = criteria_set_id and public.has_company_access(s.company_id)));
drop policy if exists criteria_set_items_write on public.criteria_set_items;
create policy criteria_set_items_write on public.criteria_set_items for all to authenticated
  using (public.is_staff()) with check (public.is_staff());
