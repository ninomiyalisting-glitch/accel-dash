/**
 * 点検表のハブ。製品ごとの点検表をここで束ねる。
 *
 * 呼び出し側（API・画面）は個別の checklist-magnet / checklist-compass を
 * 直接読まず、必ずここ経由で取る。製品を増やすときはこのファイルに
 * 1 行足すだけで済むようにしてある。
 */
import type { ChecklistItem } from './checklist-types'
import { MAGNET_CHECKLIST, MAGNET_CATEGORIES } from './checklist-magnet'
import { COMPASS_CHECKLIST, COMPASS_CATEGORIES } from './checklist-compass'

export type { ChecklistItem } from './checklist-types'

/** 製品。DB の companies.product / checklist_runs.product と同じ値を使う */
export const PRODUCTS = ['magnet', 'compass'] as const
export type Product = (typeof PRODUCTS)[number]

export const PRODUCT_LABEL: Record<Product, string> = {
  magnet: '採用版（マグネット）',
  compass: '集客版（コンパス）',
}

/** 一覧やタブでの短い表示名 */
export const PRODUCT_SHORT: Record<Product, string> = {
  magnet: '採用',
  compass: '集客',
}

/** その製品が何を測るものかの一文。画面の説明に使う */
export const PRODUCT_NOTE: Record<Product, string> = {
  magnet: '求職者から見た採用の魅力度を点検します',
  compass: '見込み客から見た集客力・訴求力を点検します',
}

type Definition = {
  items: ChecklistItem[]
  categories: readonly string[]
}

const DEFINITIONS: Record<Product, Definition> = {
  magnet: { items: MAGNET_CHECKLIST, categories: MAGNET_CATEGORIES },
  compass: { items: COMPASS_CHECKLIST, categories: COMPASS_CATEGORIES },
}

/**
 * 起動時の自己点検。
 *
 * checklist_results は製品をまたいで item_key ひとつで行を持つので、
 * 製品間でキーが重なると、会社の製品を変えたときに前の製品の判定が
 * 混ざって表示される。目視では気づけないので、ここで落とす。
 * 開発時に必ず通る場所なので、本番へ出る前に発見できる。
 */
function assertKeysAreUnique() {
  const seen = new Map<string, Product>()
  const collisions: string[] = []
  for (const product of PRODUCTS) {
    for (const item of DEFINITIONS[product].items) {
      const owner = seen.get(item.key)
      if (owner && owner !== product) collisions.push(`${item.key}（${owner} と ${product}）`)
      seen.set(item.key, product)
    }
  }
  if (collisions.length > 0) {
    throw new Error(
      `点検項目のキーが製品間で重複しています: ${collisions.join(', ')}。` +
        `checklist_results が製品をまたいで item_key で持つため、片方を改名してください。`
    )
  }
}
assertKeysAreUnique()

/**
 * 未知の値が来ても落とさず magnet に寄せる。
 * DB に古い行（product 列が入る前のもの）が残っていても動くようにするため。
 */
export function toProduct(value: string | null | undefined): Product {
  return value === 'compass' ? 'compass' : 'magnet'
}

export function checklistFor(product: Product): ChecklistItem[] {
  return DEFINITIONS[product].items
}

export function categoriesFor(product: Product): readonly string[] {
  return DEFINITIONS[product].categories
}

/** key から項目を引く表。製品ごとに作る */
export function checklistByKey(product: Product): Map<string, ChecklistItem> {
  return new Map(DEFINITIONS[product].items.map((item) => [item.key, item]))
}
