import type { Product } from './checklist'

/**
 * 製品ごとの言い回し。
 *
 * 採用版と集客版は「誰に向けて何を良くするか」だけが違い、調べ方の骨格は同じ。
 * 文面を丸ごと 2 本持つと片方だけ直して食い違うので、違う語だけをここに集める。
 */
type Voice = {
  /** 調査者の立場 */
  analyst: string
  /** 対象読者 */
  audience: string
  /** 判断される対象の呼び方 */
  asset: string
  /** 実地で見るべき場所 */
  sources: string[]
  /** AI・検索で何と検索して確かめるか（会社名と業種を受け取る） */
  probes: (name: string, industry: string) => string[]
}

const VOICE: Record<Product, Voice> = {
  magnet: {
    analyst: '採用広報と検索・AI 対策の実務者',
    audience: '求職者',
    asset: '採用ページ・求人票',
    sources: [
      '企業サイトと採用ページ（構成、掲載内容、更新日）',
      '自社ドメインの求人票の有無と中身',
      '採用ブログ・オウンドメディアの有無と最終更新',
      'SNS アカウントの有無と最終投稿',
      '口コミサイト（OpenWork、転職会議など）の登録状況と評価',
      '第三者メディアでの言及',
    ],
    probes: (name, industry) => [
      `${name} とはどんな会社か`,
      `${industry}で転職におすすめの会社`,
    ],
  },
  compass: {
    analyst: 'ウェブマーケティングと検索・AI 対策の実務者',
    audience: '見込み客',
    asset: 'サービスサイト・ランディングページ',
    sources: [
      'サービスサイトのトップと主要な下層ページ（構成、訴求、更新日）',
      '料金・事例・よくある質問のページの有無と具体性',
      '問い合わせフォームの項目数と入力しやすさ（スマホでの見え方も）',
      'オウンドメディア・ブログの有無と最終更新',
      'SNS アカウントの有無と最終投稿',
      'Googleビジネスプロフィールと口コミの件数・評価・返信状況',
      '比較サイト、業界メディア、プレスリリースでの掲載',
    ],
    probes: (name, industry) => [
      `${name} の評判`,
      `${industry}のおすすめ業者`,
      `${industry} 依頼 比較`,
    ],
  },
}

type CompanyInput = {
  name: string
  website?: string | null
  industry?: string | null
  notes?: string | null
  competitors: { name: string; website?: string | null }[]
}

function companyBlock(c: CompanyInput) {
  const rivals = c.competitors.length
    ? c.competitors.map((r) => `- ${r.name}${r.website ? `（${r.website}）` : ''}`).join('\n')
    : '（未登録）'

  return [
    `会社名: ${c.name}`,
    `サイト: ${c.website || '（未登録）'}`,
    `業種: ${c.industry || '（未登録）'}`,
    `競合:\n${rivals}`,
    `補足メモ: ${c.notes || '（なし）'}`
  ].join('\n')
}

// ---------------------------------------------------------------------
// 第1段：調査（Web 検索あり・出力は文章）
// ---------------------------------------------------------------------

export function criteriaResearch(c: CompanyInput) {
  return `あなたは日本の採用市場に詳しいアナリストです。以下の企業について、**求職者がこの企業を選ぶかどうかを判断するときに見る基準**を洗い出してください。

${companyBlock(c)}

web_search で、この企業と競合の採用サイト・求人情報・口コミ（OpenWork、転職会議など）・報道を調べ、この業種の求職者が実際に重視している論点を把握してください。

そのうえで評価軸を 8〜12 個に整理し、文章で提案してください。

- **この業種・この求職者層にとって重要な順**に並べる
- 各軸に重み（0〜100 の数値）を割り当て、**合計をちょうど 100 にする**
- 軸は「給与・待遇」のように、**外から観測できる**ものにする。社内文化のように外部から検証できないものは避ける
- 軸名は 15 文字以内。説明は「何を見て判断するか」を 1〜2 文で
- この軸は今後この企業を継続的に採点するための固定の軸になる。**流行や一時的な話題ではなく、数年単位で有効なもの**を選ぶ

最後に、この軸構成にした理由を 3 文以内でまとめてください。`
}

export function scoringResearch(
  c: CompanyInput,
  criteria: { name: string; description: string | null; weight: number }[]
) {
  const axes = criteria
    .map((x) => `- ${x.name}（重み ${x.weight}）：${x.description || ''}`)
    .join('\n')

  const rivalNames = c.competitors.map((r) => r.name)

  return `あなたは日本の採用市場に詳しいアナリストです。以下の企業を、**指定された評価軸のみ**を使って採点してください。軸を追加・削除・改名してはいけません。

${companyBlock(c)}

## 評価軸（固定）
${axes}

## 進め方

1. web_search で、対象企業と競合各社の採用サイト・求人情報・口コミ・報道を調べる
2. 各軸について 0〜100 で採点し、**調べて分かった事実にもとづく根拠**を書く
3. 競合各社（${rivalNames.length ? rivalNames.join('、') : 'なし'}）も同じ軸で採点する
4. 事実が見つからず判断できない軸は 50 点とし、根拠に「公開情報からは確認できず」と明記する

## 採点の基準

- 50 を「同業の平均的な水準」とする
- 80 以上は、明確な根拠がある場合のみ
- 推測で高い点を付けない。**分からないことは分からないと書く**

## 打ち手

採点を踏まえ、この企業が次に取り組むべきことを 3〜6 個提案してください。スコアが低く、かつ自社の努力で動かせる軸を優先します。抽象論ではなく、**着手できる具体的な作業**として書いてください。

最後に、求職者から見た現状を 4 文以内でまとめてください（強みと弱みの両方に触れる）。

以上を文章で出力してください。形式は問いません。`
}

// ---------------------------------------------------------------------
// 第2段：構造化（ツール呼び出しを強制・出力は JSON）
// ---------------------------------------------------------------------

export const CRITERIA_INSTRUCTION =
  '下の調査結果から、評価軸を抽出してツールに登録してください。重みの合計はちょうど 100 にしてください。'

export function scoringInstruction(criteriaNames: string[]) {
  return `下の調査結果から、採点結果・競合スコア・打ち手を抽出してツールに登録してください。

scores には次の軸を**すべて、この表記のまま**含めてください。軸を追加してはいけません。
${criteriaNames.map((n) => `- ${n}`).join('\n')}

調査結果に該当する記述がない軸は、score を 50、rationale を「公開情報からは確認できず」としてください。`
}

export const MENTION_INSTRUCTION =
  '下の回答内容から、言及状況を抽出してツールに登録してください。'

// ---------------------------------------------------------------------
// 点検表
// ---------------------------------------------------------------------

export function checklistResearch(
  c: CompanyInput,
  items: { key: string; category: string; title: string; check: string }[],
  product: Product = 'magnet'
) {
  const v = VOICE[product]
  const list = items
    .map((i) => `### ${i.key}\n項目: ${i.title}\n見るところ: ${i.check}`)
    .join('\n\n')

  const sources = v.sources.map((x) => `- ${x}`).join('\n')
  const probes = v.probes(c.name, c.industry || '')
    .map((q) => `「${q}」`)
    .join('、')

  return `あなたは${v.analyst}です。以下の企業について、点検項目を1つずつ実地で確認してください。

${companyBlock(c)}

## 点検の進め方

web_search を使い、まず次を実際に見てください。

${sources}
- ${probes}を検索し、AI や検索結果に何が出るか

## 判定の原則

- **見つけた事実だけで判断する。** 推測で「ある」と書かないこと
- 確認できなかった項目は正直に「公開情報からは確認できず」とする。ないことの証明は難しいので、断定しない
- 一部だけ満たしている場合はそう書く（例：インタビューが1本だけある）
- ok 以外の項目には、**何をすれば満たせるか**を具体的な作業として書く

## 点検項目

${list}

以上の全項目について、判定と根拠、直し方を文章で書いてください。key は必ず添えてください。`
}

export function checklistInstruction(keys: string[]) {
  return `下の点検結果から、各項目の判定を抽出してツールに登録してください。

results には次の key を**すべて、この表記のまま**含めてください。
${keys.join(', ')}

点検結果に記述が見当たらない key は status を unknown、evidence を「公開情報からは確認できず」としてください。`
}

// ---------------------------------------------------------------------
// コンテンツ案
// ---------------------------------------------------------------------

export function contentResearch(
  c: CompanyInput,
  weakPoints: string[],
  product: Product = 'magnet'
) {
  const v = VOICE[product]
  const designer = product === 'magnet' ? '採用広報のコンテンツ設計者' : 'ウェブマーケティングのコンテンツ設計者'
  const formats =
    product === 'magnet'
      ? '採用ブログ / note / X / Instagram / LinkedIn / YouTube / 採用サイト内ページ'
      : 'ブログ記事 / 導入事例 / 料金・比較ページ / よくある質問 / ホワイトペーパー / X / Instagram / YouTube'
  const readerExample =
    product === 'magnet'
      ? '在職中で情報収集段階の20代エンジニア'
      : '相見積もりを取り始めた段階の、従業員30名規模の製造業の担当者'

  const weak = weakPoints.length
    ? weakPoints.map((w) => `- ${w}`).join('\n')
    : '（点検結果がまだないため、一般的な観点で提案してください）'

  return `あなたは${designer}です。以下の企業が発信すべきネタを洗い出してください。

${companyBlock(c)}

## 点検で弱いと分かっている点
${weak}

## 進め方

1. web_search で、この企業と競合が現在発信している内容を確認する（重複を避けるため）
2. この業種の${v.audience}が実際に検索・AI に投げている質問を調べる
3. 競合が答えていない質問を探す。**そこが取れる場所**

## 提案の要件

20〜30 個出してください。それぞれについて次を明確にします。

- **そのまま使えるタイトル**。「〜について」のような仮題は不可
- **形式**（${formats}）
- **狙う質問**。${v.audience}が AI に投げる具体的な聞き方で書く
- **想定読者**。立場と状況で具体的に（例：${readerExample}）
- **骨子**を2〜3文

## 配分の考え方

- 半分以上は、上の「弱い点」を埋めるものにする
- 検索・AI から引用されやすい題材（数字、比較、手順、Q&A、事例）を優先する
- 単発の告知ではなく、**資産として残る**ものを選ぶ
- SNS 用は継続できる粒度にする（1投稿で完結する軽さ）

文章で出力してください。`
}

export const CONTENT_INSTRUCTION =
  '下の提案から、コンテンツ案を抽出してツールに登録してください。タイトルはそのまま使える形にしてください。'

// ---------------------------------------------------------------------
// AI 言及モニタリング
// ---------------------------------------------------------------------

/** 測定用の質問を作る。ここでだけ社名を使う（質問文には入れさせない）。 */
export function questionsResearch(c: CompanyInput) {
  return `あなたは採用市場の調査設計者です。次の企業が「AI に推薦されているか」を継続的に測るための質問を設計してください。

${companyBlock(c)}

## 重要な制約

**質問文に社名を入れないでください。** 社名を書くと「その会社を知っているか」を聞くことになり、「候補として挙がるか」を測れなくなります。求職者が**まだその会社を知らない状態**で投げる質問にしてください。

## 質問の作り方

web_search で、この業種・この職種の求職者が実際にどう検索・質問しているかを調べてください。そのうえで 5〜7 個を設計します。

- 業種、職種、地域、条件を組み合わせた自然な聞き方にする
- 「おすすめの会社」「働きやすい会社」「将来性のある会社」など、**推薦を求める形**を中心にする
- 1つは条件検索型（例：〇〇県で△△の求人がある会社）を入れる
- 1つは比較型（例：〇〇業界の大手と中小、どちらが良いか）を入れる
- この質問は今後ずっと同じものを使い続ける。**数年単位で有効な聞き方**にする

各質問について、それで何を測るのかも書いてください。`
}

export const QUESTIONS_INSTRUCTION =
  '下の設計から質問を抽出してツールに登録してください。question に社名が含まれていたら、社名を外した形に直してください。'

/** 実測。社名を一切出さずに、素の質問として投げる。 */
export function probePrompt(question: string) {
  return `${question}

web_search で調べたうえで、求職者に向けて答えてください。具体的な企業名を挙げて説明してください。`
}

export function mentionInstruction(companyName: string) {
  return `下の回答文を読み、「${companyName}」がどう扱われたかを判定してツールに登録してください。

- 回答文に ${companyName} が登場したかどうかを、事実として判定する
- 表記ゆれ（正式名称、略称、英語表記）も同一企業として扱う
- 登場した場合、挙げられた企業のうち何番目かを数える
- 登場しなかった場合は mentioned を false、sentiment を absent とし、notes に代わりに挙がった企業名を書く
- competitors_named には、回答文に出てきた企業名を登場順に並べる`
}
