import Anthropic from '@anthropic-ai/sdk'

// 調査と判断はここ。品質に直結するので落とさない。
const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-5'
// 文章を構造に流し込むだけの工程。判断を伴わないので安いモデルで十分。
const EXTRACT_MODEL = process.env.ANTHROPIC_EXTRACT_MODEL || 'claude-haiku-4-5-20251001'

export function claudeAvailable() {
  return Boolean(process.env.ANTHROPIC_API_KEY)
}

function client() {
  return new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! })
}

function webSearch(maxUses: number) {
  return { type: 'web_search_20250305' as const, name: 'web_search' as const, max_uses: maxUses }
}

function textOf(message: Anthropic.Message) {
  return message.content
    .filter((block): block is Anthropic.TextBlock => block.type === 'text')
    .map((block) => block.text)
    .join('\n')
}

/**
 * 第1段：Web 検索しながら調査し、結果を文章で書かせる。
 * ここでは形式を問わないので、検索とツール呼び出しが競合しない。
 */
export async function research(
  prompt: string,
  opts: { maxTokens?: number; maxSearches?: number } = {}
) {
  const message = await client().messages.create({
    model: MODEL,
    max_tokens: opts.maxTokens ?? 8000,
    tools: [webSearch(opts.maxSearches ?? 8)],
    messages: [{ role: 'user', content: prompt }]
  })
  return textOf(message)
}

/**
 * 第2段：調査結果をスキーマに流し込む。ツール呼び出しを強制するので、
 * 返ってくるのは常に妥当な JSON。文字列の引用符や改行で壊れることがない。
 */
export async function structure<T>(args: {
  notes: string
  instruction: string
  toolName: string
  schema: Record<string, unknown>
}): Promise<T> {
  const message = await client().messages.create({
    model: EXTRACT_MODEL,
    max_tokens: 8000,
    tools: [
      {
        name: args.toolName,
        description: '調査結果を構造化して登録する',
        input_schema: args.schema as Anthropic.Tool.InputSchema
      }
    ],
    tool_choice: { type: 'tool', name: args.toolName },
    messages: [
      {
        role: 'user',
        content: `${args.instruction}\n\n## 調査結果\n\n${args.notes}`
      }
    ]
  })

  const call = message.content.find(
    (block): block is Anthropic.ToolUseBlock => block.type === 'tool_use'
  )
  if (!call) throw new Error('構造化に失敗しました（ツール呼び出しが返りませんでした）')

  return call.input as T
}

export function modelName() {
  return MODEL
}

export function extractModelName() {
  return EXTRACT_MODEL
}

export function friendlyError(e: any) {
  const message = String(e?.message || e)
  if (/api key|authentication|401/i.test(message)) {
    return 'Claude の API キーが未設定か無効です（ANTHROPIC_API_KEY を確認してください）'
  }
  if (/not_found/i.test(message) && /model/i.test(message)) {
    return `モデル「${MODEL}」を利用できません。環境変数 ANTHROPIC_MODEL で別のモデルを指定してください`
  }
  if (/rate_limit|429/i.test(message)) {
    return 'Claude 側のレート制限に達しました。少し待ってから再実行してください'
  }
  if (/credit|billing|insufficient/i.test(message)) {
    return 'Claude の利用枠が不足しています（console.anthropic.com で残高と上限を確認してください）'
  }
  if (/overloaded|529/i.test(message)) {
    return 'Claude 側が混み合っています。少し待ってから再実行してください'
  }
  return `分析に失敗しました：${message}`
}

// ---------------------------------------------------------------------
// スキーマ
// ---------------------------------------------------------------------

export const CRITERIA_SCHEMA = {
  type: 'object',
  properties: {
    rationale: { type: 'string', description: 'この軸構成にした理由を3文以内' },
    criteria: {
      type: 'array',
      description: '8〜12 個。重要な順に並べる',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string', description: '軸名。15文字以内' },
          description: { type: 'string', description: '何を見て判断するか。1〜2文' },
          weight: { type: 'number', description: '重み。全体の合計をちょうど100にする' }
        },
        required: ['name', 'description', 'weight']
      }
    }
  },
  required: ['rationale', 'criteria']
} as const

export const SCORING_SCHEMA = {
  type: 'object',
  properties: {
    summary: { type: 'string', description: '求職者から見た現状を4文以内。強みと弱みの両方に触れる' },
    scores: {
      type: 'array',
      description: '指定された評価軸すべて。軸名は完全に一致させる',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' },
          score: { type: 'number', description: '0〜100。50が同業平均。確認できない場合は50' },
          rationale: { type: 'string', description: '調査で分かった事実にもとづく根拠' }
        },
        required: ['name', 'score', 'rationale']
      }
    },
    competitors: {
      type: 'array',
      description: '競合各社を同じ軸で採点した結果。競合が未登録なら空配列',
      items: {
        type: 'object',
        properties: {
          competitor: { type: 'string' },
          name: { type: 'string', description: '軸名' },
          score: { type: 'number' },
          rationale: { type: 'string' }
        },
        required: ['competitor', 'name', 'score']
      }
    },
    recommendations: {
      type: 'array',
      description: '次に取り組むべきこと 3〜6 個',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string', description: '30文字以内の見出し' },
          detail: { type: 'string', description: '何をどうするか。具体的に' },
          priority: { type: 'string', enum: ['high', 'medium', 'low'] },
          effort: { type: 'string', enum: ['小', '中', '大'] }
        },
        required: ['title', 'detail', 'priority']
      }
    }
  },
  required: ['summary', 'scores', 'competitors', 'recommendations']
} as const

export const CHECKLIST_SCHEMA = {
  type: 'object',
  properties: {
    results: {
      type: 'array',
      description: '指定された項目すべて。key は指定されたものと完全に一致させる',
      items: {
        type: 'object',
        properties: {
          key: { type: 'string' },
          status: {
            type: 'string',
            enum: ['ok', 'partial', 'ng', 'unknown'],
            description: 'ok=満たしている / partial=一部だけ / ng=満たしていない / unknown=公開情報から確認できない'
          },
          evidence: { type: 'string', description: 'そう判断した根拠。見つけたページや記述を具体的に' },
          fix: { type: 'string', description: 'ok 以外の場合、何をすれば満たせるか。着手できる作業として' }
        },
        required: ['key', 'status', 'evidence']
      }
    }
  },
  required: ['results']
} as const

export const CONTENT_SCHEMA = {
  type: 'object',
  properties: {
    ideas: {
      type: 'array',
      description: '20〜30 個',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string', description: 'そのまま使える記事・投稿のタイトル' },
          format: {
            type: 'string',
            enum: ['採用ブログ', 'note', 'X', 'Instagram', 'LinkedIn', 'YouTube', '採用サイト内ページ'],
            description: '最も向いている形式'
          },
          target_question: { type: 'string', description: '求職者が AI や検索で投げる想定質問' },
          audience: { type: 'string', description: '想定読者。職種や状況で具体的に' },
          outline: { type: 'string', description: '中身の骨子を2〜3文' },
          priority: { type: 'string', enum: ['high', 'medium', 'low'] }
        },
        required: ['title', 'format', 'target_question', 'audience', 'outline', 'priority']
      }
    }
  },
  required: ['ideas']
} as const

export const QUESTIONS_SCHEMA = {
  type: 'object',
  properties: {
    questions: {
      type: 'array',
      description: '5〜7 個。求職者が実際に投げる聞き方で',
      items: {
        type: 'object',
        properties: {
          question: {
            type: 'string',
            description: '社名を含めない質問文。求職者が AI に打ち込む自然な文で'
          },
          intent: { type: 'string', description: 'この質問で何を測るか。1文' }
        },
        required: ['question', 'intent']
      }
    }
  },
  required: ['questions']
} as const

export const MENTION_SCHEMA = {
  type: 'object',
  properties: {
    mentioned: { type: 'boolean', description: '回答本文にその企業が登場したか' },
    rank_position: {
      type: ['integer', 'null'],
      description: '挙げられた企業のうち何番目か。登場しなければ null'
    },
    sentiment: {
      type: 'string',
      enum: ['positive', 'neutral', 'negative', 'absent'],
      description: 'どのような評価で触れられたか。登場しなければ absent'
    },
    notes: {
      type: 'string',
      description: 'どの文脈で言及されたか。登場しなかった場合は、代わりに挙がった企業名を列挙する'
    },
    competitors_named: {
      type: 'array',
      description: '回答内で挙げられた企業名（登場順）',
      items: { type: 'string' }
    }
  },
  required: ['mentioned', 'sentiment', 'notes', 'competitors_named']
} as const
