import type { Product } from './checklist'

export interface Company {
  id: string
  name: string
  /** どちらの点検表で見る会社か */
  product: Product
  website: string | null
  industry: string | null
  notes: string | null
  archived: boolean
  created_at: string
  updated_at: string
}

export interface Competitor {
  id: string
  company_id: string
  name: string
  website: string | null
  sort_order: number
}

export interface Assessment {
  id: string
  company_id: string
  status: string
  overall_score: number | null
  summary: string | null
  model: string | null
  created_at: string
}

export interface AssessmentCriterion {
  id: string
  assessment_id: string
  name: string
  description: string | null
  weight: number
  score: number | null
  rationale: string | null
  sort_order: number
}

export interface Todo {
  id: string
  company_id: string
  recommendation_id: string | null
  title: string
  detail: string | null
  source: 'auto' | 'manual'
  priority: 'high' | 'medium' | 'low'
  due_on: string | null
  done: boolean
  done_at: string | null
  sort_order: number
  created_at: string
}
