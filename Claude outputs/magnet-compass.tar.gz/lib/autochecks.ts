/**
 * コードで確実に判定できる項目。
 * LLM に推測させるより速く、安く、そして正確。
 * 判定できなかった場合は unknown を返し、LLM 側の判定に委ねる。
 */

export type AutoResult = {
  status: 'ok' | 'partial' | 'ng' | 'unknown'
  evidence: string
  fix?: string
}

const TIMEOUT_MS = 8000
const AI_CRAWLERS = ['GPTBot', 'ClaudeBot', 'anthropic-ai', 'PerplexityBot', 'Google-Extended']

async function get(url: string) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS)
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: { 'User-Agent': 'AccelDash-Magnet/1.0 (recruitment audit)' }
    })
    const body = res.ok ? await res.text() : ''
    return { ok: res.ok, status: res.status, body, finalUrl: res.url }
  } catch {
    return { ok: false, status: 0, body: '', finalUrl: url }
  } finally {
    clearTimeout(timer)
  }
}

function originOf(website: string) {
  try {
    return new URL(website.startsWith('http') ? website : `https://${website}`).origin
  } catch {
    return null
  }
}

/** JSON-LD の @type を全部集める（配列・@graph・入れ子に対応） */
function jsonLdTypes(html: string) {
  const types = new Set<string>()
  const blocks = html.matchAll(
    /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi
  )

  for (const block of blocks) {
    let parsed: unknown
    try {
      parsed = JSON.parse(block[1].trim())
    } catch {
      // 壊れた JSON-LD は型名だけ拾う
      for (const m of block[1].matchAll(/"@type"\s*:\s*"([^"]+)"/g)) types.add(m[1])
      continue
    }
    const walk = (node: any) => {
      if (!node || typeof node !== 'object') return
      if (Array.isArray(node)) return node.forEach(walk)
      const t = node['@type']
      if (typeof t === 'string') types.add(t)
      if (Array.isArray(t)) t.forEach((x) => typeof x === 'string' && types.add(x))
      Object.values(node).forEach(walk)
    }
    walk(parsed)
  }
  return types
}

/** トップページから採用系ページの URL を推定する */
function findRecruitUrls(html: string, origin: string) {
  const found = new Set<string>()
  const pattern = /href=["']([^"']+)["'][^>]*>([^<]{0,80})/gi
  for (const m of html.matchAll(pattern)) {
    const href = m[1]
    const label = m[2]
    const hay = `${href} ${label}`.toLowerCase()
    if (!/recruit|career|saiyo|採用|求人|新卒|中途/.test(hay)) continue
    try {
      const abs = new URL(href, origin)
      if (abs.origin === origin) found.add(abs.toString())
    } catch {
      /* 無効な href は無視 */
    }
  }
  return Array.from(found).slice(0, 4)
}

export async function runAutoChecks(website: string | null): Promise<Record<string, AutoResult>> {
  const out: Record<string, AutoResult> = {}
  const keys = [
    'tech-ai-crawlers',
    'tech-sitemap',
    'tech-https-mobile',
    'tech-jobposting',
    'tech-organization',
    'tech-faqpage',
    'tech-canonical-name'
  ]

  if (!website) {
    for (const key of keys) {
      out[key] = { status: 'unknown', evidence: 'サイト URL が未登録のため自動判定できず' }
    }
    return out
  }

  const origin = originOf(website)
  if (!origin) {
    for (const key of keys) {
      out[key] = { status: 'unknown', evidence: `サイト URL の形式が不正：${website}` }
    }
    return out
  }

  const [robots, sitemap, home] = await Promise.all([
    get(`${origin}/robots.txt`),
    get(`${origin}/sitemap.xml`),
    get(origin)
  ])

  // ── AI クローラーの許可 ────────────────────────────────────
  if (!robots.ok) {
    out['tech-ai-crawlers'] = {
      status: 'ok',
      evidence: 'robots.txt が存在しないため、クローラーは全て許可されている状態'
    }
  } else {
    const blocked: string[] = []
    // User-agent ブロック単位で解析する
    const sections = robots.body.split(/\n(?=user-agent:)/i)
    for (const section of sections) {
      const agents = Array.from(section.matchAll(/^user-agent:\s*(.+)$/gim)).map((m) =>
        m[1].trim().toLowerCase()
      )
      const disallowsRoot = /^disallow:\s*\/\s*$/im.test(section)
      if (!disallowsRoot) continue
      for (const crawler of AI_CRAWLERS) {
        if (agents.includes(crawler.toLowerCase())) blocked.push(crawler)
      }
      if (agents.includes('*')) blocked.push('* (全クローラー)')
    }

    out['tech-ai-crawlers'] = blocked.length
      ? {
          status: 'ng',
          evidence: `robots.txt が次をブロックしています：${Array.from(new Set(blocked)).join('、')}`,
          fix: 'robots.txt から該当の Disallow: / を削除する。ここを開けない限り AI 側の対策は届きません'
        }
      : {
          status: 'ok',
          evidence: 'robots.txt に主要 AI クローラーの全面ブロックは見当たりません'
        }
  }

  // ── sitemap ────────────────────────────────────────────────
  if (!sitemap.ok) {
    out['tech-sitemap'] = {
      status: 'ng',
      evidence: `${origin}/sitemap.xml が取得できません（HTTP ${sitemap.status || '接続失敗'}）`,
      fix: 'sitemap.xml を生成し、採用・求人ページを含めて robots.txt から参照させる'
    }
  } else {
    const hasRecruit = /recruit|career|saiyo|採用|求人|job/i.test(sitemap.body)
    out['tech-sitemap'] = hasRecruit
      ? { status: 'ok', evidence: 'sitemap.xml に採用・求人らしい URL が含まれています' }
      : {
          status: 'partial',
          evidence: 'sitemap.xml はありますが、採用・求人の URL が見当たりません（索引形式の可能性あり）',
          fix: '採用・求人ページを sitemap に含める'
        }
  }

  // ── HTTPS とスマホ対応 ─────────────────────────────────────
  const isHttps = origin.startsWith('https://')
  const hasViewport = /<meta[^>]+name=["']viewport["']/i.test(home.body)
  if (!home.ok) {
    out['tech-https-mobile'] = {
      status: 'unknown',
      evidence: `トップページを取得できませんでした（HTTP ${home.status || '接続失敗'}）`
    }
  } else if (isHttps && hasViewport) {
    out['tech-https-mobile'] = {
      status: 'ok',
      evidence: 'HTTPS で配信され、viewport 指定もあります'
    }
  } else {
    const problems = [
      !isHttps ? 'HTTPS ではありません' : null,
      !hasViewport ? 'viewport 指定が見当たりません（スマホ対応が疑わしい）' : null
    ].filter(Boolean)
    out['tech-https-mobile'] = {
      status: 'ng',
      evidence: problems.join(' / '),
      fix: !isHttps ? 'サイト全体を HTTPS に移行する' : 'viewport メタタグを追加し、レスポンシブ対応にする'
    }
  }

  // ── 構造化データ（採用系ページも見る） ──────────────────────
  const recruitUrls = home.ok ? findRecruitUrls(home.body, origin) : []
  const pages = await Promise.all(recruitUrls.map((u) => get(u)))
  const allHtml = [home, ...pages].filter((p) => p.ok).map((p) => p.body)
  const types = new Set<string>()
  for (const html of allHtml) for (const t of jsonLdTypes(html)) types.add(t)

  const scanned = allHtml.length
  const scannedNote =
    scanned === 0
      ? 'ページを取得できず判定できませんでした'
      : `トップページと採用系 ${recruitUrls.length} ページを走査`

  if (scanned === 0) {
    for (const key of ['tech-jobposting', 'tech-organization', 'tech-faqpage']) {
      out[key] = { status: 'unknown', evidence: scannedNote }
    }
  } else {
    out['tech-jobposting'] = types.has('JobPosting')
      ? { status: 'ok', evidence: `JobPosting 構造化データを検出（${scannedNote}）` }
      : {
          status: 'ng',
          evidence: `JobPosting 構造化データが見当たりません（${scannedNote}）`,
          fix: '求人ページに schema.org の JobPosting を実装する。title, datePosted, hiringOrganization, jobLocation, baseSalary を埋める'
        }

    const hasOrg = ['Organization', 'Corporation', 'LocalBusiness'].some((t) => types.has(t))
    out['tech-organization'] = hasOrg
      ? { status: 'ok', evidence: `Organization 系の構造化データを検出（${scannedNote}）` }
      : {
          status: 'ng',
          evidence: `Organization 構造化データが見当たりません（${scannedNote}）`,
          fix: 'トップページに Organization を実装し、name / logo / url / sameAs（SNS や第三者ページ）を記述する'
        }

    out['tech-faqpage'] = types.has('FAQPage')
      ? { status: 'ok', evidence: `FAQPage 構造化データを検出（${scannedNote}）` }
      : {
          status: 'ng',
          evidence: `FAQPage 構造化データが見当たりません（${scannedNote}）`,
          fix: '採用の FAQ ページを作り、FAQPage 構造化データを付ける。AI がそのまま引用できる形になる'
        }
  }

  // ── ページタイトルに会社名 ─────────────────────────────────
  if (!home.ok) {
    out['tech-canonical-name'] = { status: 'unknown', evidence: 'ページを取得できませんでした' }
  } else {
    const titles = [home, ...pages]
      .filter((p) => p.ok)
      .map((p) => p.body.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim())
      .filter(Boolean) as string[]
    out['tech-canonical-name'] = titles.length
      ? {
          status: 'partial',
          evidence: `検出したタイトル：${titles.slice(0, 3).join(' / ')}（会社名と職種が入っているか確認してください）`,
          fix: '採用ページの title に「会社名 + 職種 + 採用」を含める'
        }
      : { status: 'unknown', evidence: 'title タグを検出できませんでした' }
  }

  return out
}

/** コードで判定する項目のキー */
export const AUTO_KEYS = [
  'tech-ai-crawlers',
  'tech-sitemap',
  'tech-https-mobile',
  'tech-jobposting',
  'tech-organization',
  'tech-faqpage',
  'tech-canonical-name'
] as const
