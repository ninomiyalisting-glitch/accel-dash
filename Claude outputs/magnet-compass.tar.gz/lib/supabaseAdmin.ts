import { createClient } from '@supabase/supabase-js'

const url = process.env.NEXT_PUBLIC_SUPABASE_URL || ''
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || ''

export const supabaseAdmin = createClient(url, serviceKey, {
  auth: { autoRefreshToken: false, persistSession: false }
})

export const STAFF_DOMAIN = '@accel-partners.co.jp'

export type Viewer = {
  id: string
  email: string
  isStaff: boolean
  /** 自社スタッフなら null（全社アクセス可）、クライアントなら所属会社 ID */
  companyIds: string[] | null
}

export type AuthResult =
  | { ok: true; viewer: Viewer }
  | { ok: false; message: string; status: number }

/** Authorization ヘッダーの JWT を検証し、閲覧できる会社の範囲まで解決する */
export async function requireViewer(req: Request): Promise<AuthResult> {
  if (!url || !serviceKey) {
    return { ok: false, status: 500, message: 'サーバー設定エラー：Supabase のキーが読み込めていません' }
  }

  const token = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '').trim()
  if (!token) return { ok: false, status: 401, message: '認証トークンが送られていません（再ログインしてください）' }

  const { data, error } = await supabaseAdmin.auth.getUser(token)
  if (error) return { ok: false, status: 401, message: `トークンの検証に失敗しました：${error.message}` }

  const user = data?.user
  if (!user?.email) return { ok: false, status: 401, message: 'ユーザー情報を取得できませんでした' }

  const isStaff = user.email.endsWith(STAFF_DOMAIN)
  if (isStaff) {
    return { ok: true, viewer: { id: user.id, email: user.email, isStaff: true, companyIds: null } }
  }

  const { data: rows } = await supabaseAdmin
    .from('company_members')
    .select('company_id')
    .eq('user_id', user.id)

  return {
    ok: true,
    viewer: {
      id: user.id,
      email: user.email,
      isStaff: false,
      companyIds: (rows ?? []).map((r) => r.company_id as string)
    }
  }
}

/** 更新系は自社スタッフのみ */
export async function requireStaff(req: Request): Promise<AuthResult> {
  const auth = await requireViewer(req)
  if (!auth.ok) return auth
  if (!auth.viewer.isStaff) {
    return { ok: false, status: 403, message: 'この操作は担当者アカウントのみ行えます' }
  }
  return auth
}

export function canSee(viewer: Viewer, companyId: string) {
  return viewer.companyIds === null || viewer.companyIds.includes(companyId)
}
