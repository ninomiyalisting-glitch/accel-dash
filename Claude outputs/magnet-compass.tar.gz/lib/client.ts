'use client'

import { supabase } from './supabase'

export async function authHeaders(extra: Record<string, string> = {}) {
  const { data } = await supabase.auth.getSession()
  return { ...extra, Authorization: `Bearer ${data.session?.access_token ?? ''}` }
}

async function readError(res: Response, fallback: string) {
  try {
    const body = await res.json()
    return body?.error || fallback
  } catch {
    return fallback
  }
}

/** 失敗時は Error を投げる。呼び出し側で message をそのまま画面に出せる。 */
export async function api<T>(
  path: string,
  init: { method?: string; body?: unknown } = {}
): Promise<T> {
  const hasBody = init.body !== undefined
  const res = await fetch(path, {
    method: init.method ?? 'GET',
    headers: await authHeaders(hasBody ? { 'Content-Type': 'application/json' } : {}),
    body: hasBody ? JSON.stringify(init.body) : undefined
  })

  if (!res.ok) throw new Error(await readError(res, '通信に失敗しました'))
  if (res.status === 204) return undefined as T
  return res.json() as Promise<T>
}
