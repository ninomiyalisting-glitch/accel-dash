/** 点検表の項目定義。製品をまたいで共通。 */
export type ChecklistItem = {
  key: string
  category: string
  title: string
  /** 何を見て判断するか */
  check: string
  /** なぜ重要か。クライアントへの説明にそのまま使える文にする */
  why: string
  /** 3 = 効果が大きい / 2 = 標準 / 1 = あると良い */
  weight: 1 | 2 | 3
  /** AI や検索から見つけられるかに直接効く項目 */
  aio?: boolean
  /** 月ごとに変わりやすい項目。差分点検の対象 */
  volatile?: boolean
  /** コードで確実に判定できる項目 */
  auto?: boolean
}
