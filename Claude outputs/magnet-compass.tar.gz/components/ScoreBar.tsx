'use client'

/** 単系列の横棒。データ端を 4px 丸め、ベースラインに接地させる。 */
export default function ScoreBar({ score }: { score: number | null }) {
  const value = score ?? 0

  return (
    <div className="flex items-center gap-3">
      <div className="relative h-2.5 flex-1 rounded-sm bg-surface-muted">
        <div
          className="absolute inset-y-0 left-0 rounded-sm bg-accel-primary"
          style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
        />
        {/* 平均水準（50）の目印 */}
        <div className="absolute inset-y-[-3px] left-1/2 w-px bg-black/20" aria-hidden />
      </div>
      <span className="w-12 shrink-0 text-right text-sm tabular-nums">
        {score === null ? '—' : Math.round(score)}
      </span>
    </div>
  )
}
