'use client'

import { useState } from 'react'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts'
import type { Assessment } from './ScoreTab'
import { LineChart as LineIcon } from 'lucide-react'

const GREEN = '#279300'

export default function HistoryTab({ history }: { history: Assessment[] }) {
  // 古い順に並べる（時系列は左から右へ）
  const runs = history.slice().reverse()
  const axisNames = Array.from(
    new Set(runs.flatMap((r) => r.assessment_criteria.map((c) => c.name)))
  )
  const [selected, setSelected] = useState<string>('__overall__')

  if (runs.length === 0) {
    return (
      <section className="rounded-2xl border border-border-soft bg-surface p-10 text-center">
        <LineIcon size={28} className="mx-auto mb-3 text-accel-secondary" />
        <h3 className="mb-2">まだ履歴がありません</h3>
        <p className="mx-auto max-w-lg text-sm text-black/70">
          「スコア」タブで採点すると、ここに推移が積み上がります。同じ評価軸で採点するので、
          変化は実際に何かが動いたことを表します。
        </p>
      </section>
    )
  }

  const label = selected === '__overall__' ? '総合スコア' : selected

  const data = runs.map((run) => ({
    date: new Date(run.created_at).toLocaleDateString('ja-JP', { month: 'numeric', day: 'numeric' }),
    full: new Date(run.created_at).toLocaleString('ja-JP'),
    value:
      selected === '__overall__'
        ? run.overall_score === null
          ? null
          : Number(run.overall_score)
        : (run.assessment_criteria.find((c) => c.name === selected)?.score ?? null) === null
          ? null
          : Number(run.assessment_criteria.find((c) => c.name === selected)!.score)
  }))

  const latest = runs[runs.length - 1]
  const previous = runs.length > 1 ? runs[runs.length - 2] : null

  const deltaOf = (name: string) => {
    const now = latest.assessment_criteria.find((c) => c.name === name)?.score
    const before = previous?.assessment_criteria.find((c) => c.name === name)?.score
    if (now === null || now === undefined || before === null || before === undefined) return null
    return Math.round((Number(now) - Number(before)) * 10) / 10
  }

  return (
    <section className="flex flex-col gap-6">
      <div className="rounded-2xl border border-border-soft bg-surface p-6">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3>{label}の推移</h3>
            <p className="text-sm text-black/60">{runs.length} 回分の採点</p>
          </div>
          <select
            value={selected}
            onChange={(e) => setSelected(e.target.value)}
            className="sm:w-64"
            aria-label="表示する項目"
          >
            <option value="__overall__">総合スコア</option>
            {axisNames.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>

        <div style={{ width: '100%', height: 300 }}>
          <ResponsiveContainer>
            <LineChart data={data} margin={{ top: 8, right: 16, bottom: 0, left: -16 }}>
              <CartesianGrid stroke="#e6ede0" vertical={false} />
              <XAxis
                dataKey="date"
                tick={{ fill: '#6b7266', fontSize: 12 }}
                stroke="#dbe8c8"
                tickLine={false}
              />
              <YAxis
                domain={[0, 100]}
                tick={{ fill: '#6b7266', fontSize: 12 }}
                stroke="#dbe8c8"
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  borderRadius: 8,
                  border: '1px solid #dbe8c8',
                  fontSize: 13,
                  fontFamily: 'inherit'
                }}
                labelFormatter={(_, payload) => payload?.[0]?.payload?.full ?? ''}
                formatter={(value: any) => [value ?? '—', label]}
              />
              <Line
                type="monotone"
                dataKey="value"
                stroke={GREEN}
                strokeWidth={2}
                dot={{ r: 4, fill: GREEN, strokeWidth: 0 }}
                activeDot={{ r: 6, fill: GREEN, stroke: '#ffffff', strokeWidth: 2 }}
                connectNulls
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-2xl border border-border-soft bg-surface p-6">
        <h3 className="mb-1">前回からの変化</h3>
        <p className="mb-5 text-sm text-black/60">
          {previous
            ? `${new Date(previous.created_at).toLocaleDateString('ja-JP')} → ${new Date(latest.created_at).toLocaleDateString('ja-JP')}`
            : '比較できる前回の採点がまだありません'}
        </p>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[420px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-border-soft text-left">
                <th className="py-2 pr-4 font-semibold">軸</th>
                <th className="py-2 pr-4 text-right font-semibold">今回</th>
                <th className="py-2 pr-4 text-right font-semibold">変化</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-border-soft">
                <td className="py-2 pr-4 font-semibold">総合</td>
                <td className="py-2 pr-4 text-right font-semibold tabular-nums">
                  {latest.overall_score ?? '—'}
                </td>
                <td className="py-2 pr-4 text-right tabular-nums">
                  <Delta
                    value={
                      previous && latest.overall_score !== null && previous.overall_score !== null
                        ? Math.round((Number(latest.overall_score) - Number(previous.overall_score)) * 10) / 10
                        : null
                    }
                  />
                </td>
              </tr>
              {latest.assessment_criteria
                .slice()
                .sort((a, b) => a.sort_order - b.sort_order)
                .map((c) => (
                  <tr key={c.name} className="border-b border-border-soft/60">
                    <td className="py-2 pr-4">{c.name}</td>
                    <td className="py-2 pr-4 text-right tabular-nums">
                      {c.score === null ? '—' : Math.round(Number(c.score))}
                    </td>
                    <td className="py-2 pr-4 text-right tabular-nums">
                      <Delta value={deltaOf(c.name)} />
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  )
}

function Delta({ value }: { value: number | null }) {
  if (value === null) return <span className="text-black/40">—</span>
  if (value === 0) return <span className="text-black/50">±0</span>

  const up = value > 0
  return (
    <span className={up ? 'text-accel-primary' : 'text-red-700'}>
      {up ? '▲' : '▼'} {Math.abs(value)}
    </span>
  )
}
