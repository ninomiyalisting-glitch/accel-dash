'use client'

import { useState } from 'react'
import { api } from '@/lib/client'
import { UserPlus, Trash2, Users } from 'lucide-react'

export type Member = {
  company_id: string
  user_id: string
  email: string | null
  role: string
  created_at: string
}

export default function MembersPanel({
  companyId,
  members,
  onMembers,
  onError,
  onNotice
}: {
  companyId: string
  members: Member[]
  onMembers: (next: Member[]) => void
  onError: (m: string) => void
  onNotice: (m: string) => void
}) {
  const [email, setEmail] = useState('')
  const [busy, setBusy] = useState(false)
  const [confirming, setConfirming] = useState<string | null>(null)

  async function add() {
    if (!email.trim()) return
    setBusy(true)
    try {
      const res = await api<{ message: string }>('/api/members', {
        method: 'POST',
        body: { company_id: companyId, email }
      })
      setEmail('')
      onMembers(await api<Member[]>(`/api/members?company_id=${companyId}`))
      onNotice(res.message)
    } catch (e: any) {
      onError(e.message)
    }
    setBusy(false)
  }

  async function remove(userId: string) {
    setConfirming(null)
    try {
      await api(`/api/members?company_id=${companyId}&user_id=${userId}`, { method: 'DELETE' })
      onMembers(members.filter((m) => m.user_id !== userId))
      onNotice('閲覧権を外しました')
    } catch (e: any) {
      onError(e.message)
    }
  }

  return (
    <div className="rounded-2xl border border-border-soft bg-surface p-6">
      <div className="mb-4 flex items-center gap-2">
        <Users size={18} className="text-accel-secondary" />
        <h3>クライアントのアクセス権</h3>
      </div>

      <p className="mb-4 text-sm text-black/60">
        ここに登録した方は、この会社のデータだけを閲覧できます（編集はできません）。
        未登録のアドレスには招待メールが送られます。
        <br />
        @accel-partners.co.jp のアカウントは全クライアントを見られるので、登録は不要です。
      </p>

      <div className="mb-5 flex flex-wrap gap-3">
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && add()}
          placeholder="client@example.co.jp"
          className="min-w-[240px] flex-1"
        />
        <button
          onClick={add}
          disabled={busy}
          className="flex items-center gap-2 rounded-lg bg-accel-primary px-5 py-3 text-white hover:bg-accel-hover active:bg-accel-active"
        >
          <UserPlus size={18} />
          {busy ? '処理中…' : '権限を付与'}
        </button>
      </div>

      {members.length === 0 ? (
        <p className="text-sm text-black/60">まだ誰も登録されていません。</p>
      ) : (
        <ul className="flex flex-col gap-2">
          {members.map((m) => (
            <li key={m.user_id} className="rounded-xl border border-border-soft px-4 py-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate font-semibold">{m.email ?? m.user_id}</p>
                  <p className="text-xs text-black/50">
                    付与日：{new Date(m.created_at).toLocaleDateString('ja-JP')}
                  </p>
                </div>
                <button
                  onClick={() => setConfirming(m.user_id)}
                  aria-label="閲覧権を外す"
                  className="shrink-0 rounded-lg p-2 text-red-600 hover:bg-red-50"
                >
                  <Trash2 size={16} />
                </button>
              </div>

              {confirming === m.user_id && (
                <div className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-lg bg-red-50 px-4 py-3">
                  <span className="text-sm text-red-800">
                    {m.email} の閲覧権を外しますか？アカウント自体は残ります。
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => remove(m.user_id)}
                      className="rounded-lg bg-red-600 px-4 py-2 text-sm text-white hover:bg-red-700"
                    >
                      外す
                    </button>
                    <button
                      onClick={() => setConfirming(null)}
                      className="rounded-lg border-2 border-border-soft bg-surface px-4 py-2 text-sm"
                    >
                      やめる
                    </button>
                  </div>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
