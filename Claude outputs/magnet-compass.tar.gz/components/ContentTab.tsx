'use client'

import { useMemo, useState } from 'react'
import { api } from '@/lib/client'
import { Lightbulb, Plus, Check, Trash2, Sparkles } from 'lucide-react'

export type ContentIdea = {
  id: string
  title: string
  format: string | null
  target_question: string | null
  audience: string | null
  outline: string | null
  priority: 'high' | 'medium' | 'low'
  used: boolean
  created_at: string
}

const PRIORITY_LABEL: Record<string, string> = { high: '高', medium: '中', low: '低' }

export default function ContentTab({
  companyId,
  isStaff,
  ideas,
  onIdeas,
  onTodosChanged,
  onError,
  onNotice
}: {
  companyId: string
  isStaff: boolean
  ideas: ContentIdea[]
  onIdeas: (next: ContentIdea[]) => void
  onTodosChanged: () => void
  onError: (m: string) => void
  onNotice: (m: string) => void
}) {
  const [generating, setGenerating] = useState(false)
  const [format, setFormat] = useState('all')
  const [showUsed, setShowUsed] = useState(false)

  const formats = useMemo(
    () => Array.from(new Set(ideas.map((i) => i.format).filter(Boolean))) as string[],
    [ideas]
  )

  const rows = ideas.filter((i) => {
    if (!showUsed && i.used) return false
    if (format !== 'all' && i.format !== format) return false
    return true
  })

  async function generate() {
    setGenerating(true)
    try {
      const created = await api<ContentIdea[]>('/api/content', {
        method: 'POST',
        body: { company_id: companyId }
      })
      onIdeas([...created, ...ideas])
      onNotice(`${created.length} 件のネタを追加しました`)
    } catch (e: any) {
      onError(e.message)
    }
    setGenerating(false)
  }

  async function toTodo(idea: ContentIdea) {
    try {
      await api('/api/content', { method: 'PATCH', body: { action: 'to_todo', id: idea.id } })
      onIdeas(ideas.map((i) => (i.id === idea.id ? { ...i, used: true } : i)))
      onTodosChanged()
      onNotice('「やること」に追加しました')
    } catch (e: any) {
      onError(e.message)
    }
  }

  async function toggleUsed(idea: ContentIdea) {
    onIdeas(ideas.map((i) => (i.id === idea.id ? { ...i, used: !i.used } : i)))
    try {
      await api('/api/content', { method: 'PATCH', body: { id: idea.id, used: !idea.used } })
    } catch (e: any) {
      onIdeas(ideas.map((i) => (i.id === idea.id ? { ...i, used: idea.used } : i)))
      onError(e.message)
    }
  }

  async function remove(id: string) {
    const before = ideas
    onIdeas(ideas.filter((i) => i.id !== id))
    try {
      await api(`/api/content?id=${id}`, { method: 'DELETE' })
    } catch (e: any) {
      onIdeas(before)
      onError(e.message)
    }
  }

  if (ideas.length === 0) {
    return (
      <section className="rounded-2xl border border-border-soft bg-surface p-10 text-center">
        <Lightbulb size={28} className="mx-auto mb-3 text-accel-secondary" />
        <h3 className="mb-2">発信するネタを洗い出します</h3>
        <p className="mx-auto mb-6 max-w-xl text-sm text-black/70">
          点検で弱かった箇所と、競合が答えていない質問をもとに、採用ブログや SNS のネタを 20〜30 本出します。
          求職者が AI に投げる質問を起点にするので、書けば引用されうる題材が並びます。
        </p>
        {isStaff ? (
          <button
            onClick={generate}
            disabled={generating}
            className="rounded-lg bg-accel-primary px-6 py-3 text-white hover:bg-accel-hover active:bg-accel-active"
          >
            {generating ? '調査中… 2〜3分かかります' : 'ネタを出す'}
          </button>
        ) : (
          <p className="text-sm text-black/60">担当者が作成すると表示されます。</p>
        )}
      </section>
    )
  }

  return (
    <section className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center gap-3">
        <select
          value={format}
          onChange={(e) => setFormat(e.target.value)}
          className="sm:w-52"
          aria-label="形式で絞り込む"
        >
          <option value="all">すべての形式</option>
          {formats.map((f) => (
            <option key={f} value={f}>
              {f}
            </option>
          ))}
        </select>

        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={showUsed}
            onChange={(e) => setShowUsed(e.target.checked)}
            style={{ minHeight: 'auto', width: '18px', padding: 0 }}
            className="h-[18px] w-[18px] accent-accel-primary"
          />
          着手済みも表示
        </label>

        <p className="text-sm text-black/60">{rows.length} 件</p>

        {isStaff && (
          <button
            onClick={generate}
            disabled={generating}
            className="ml-auto flex items-center gap-2 rounded-lg border-2 border-border-soft px-4 py-2 text-sm hover:border-accel-secondary"
          >
            <Sparkles size={16} />
            {generating ? '調査中…' : 'さらに出す'}
          </button>
        )}
      </div>

      <div className="overflow-x-auto rounded-2xl border border-border-soft bg-surface">
        <table className="w-full min-w-[900px] border-collapse text-sm">
          <thead>
            <tr className="border-b border-border-soft bg-surface-muted text-left">
              <th className="w-16 px-4 py-3 font-semibold">優先</th>
              <th className="w-28 px-4 py-3 font-semibold">形式</th>
              <th className="px-4 py-3 font-semibold">タイトルと骨子</th>
              <th className="px-4 py-3 font-semibold">狙う質問</th>
              <th className="w-44 px-4 py-3 font-semibold">想定読者</th>
              {isStaff && <th className="w-24 px-4 py-3 font-semibold">操作</th>}
            </tr>
          </thead>
          <tbody>
            {rows.map((idea) => (
              <tr
                key={idea.id}
                className={`border-b border-border-soft/60 align-top ${idea.used ? 'opacity-50' : ''}`}
              >
                <td className="px-4 py-4">
                  <span
                    className={
                      idea.priority === 'high'
                        ? 'rounded bg-accel-lightest px-2 py-0.5 text-xs text-accel-dark'
                        : 'rounded bg-surface-muted px-2 py-0.5 text-xs text-black/60'
                    }
                  >
                    {PRIORITY_LABEL[idea.priority] ?? '中'}
                  </span>
                </td>
                <td className="px-4 py-4 text-black/60">{idea.format ?? '—'}</td>
                <td className="px-4 py-4">
                  <p className={idea.used ? 'font-semibold line-through' : 'font-semibold'}>
                    {idea.title}
                  </p>
                  {idea.outline && <p className="mt-1 text-black/60">{idea.outline}</p>}
                </td>
                <td className="px-4 py-4 text-black/70">{idea.target_question ?? '—'}</td>
                <td className="px-4 py-4 text-black/60">{idea.audience ?? '—'}</td>
                {isStaff && (
                  <td className="px-4 py-4">
                    <div className="flex gap-1">
                      {!idea.used && (
                        <button
                          onClick={() => toTodo(idea)}
                          aria-label="やることに追加"
                          className="rounded-lg border-2 border-border-soft p-2 hover:border-accel-secondary"
                        >
                          <Plus size={14} />
                        </button>
                      )}
                      <button
                        onClick={() => toggleUsed(idea)}
                        aria-label={idea.used ? '未着手に戻す' : '着手済みにする'}
                        className="rounded-lg border-2 border-border-soft p-2 hover:border-accel-secondary"
                      >
                        <Check size={14} />
                      </button>
                      <button
                        onClick={() => remove(idea.id)}
                        aria-label="削除"
                        className="rounded-lg p-2 text-red-600 hover:bg-red-50"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}
