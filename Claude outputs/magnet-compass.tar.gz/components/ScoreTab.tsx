'use client'

import { useState } from 'react'
import { api } from '@/lib/client'
import ScoreBar from './ScoreBar'
import { Sparkles, RefreshCw, Pencil, Check } from 'lucide-react'

type Item = { id: string; name: string; description: string | null; weight: number; sort_order: number }
type CriteriaSet = {
  id: string
  version: number
  rationale: string | null
  criteria_set_items: Item[]
}
type Criterion = {
  name: string
  description: string | null
  weight: number
  score: number | null
  rationale: string | null
  sort_order: number
}
type RivalScore = { competitor_name: string; criteria_name: string; score: number | null }
export type Assessment = {
  id: string
  overall_score: number | null
  summary: string | null
  created_at: string
  assessment_criteria: Criterion[]
  competitor_scores: RivalScore[]
}

export default function ScoreTab({
  companyId,
  isStaff,
  criteriaSet,
  latest,
  onCriteriaChange,
  onScored,
  onError
}: {
  companyId: string
  isStaff: boolean
  criteriaSet: CriteriaSet | null
  latest: Assessment | null
  onCriteriaChange: (set: CriteriaSet) => void
  onScored: (assessment: Assessment) => void
  onError: (message: string) => void
}) {
  const [building, setBuilding] = useState(false)
  const [scoring, setScoring] = useState(false)
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState<Item[]>([])

  async function buildCriteria() {
    setBuilding(true)
    try {
      const set = await api<CriteriaSet>('/api/criteria', {
        method: 'POST',
        body: { company_id: companyId }
      })
      onCriteriaChange(set)
    } catch (e: any) {
      onError(e.message)
    }
    setBuilding(false)
  }

  async function runScoring() {
    setScoring(true)
    try {
      const assessment = await api<Assessment>('/api/assessments', {
        method: 'POST',
        body: { company_id: companyId }
      })
      onScored(assessment)
    } catch (e: any) {
      onError(e.message)
    }
    setScoring(false)
  }

  async function saveCriteria() {
    try {
      await api('/api/criteria', { method: 'PATCH', body: { items: draft } })
      onCriteriaChange({ ...criteriaSet!, criteria_set_items: draft })
      setEditing(false)
    } catch (e: any) {
      onError(e.message)
    }
  }

  const items = (criteriaSet?.criteria_set_items ?? []).slice().sort((a, b) => a.sort_order - b.sort_order)
  const weightTotal = items.reduce((sum, i) => sum + Number(i.weight), 0)

  // 評価軸がまだ無い
  if (!criteriaSet) {
    return (
      <section className="rounded-2xl border border-border-soft bg-surface p-10 text-center">
        <Sparkles size={28} className="mx-auto mb-3 text-accel-secondary" />
        <h3 className="mb-2">まず評価軸を作ります</h3>
        <p className="mx-auto mb-6 max-w-xl text-sm text-black/70">
          登録した会社情報と競合をもとに、求職者がこの会社を選ぶときに見る基準を洗い出し、
          重み付けした評価軸を作ります。この軸は保存され、以降の採点はすべて同じ軸で行われます。
          だからスコアの変化が「実際に何かが変わった」ことを意味します。
        </p>
        {isStaff ? (
          <button
                        onClick={buildCriteria}
            disabled={building}
            className="rounded-lg bg-accel-primary px-6 py-3 text-white hover:bg-accel-hover active:bg-accel-active"
          >
            {building ? '調査中… 1〜2分かかります' : '評価軸を作る'}
          </button>
        ) : (
          <p className="text-sm text-black/60">担当者が評価軸を作成すると表示されます。</p>
        )}
      </section>
    )
  }

  const rivals = Array.from(
    new Set((latest?.competitor_scores ?? []).map((r) => r.competitor_name))
  )
  const rivalScore = (rival: string, criterion: string) =>
    latest?.competitor_scores.find(
      (r) => r.competitor_name === rival && r.criteria_name === criterion
    )?.score ?? null

  return (
    <section className="flex flex-col gap-8">
      {/* 評価軸 */}
      <div className="rounded-2xl border border-border-soft bg-surface p-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h3>評価軸（第 {criteriaSet.version} 版）</h3>
          {isStaff && (
            <div className="flex flex-wrap gap-2">
              {editing ? (
                <>
                  <button
                    onClick={saveCriteria}
                    className="flex items-center gap-2 rounded-lg bg-accel-primary px-4 py-2 text-sm text-white hover:bg-accel-hover"
                  >
                    <Check size={16} />
                    保存
                  </button>
                  <button
                    onClick={() => setEditing(false)}
                    className="rounded-lg border-2 border-border-soft px-4 py-2 text-sm hover:border-accel-secondary"
                  >
                    キャンセル
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => {
                      setDraft(items.map((i) => ({ ...i })))
                      setEditing(true)
                    }}
                    className="flex items-center gap-2 rounded-lg border-2 border-border-soft px-4 py-2 text-sm hover:border-accel-secondary"
                  >
                    <Pencil size={16} />
                    軸を編集
                  </button>
                  <button
                    onClick={buildCriteria}
                    disabled={building}
                    className="flex items-center gap-2 rounded-lg border-2 border-border-soft px-4 py-2 text-sm hover:border-accel-secondary"
                  >
                    <RefreshCw size={16} />
                    {building ? '作り直し中…' : '軸を作り直す'}
                  </button>
                </>
              )}
            </div>
          )}
        </div>

        {criteriaSet.rationale && (
          <p className="mb-4 text-sm text-black/70">{criteriaSet.rationale}</p>
        )}

        {editing ? (
          <div className="flex flex-col gap-4">
            {draft.map((item, i) => (
              <div key={item.id} className="grid gap-3 border-t border-border-soft pt-4 sm:grid-cols-[1fr_auto]">
                <div className="flex flex-col gap-2">
                  <input
                    type="text"
                    value={item.name}
                    onChange={(e) => {
                      const next = [...draft]
                      next[i] = { ...next[i], name: e.target.value }
                      setDraft(next)
                    }}
                  />
                  <textarea
                    value={item.description ?? ''}
                    onChange={(e) => {
                      const next = [...draft]
                      next[i] = { ...next[i], description: e.target.value }
                      setDraft(next)
                    }}
                    style={{ minHeight: '72px' }}
                  />
                </div>
                <div className="flex flex-col gap-2 sm:w-28">
                  <label className="text-xs text-black/60">重み</label>
                  <input
                    type="number"
                    value={item.weight}
                    onChange={(e) => {
                      const next = [...draft]
                      next[i] = { ...next[i], weight: Number(e.target.value) }
                      setDraft(next)
                    }}
                  />
                </div>
              </div>
            ))}
            <p className="text-sm text-black/60">
              重みの合計：{draft.reduce((s, i) => s + Number(i.weight), 0)}
              （100 に揃えると読みやすくなります）
            </p>
          </div>
        ) : (
          <ul className="flex flex-col gap-3">
            {items.map((item) => (
              <li key={item.id} className="flex items-start justify-between gap-4 border-t border-border-soft pt-3">
                <div className="min-w-0">
                  <p className="font-semibold">{item.name}</p>
                  {item.description && <p className="text-sm text-black/60">{item.description}</p>}
                </div>
                <span className="shrink-0 text-sm tabular-nums text-black/60">重み {Number(item.weight)}</span>
              </li>
            ))}
          </ul>
        )}

        {weightTotal !== 100 && !editing && (
          <p className="mt-4 text-sm text-black/60">
            重みの合計が {weightTotal} です。総合スコアは合計値で正規化して計算しています。
          </p>
        )}
      </div>

      {/* 採点 */}
      {isStaff && (
        <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-border-soft bg-surface p-6">
          <button
            onClick={runScoring}
            disabled={scoring}
            className="flex items-center gap-2 rounded-lg bg-accel-primary px-6 py-3 text-white hover:bg-accel-hover active:bg-accel-active"
          >
            <Sparkles size={18} />
            {scoring ? '調査・採点中… 2〜3分かかります' : latest ? '再採点する' : '採点する'}
          </button>
          <p className="text-sm text-black/60">
            Web 検索で採用サイト・求人・口コミを調べ、上の軸で採点します。打ち手も「やること」に追加されます。
          </p>
        </div>
      )}

      {/* 結果 */}
      {latest && (
        <div className="flex flex-col gap-6">
          <div className="rounded-2xl border border-border-soft bg-surface p-6">
            <p className="text-sm text-black/60">総合スコア</p>
            <p className="mb-3 text-5xl font-bold tabular-nums text-accel-primary">
              {latest.overall_score ?? '—'}
              <span className="ml-1 text-lg font-normal text-black/40">/ 100</span>
            </p>
            <p className="mb-1 text-xs text-black/50">
              {new Date(latest.created_at).toLocaleString('ja-JP')} 時点
            </p>
            {latest.summary && <p className="mt-4">{latest.summary}</p>}
          </div>

          <div className="rounded-2xl border border-border-soft bg-surface p-6">
            <h3 className="mb-1">軸ごとのスコア</h3>
            <p className="mb-5 text-sm text-black/60">縦線は同業の平均水準（50）です。</p>
            <ul className="flex flex-col gap-5">
              {latest.assessment_criteria
                .slice()
                .sort((a, b) => a.sort_order - b.sort_order)
                .map((c) => (
                  <li key={c.name} className="border-t border-border-soft pt-4">
                    <div className="mb-2 flex flex-wrap items-baseline justify-between gap-2">
                      <p className="font-semibold">{c.name}</p>
                      <span className="text-xs text-black/50">重み {Number(c.weight)}</span>
                    </div>
                    <ScoreBar score={c.score} />
                    {c.rationale && <p className="mt-2 text-sm text-black/70">{c.rationale}</p>}
                  </li>
                ))}
            </ul>
          </div>

          {rivals.length > 0 && (
            <div className="rounded-2xl border border-border-soft bg-surface p-6">
              <h3 className="mb-1">競合との比較</h3>
              <p className="mb-5 text-sm text-black/60">同じ軸で競合も採点した結果です。</p>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[520px] border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-border-soft text-left">
                      <th className="py-2 pr-4 font-semibold">軸</th>
                      <th className="py-2 pr-4 text-right font-semibold">自社</th>
                      {rivals.map((r) => (
                        <th key={r} className="py-2 pr-4 text-right font-normal text-black/60">
                          {r}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {latest.assessment_criteria
                      .slice()
                      .sort((a, b) => a.sort_order - b.sort_order)
                      .map((c) => (
                        <tr key={c.name} className="border-b border-border-soft/60">
                          <td className="py-2 pr-4">{c.name}</td>
                          <td className="py-2 pr-4 text-right font-semibold tabular-nums">
                            {c.score === null ? '—' : Math.round(c.score)}
                          </td>
                          {rivals.map((r) => {
                            const s = rivalScore(r, c.name)
                            return (
                              <td key={r} className="py-2 pr-4 text-right tabular-nums text-black/60">
                                {s === null ? '—' : Math.round(Number(s))}
                              </td>
                            )
                          })}
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {!latest && isStaff && (
        <p className="text-sm text-black/60">まだ採点していません。「採点する」を押してください。</p>
      )}
    </section>
  )
}
