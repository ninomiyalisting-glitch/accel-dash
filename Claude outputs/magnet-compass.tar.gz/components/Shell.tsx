'use client'

import Link from 'next/link'
import { LogOut, ArrowLeft } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'

export default function Shell({
  email,
  isStaff,
  children
}: {
  email?: string
  isStaff?: boolean
  children: React.ReactNode
}) {
  const router = useRouter()

  async function signOut() {
    await supabase.auth.signOut()
    router.push('/login')
  }

  return (
    <div className="min-h-screen">
      <header className="border-b border-border-soft bg-surface">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-6 py-4">
          <Link href="/" className="shrink-0">
            <img src="/logo.png" alt="マグネット" className="h-8 w-auto" />
          </Link>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href="https://accel-dash.com"
              className="flex items-center gap-1.5 text-sm text-black/60 hover:text-black"
            >
              <ArrowLeft size={15} />
              アクセルダッシュ
            </a>
            {email && (
              <span className="text-sm text-black/60">
                {email}
                {isStaff && (
                  <span className="ml-2 rounded bg-accel-lightest px-2 py-0.5 text-xs text-black">
                    担当者
                  </span>
                )}
              </span>
            )}
            <button
              onClick={signOut}
              className="flex items-center gap-2 rounded-lg border-2 border-border-soft bg-surface px-4 py-2 text-sm hover:border-accel-secondary"
            >
              <LogOut size={16} />
              ログアウト
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">{children}</main>
    </div>
  )
}
