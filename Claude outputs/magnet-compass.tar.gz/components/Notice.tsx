'use client'

import { X } from 'lucide-react'

export type NoticeState = { kind: 'ok' | 'ng'; text: string } | null

export default function Notice({
  notice,
  onClose
}: {
  notice: NoticeState
  onClose: () => void
}) {
  if (!notice) return null

  return (
    <div
      className={
        notice.kind === 'ok'
          ? 'mb-6 flex items-start justify-between gap-4 rounded-lg bg-accel-lightest px-5 py-3'
          : 'mb-6 flex items-start justify-between gap-4 rounded-lg bg-red-50 px-5 py-3 text-red-800'
      }
    >
      <span className="text-sm">{notice.text}</span>
      <button onClick={onClose} aria-label="閉じる" className="shrink-0">
        <X size={16} />
      </button>
    </div>
  )
}
