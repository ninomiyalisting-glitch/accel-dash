# マグネット（magnet.accel-dash.com）

採用魅力度スコアリングと AI 言及モニタリング。アクセルダッシュのサブアプリ。

## セットアップ

```bash
npm install
cp .env.example .env.local   # 値を埋める
npm run dev
```

## 必要な環境変数（Vercel にも同じものを設定）

| 変数 | 用途 |
| --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` | accel-dash と同じ Supabase プロジェクト |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | 同上（公開キー） |
| `SUPABASE_SERVICE_ROLE_KEY` | サーバー側のみ。絶対にクライアントへ出さない |
| `ANTHROPIC_API_KEY` | スコアリングと AI 言及の分析に使用（第2段階から） |

## DB

`supabase/schema.sql` を Supabase の SQL Editor で実行してください。何度実行しても安全です。

## 権限の考え方

- `@accel-partners.co.jp` のアカウント = 担当者。全クライアントを閲覧・編集できる
- それ以外 = クライアント。`company_members` に登録された会社のみ閲覧できる（編集不可）

画面で隠すだけでなく、Supabase の RLS と API 側の両方で判定しています。

## 旧版

`legacy/index.html` は 1 ファイル構成だった旧ダッシュボード。移植したい画面が出たら参照用に使います。
